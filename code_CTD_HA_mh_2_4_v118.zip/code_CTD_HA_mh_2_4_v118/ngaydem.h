#pragma once
#include "globals.h"

// ═════════════════════════════════════════════════════════════
// CHẾ ĐỘ "NGÀY & ĐÊM" — logic cấu hình, cập nhật dữ liệu, nút bấm.
// (Vẽ màn hình vẫn nằm trong ui.cpp/ui.h như các màn hình khác)
// ═════════════════════════════════════════════════════════════

// true nếu thời điểm t nằm trong khung "ban ngày" [NGD_DAY_START_HOUR, NGD_DAY_END_HOUR)
bool ngdIsDaytime(const DateTime &t);

// Đặt lại toàn bộ trạng thái/dữ liệu của chế độ Ngày & Đêm về "Chưa cấu
// hình", đề xuất TGBĐ = thời gian hiện tại. Dùng khi: (1) mới chuyển vào
// chế độ này, (2) người dùng giữ NEXT+OK để cấu hình lại.
void ngdResetConfig();

// Gọi mỗi vòng lặp đọc PZEM (cùng nhịp với updateKWh()) khi
// operatingMode == MODE_NGAYDEM — xử lý chuyển trạng thái Chờ bắt đầu /
// Đang chạy / Đã kết thúc, cộng dồn kWh ngày/đêm và Max/TB/Min công suất.
void ngdUpdate(const DateTime &now);

// ── Xử lý nút bấm (gọi từ buttons.cpp) ────────────────────────
void ngdCursorNext();      // NEXT khi đang duyệt (không edit) ở màn "Cài đặt thời gian"
void ngdEditIncrement();   // NEXT khi đang edit (tăng giá trị field hiện tại)
void ngdToggleEdit();      // OK ở màn "Cài đặt thời gian": bật/tắt chế độ edit field hiện tại
void ngdNextScreen();      // NEXT khi đã lưu cấu hình (đang chạy/đã kết thúc): đổi giữa 4 màn hình
void ngdHandleComboHold(); // Giữ NEXT+OK: Lưu & chạy (nếu chưa cấu hình) hoặc Đặt lại (nếu đang chạy/đã xong)

// Xem trước TGKT trong lúc đang cấu hình (dựa trên ngdCfg*/ngdSoNgay hiện tại)
DateTime ngdPreviewEnd();

// Nhãn văn bản của ngdStatus (dùng chung cho UI và MQTT/HA)
const char* ngdStatusLabel();
