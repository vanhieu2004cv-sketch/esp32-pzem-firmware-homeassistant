#pragma once

void loadPrefs();
void savePrefs();
void resetAllData();
void resetWifiOnly();  // Chỉ xóa cấu hình WiFi (dùng khi vào lại Cấu hình WiFi) — giữ nguyên dữ liệu kWh