#pragma once

// ═══════════════════════════════════════════════════════════
// MQTT CLIENT — Gửi dữ liệu PZEM lên MQTT Broker + Home Assistant
// MQTT Discovery (Tasmota-compatible topic pattern cho dữ liệu thô)
// ═══════════════════════════════════════════════════════════

// MQTT Broker mặc định — chỉ dùng khi CHƯA có cấu hình lưu trong NVS.
// Người dùng cấu hình host/port/user/pass thật qua màn hình "Cấu hình WiFi"
// (Web AP), giá trị sẽ được lưu vào NVS và ưu tiên dùng thay cho mặc định.
#define MQTT_DEFAULT_HOST "broker.hivemq.com"
#define MQTT_DEFAULT_PORT 1883

// Heartbeat interval
#define MQTT_HEARTBEAT_MS  300000UL   // 5 phút

extern bool mqttConnected;

void mqttSetup();                  // Gọi sau khi có WiFi + deviceId
bool mqttReconnect();              // Kết nối/kết nối lại, trả về true nếu OK
void mqttLoop();                   // Gọi trong loop() (keepalive + gửi heartbeat)
void publishPzemData();            // Gửi dữ liệu đo lường hiện tại (tele/{id}/SENSOR)
void publishFullStatus();          // Gửi trạng thái đầy đủ (retained)
void publishTelemetry();           // Gửi heartbeat (không retained)
void publishHADiscovery();         // Gửi các gói MQTT Auto Discovery cho Home Assistant
void mqttDisconnectExplicit();     // Ngắt kết nối MQTT chủ động, báo Offline trước (dùng khi vào lại Cấu hình WiFi)