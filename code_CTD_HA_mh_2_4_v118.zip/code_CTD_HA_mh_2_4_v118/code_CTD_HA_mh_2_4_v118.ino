/*
 * ============================================================
 * ĐỒNG HỒ ĐIỆN KÉP - PZEM-004T v3.0 x2 + DS1307 + ST7789
 * v7 - LVGL v8.3.8 + TFT_eSPI + Web AP Cấu hình + MQTT (Home Assistant)
 * Font VN, tiếng Việt có dấu, WiFi symbol LVGL
 * ============================================================
 *
 * Cấu trúc file:
 *   code_CongToDien.ino — Biến toàn cục, setup(), loop()
 *   globals.h           — Defines, extern, struct dùng chung
 *   log.cpp/h           — Nhật ký lỗi (addLog)
 *   time_rtc.cpp/h      — Thời gian, RTC, NTP
 *   storage.cpp/h       — NVS Preferences (load/save/reset)
 *   pzem.cpp/h          — Đọc PZEM, tính kWh
 *   ui.cpp/h            — LVGL widget helpers + các màn hình
 *   wifi_portal.cpp/h   — Cấu hình WiFi + MQTT qua Web AP (SD_<CHIP_ID>_Config)
 *   mqtt_client.cpp/h   — MQTT publish dữ liệu & Home Assistant MQTT Discovery
 *   buttons.cpp/h       — Nút bấm + LED
 */

#include "globals.h"
#include "log.h"
#include "time_rtc.h"
#include "storage.h"
#include "pzem.h"
#include "mode.h"
#include "ui.h"
#include "wifi_portal.h"
#include "mqtt_client.h"
#include "buttons.h"
#include "ngaydem.h"

// ══════════════════════════════════════════════════════════════
// ĐỊNH NGHĨA BIẾN TOÀN CỤC
// ══════════════════════════════════════════════════════════════

// ── Font ─────────────────────────────────────────────────────
const lv_font_t *FONT_NORMAL = &lv_font_tiengviet_16;
const lv_font_t *FONT_LOG    = &lv_font_tiengviet_12;
const lv_font_t *FONT_SMALL  = &lv_font_tiengviet_10;

// ── LVGL Display ─────────────────────────────────────────────
static lv_disp_draw_buf_t draw_buf;
static lv_color_t buf1[SCR_W * LV_BUF_LINES];
static lv_color_t buf2[SCR_W * LV_BUF_LINES];

TFT_eSPI tft = TFT_eSPI();

// ── PZEM ─────────────────────────────────────────────────────
HardwareSerial pzSerial1(1);
HardwareSerial pzSerial2(2);
PZEM004Tv30   pzSensor1(&pzSerial1, PIN_PZ1_RX, PIN_PZ1_TX);
PZEM004Tv30   pzSensor2(&pzSerial2, PIN_PZ2_RX, PIN_PZ2_TX);

// ── RTC ──────────────────────────────────────────────────────
RTC_DS1307   rtc;
bool         rtcOK        = false;
bool         usingNTPTime = false;
unsigned long tRTCRetry   = 0;

// ── NVS ──────────────────────────────────────────────────────
Preferences prefs;

// ── WiFi ─────────────────────────────────────────────────────
String    wifiSSID      = "";
String    wifiPASS      = "";
bool      wifiConnected  = false;
bool      wifiConfigured = false;

// ── MQTT Broker (Home Assistant) — cấu hình qua Web AP ───────
String    mqttHost = "";
int       mqttPort = 1883;
String    mqttUser = "";
String    mqttPass = "";

// ── Web AP Portal screen flag ────────────────────────────────
bool inWifiConfig = false;

// ── NTP ──────────────────────────────────────────────────────
unsigned long tLastNTP  = 0;
bool          ntpSynced = false;

// ── Nhật ký ──────────────────────────────────────────────────
LogEntry logBuf[LOG_MAX];
int      logCount  = 0;
bool     inLogView = false;
int      logScroll = 0;

// ── Screens ──────────────────────────────────────────────────
ScreenID currentScreen = SCR_CT1;
bool     inSettings    = false;
int      settingsRow   = 0;

// ── Chế độ xem chi tiết bên trong màn hình "Tổng" ──────────────
bool inTotalDetail   = false;
int  totalDetailIndex = 0;

// ── Chế độ xem chi tiết bên trong "Công tơ 1" / "Công tơ 2" ────
bool inCT1Detail   = false;
int  ct1DetailIndex = 0;
bool inCT2Detail   = false;
int  ct2DetailIndex = 0;

// ── Màn hình "Thông tin thiết bị" ──────────────────────────────
bool     inDeviceInfo  = false;

// ── Chế độ hoạt động ─────────────────────────────────────────
OperatingMode operatingMode = MODE_SUM;
bool          inModeSelect  = false;
int           modeSelectRow = 0;

// ── Chế độ "Ngày & Đêm" ──────────────────────────────────────
int           ngdScreenIndex = 0;
NgayDemStatus ngdStatus      = NGD_CHUA_CAUHINH;

int ngdCfgYear = 2024, ngdCfgMonth = 1, ngdCfgDay = 1, ngdCfgHour = 0, ngdCfgMinute = 0;
int ngdSoNgay  = 1;

int  ngdCursorPos = 0;
bool ngdEditing    = false;

uint32_t ngdStartEpoch = 0;
uint32_t ngdEndEpoch   = 0;

float ngdKwhDay      = 0;
float ngdKwhNight    = 0;
float ngdEnergyStart = 0;
float ngdLastEnergy  = 0;

float    ngdPowerMax     = 0;
float    ngdPowerMin     = 0;
float    ngdPowerSum     = 0;
uint32_t ngdPowerSamples = 0;

// (customTitleNgdSetting/P1/P2/P3 được định nghĩa trong mode.cpp, cùng
// chỗ với customTitleCT1/CT2/Total — tránh định nghĩa trùng lặp)

// ── kWh Tổng/Hiệu ────────────────────────────────────────────
float kwhDayTotal    = 0;
float kwhMonTotal[12] = {};
float chartDataTotal[12] = {};

// ── Lịch sử kWh theo ngày trong tháng ("Tháng X") ────────────
float dayHistCurMonth[31]  = {};
float dayHistPrevMonth[31] = {};
int   dayHistCurMonthIdx   = 0;
int   dayHistCurYear       = 0;
int   dayHistPrevMonthIdx  = 0;
int   dayHistPrevYear      = 0;
bool  dayHistShowPrev      = false;
int   dayHistScroll        = 0;

// ── Lịch sử kWh theo ngày của từng công tơ riêng ("Tháng X" bên trong
//    "Công tơ 1" / "Công tơ 2") ─────────────────────────────────────
float dayHistCurMonth1[31] = {};
float dayHistCurMonth2[31] = {};

// ── Lịch sử biểu đồ năm trước ─────────────────────────────────
float chartDataTotalPrev[12] = {};
int   chartPrevYear          = 0;
bool  chartShowPrev          = false;

// ── Snapshot kWh/tháng của từng công tơ vào cuối năm ──────────
float kwhMonth1Prev[12] = {};
float kwhMonth2Prev[12] = {};

// ── PZEM data ────────────────────────────────────────────────
PZReading rd1, rd2;

// ── kWh tracking ─────────────────────────────────────────────
float kwhDay1, kwhDay2;
float kwhMonth1[12], kwhMonth2[12];
float chartData[12];
int   lastDay, lastMonth, lastYear;
float eStart1, eStart2;
float mStart1, mStart2;

int pz1FailCnt = 0, pz2FailCnt = 0;

// ── Buttons ──────────────────────────────────────────────────
unsigned long tOkDown = 0;
unsigned long tNxDown = 0;
bool prevOK   = HIGH;
bool prevNEXT = HIGH;

// ── LED ──────────────────────────────────────────────────────
unsigned long tLedToggle = 0;
bool          ledState   = false;

// ── Timing ───────────────────────────────────────────────────
unsigned long tLastPZ   = 0;
unsigned long tLastDisp = 0;

// ── MQTT publish interval ────────────────────────────────────
static unsigned long tLastMqttPub = 0;
#define MQTT_PUB_INTERVAL_MS 5000UL   // gửi dữ liệu PZEM lên MQTT mỗi 5s

// ══════════════════════════════════════════════════════════════
// LVGL FLUSH CALLBACK
// ══════════════════════════════════════════════════════════════
void my_disp_flush(lv_disp_drv_t *disp_drv, const lv_area_t *area, lv_color_t *color_p) {
    uint32_t w = (area->x2 - area->x1 + 1);
    uint32_t h = (area->y2 - area->y1 + 1);
    tft.startWrite();
    tft.setAddrWindow(area->x1, area->y1, w, h);
    tft.pushColors((uint16_t *)&color_p->full, w * h, true);
    tft.endWrite();
    lv_disp_flush_ready(disp_drv);
}

// ═════════════════════════════════════════════════════════════
// SETUP
// ═════════════════════════════════════════════════════════════
void setup() {
    Serial.begin(115200);
    Serial.println("\n=== PZEM Power Meter v7 (Web AP + MQTT/Home Assistant) ===");

    pinMode(PIN_LED,      OUTPUT);
    pinMode(PIN_TFT_BLK,  OUTPUT);
    pinMode(PIN_BTN_OK,   INPUT_PULLUP);
    pinMode(PIN_BTN_NEXT, INPUT_PULLUP);
    digitalWrite(PIN_TFT_BLK, HIGH);

    // 1. Khởi tạo Device ID (mã thiết bị: SD_<CHIP_ID>) — không đổi
    initDeviceId();

    // 2. Khởi tạo TFT
    tft.begin();
    tft.setRotation(3);
    tft.fillScreen(TFT_BLACK);
    tft.setSwapBytes(true);

    // 3. Khởi tạo LVGL
    lv_init();

    // 4. Đăng ký bộ đệm
    lv_disp_draw_buf_init(&draw_buf, buf1, buf2, SCR_W * LV_BUF_LINES);

    // 5. Đăng ký driver hiển thị
    static lv_disp_drv_t disp_drv;
    lv_disp_drv_init(&disp_drv);
    disp_drv.hor_res  = SCR_W;
    disp_drv.ver_res  = SCR_H;
    disp_drv.flush_cb = my_disp_flush;
    disp_drv.draw_buf = &draw_buf;
    lv_disp_drv_register(&disp_drv);

    // 6. Màn hình khởi động
    lv_obj_t *scr = lv_scr_act();
    lv_obj_set_style_bg_color(scr, LV_C_BG, 0);
    lv_obj_set_style_bg_opa(scr, LV_OPA_COVER, 0);
    lv_obj_clear_flag(scr, LV_OBJ_FLAG_SCROLLABLE);
    make_label(scr, 20, 110, "Đang khởi động...", LV_C_TITLE);
    lv_timer_handler();
    lv_tick_inc(10);

    // 7. RTC
    Wire.begin(PIN_RTC_SDA, PIN_RTC_SCL);
    if (!rtc.begin()) {
        addLog("[LỖI] RTC: Không tìm thấy DS1307");
        rtcOK = false;
    } else {
        rtcOK = true;
        if (!rtc.isrunning()) {
            addLog("[WARN] RTC: Chưa chạy, đặt thời gian biên dịch");
            rtc.adjust(DateTime(F(__DATE__), F(__TIME__)));
        }
        addLog("[OK] RTC: Khởi động thành công");
    }

    // 8. PZEM
    pzSerial1.begin(9600, SERIAL_8N1, PIN_PZ1_RX, PIN_PZ1_TX);
    pzSerial2.begin(9600, SERIAL_8N1, PIN_PZ2_RX, PIN_PZ2_TX);

    // 9. NVS
    loadPrefs();

    // 10. WiFi + MQTT
    if (wifiSSID.length() > 0) {
        wifiConfigured = true;
        WiFi.mode(WIFI_STA);
        WiFi.begin(wifiSSID.c_str(), wifiPASS.c_str());
        unsigned long t = millis();
        while (millis() - t < 8000) {
            if (WiFi.status() == WL_CONNECTED) { wifiConnected = true; break; }
            lv_tick_inc(200);
            lv_timer_handler();
            delay(200);
        }
        if (wifiConnected) {
            addLog("[OK] WiFi: Đã kết nối");
            syncNTP();
            mqttSetup();
            mqttReconnect();
        } else {
            addLog("[WARN] WiFi: Không kết nối được");
            // Không tự bật Web AP — chỉ bật khi user vào "Cấu hình WiFi"
        }
    } else {
        // Chưa có cấu hình WiFi → bật Web AP để người dùng cấu hình
        addLog("[INFO] Chưa có WiFi, bật Web AP cấu hình...");
        startWifiPortal();
    }

    delay(800);
}

// ═════════════════════════════════════════════════════════════
// LOOP
// ═════════════════════════════════════════════════════════════
void loop() {
    static uint32_t last_tick = 0;
    uint32_t now_ms = millis();
    uint32_t elapsed = now_ms - last_tick;
    if (elapsed > 0) {
        lv_tick_inc(elapsed);
        last_tick = now_ms;
    }

    // Xử lý Web AP cấu hình (nếu đang bật)
    handleWifiPortal();

    // WiFi reconnect — bỏ qua khi Web AP cấu hình đang chạy
    if (!wifiPortalActive) {
        if (wifiConfigured && WiFi.status() != WL_CONNECTED) {
            if (wifiConnected) {
                wifiConnected = false;
                addLog("[WARN] WiFi: Mất kết nối");
                WiFi.disconnect(false);
                WiFi.begin(wifiSSID.c_str(), wifiPASS.c_str());
            }
        } else if (wifiConfigured && WiFi.status() == WL_CONNECTED && !wifiConnected) {
            wifiConnected = true;
            addLog("[OK] WiFi: Kết nối lại thành công");
        }
    }

    // NTP sync
    if (wifiConnected && (now_ms - tLastNTP >= NTP_SYNC_MS || tLastNTP == 0)) {
        tLastNTP = now_ms;
        syncNTP();
    }

    // MQTT loop + reconnect
    mqttLoop();

    // Đọc PZEM
    if (now_ms - tLastPZ >= PZ_MS) {
        tLastPZ = now_ms;
        readPZEM();
        DateTime now = getTime();
        updateKWh(now);
        ngdUpdate(now);   // Chế độ "Ngày & Đêm" — cộng dồn kWh ngày/đêm, Max/TB/Min công suất

        // Gửi dữ liệu PZEM lên MQTT theo interval riêng
        if (now_ms - tLastMqttPub >= MQTT_PUB_INTERVAL_MS) {
            tLastMqttPub = now_ms;
            publishPzemData();
        }
    }

    // Cập nhật màn hình (bỏ qua khi đang hiển thị màn hình Cấu hình WiFi)
    if (!inWifiConfig && now_ms - tLastDisp >= DISP_MS) {
        tLastDisp = now_ms;
        drawScreen();
    }

    handleButtons();
    updateLED();

    lv_timer_handler();
    delay(5);
}