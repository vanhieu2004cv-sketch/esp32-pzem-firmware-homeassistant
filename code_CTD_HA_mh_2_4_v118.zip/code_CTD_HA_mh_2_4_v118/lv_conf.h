#if 1 /*Đặt "1" để bật nội dung file này*/

#ifndef LV_CONF_H
#define LV_CONF_H

#include <stdint.h>

/*Biến hỗ trợ kiểm tra phiên bản LVGL*/
#define __LVGL_V8_3 (8 == 8 && 3 == 3)

/*====================
   CẤU HÌNH MÀU SẮC
 *====================*/

/*Độ sâu màu: 1 (1 bit/pixel), 8 (RGB332), 16 (RGB565), 32 (ARGB8888)*/
#define LV_COLOR_DEPTH 16

/*Đảo 2 byte của màu RGB565. Dùng khi màn hình giao tiếp SPI 8-bit*/
#define LV_COLOR_16_SWAP 0

/*Bật khả năng vẽ nền trong suốt (cần cho opa và transform_*).
 *Project không vẽ chồng lớp trong suốt (không OSD/overlay) -> tắt để giảm chi phí*/
#define LV_COLOR_SCREEN_TRANSP 0

/*Làm tròn khi trộn màu (blending). 0: làm tròn xuống, 254: làm tròn lên*/
#define LV_COLOR_MIX_ROUND_OFS 0

/*Màu chroma-key: pixel ảnh có màu này sẽ không được vẽ (không dùng vì không có ảnh)*/
#define LV_COLOR_CHROMA_KEY lv_color_hex(0x00ff00)

/*=========================
   CẤU HÌNH BỘ NHỚ
 *=========================*/

/*1: dùng malloc/free tự viết, 0: dùng lv_mem_alloc()/lv_mem_free() có sẵn của LVGL*/
#define LV_MEM_CUSTOM 0
#if LV_MEM_CUSTOM == 0
    /*Kích thước vùng nhớ heap nội bộ dành cho lv_mem_alloc() (tối thiểu 2KB)
     *Giảm từ 48KB xuống 24KB: project chỉ tạo ~15-20 obj/label mỗi màn hình,
     *không dùng ảnh/chart/list dài nên không cần vùng nhớ lớn*/
    #define LV_MEM_SIZE (24U * 1024U)

    /*Chỉ định địa chỉ cố định cho vùng nhớ (0 = để LVGL tự cấp phát mảng bình thường)*/
    #define LV_MEM_ADR 0
    #if LV_MEM_ADR == 0
        #undef LV_MEM_POOL_INCLUDE
        #undef LV_MEM_POOL_ALLOC
    #endif
#else
    #define LV_MEM_CUSTOM_INCLUDE <stdlib.h>
    #define LV_MEM_CUSTOM_ALLOC   malloc
    #define LV_MEM_CUSTOM_FREE    free
    #define LV_MEM_CUSTOM_REALLOC realloc
#endif

/*Số lượng buffer nhớ tạm dùng trong quá trình vẽ (giữ mặc định, an toàn)*/
#define LV_MEM_BUF_MAX_NUM 16

/*1: dùng memcpy/memset chuẩn thay vì hàm riêng của LVGL*/
#define LV_MEMCPY_MEMSET_STD 0

/*====================
   CẤU HÌNH PHẦN CỨNG (HAL)
 *====================*/

/*Chu kỳ LVGL vẽ lại vùng thay đổi trên màn hình*/
#define LV_DISP_DEF_REFR_PERIOD 30      /*[ms]*/

/*Chu kỳ đọc thiết bị nhập (không dùng vì không có lv_indev nào trong project)*/
#define LV_INDEV_DEF_READ_PERIOD 30     /*[ms]*/

/*Dùng nguồn tick riêng để báo thời gian trôi qua (tắt: project tự gọi lv_tick_inc() trong loop())*/
#define LV_TICK_CUSTOM 0
#if LV_TICK_CUSTOM
    #define LV_TICK_CUSTOM_INCLUDE "Arduino.h"
    #define LV_TICK_CUSTOM_SYS_TIME_EXPR (millis())
#endif

/*DPI mặc định, chỉ ảnh hưởng kích thước/khoảng cách mặc định của theme (không quan trọng vì đã tắt theme)*/
#define LV_DPI_DEF 130     /*[px/inch]*/

/*=======================
 * CẤU HÌNH TÍNH NĂNG
 *=======================*/

/*-------------
 * Vẽ (Drawing)
 *-----------*/

/*Bật draw engine phức tạp - cần cho shadow, gradient, bo góc, hình tròn, arc, mask...
 *TẮT: toàn bộ UI trong project dùng radius=0, border_width=0, không shadow/gradient/arc/opa
 *từng phần -> không cần draw engine phức tạp, tắt giúp giảm flash đáng kể*/
#define LV_DRAW_COMPLEX 1
#if LV_DRAW_COMPLEX != 0
    #define LV_SHADOW_CACHE_SIZE 0
    #define LV_CIRCLE_CACHE_SIZE 4
#endif

/*Buffer cho "simple layer" - chỉ dùng khi widget có style_opa < 255 (opacity riêng từng đối tượng).
 *Project không set opa cho bất kỳ widget nào (chỉ bg_opa COVER/TRANSP) -> giảm mạnh buffer này*/
#define LV_LAYER_SIMPLE_BUF_SIZE          (2 * 1024)
#define LV_LAYER_SIMPLE_FALLBACK_BUF_SIZE (512)

/*Kích thước cache ảnh mặc định (0 = tắt cache, không dùng vì project không có ảnh)*/
#define LV_IMG_CACHE_DEF_SIZE 0

/*Số điểm dừng màu tối đa cho gradient (không dùng gradient nhưng giữ mặc định tối thiểu)*/
#define LV_GRADIENT_MAX_STOPS 2

/*Cache cho bản đồ gradient đã tính (0 = không cache, không dùng vì không có gradient)*/
#define LV_GRAD_CACHE_DEF_SIZE 0

/*Dithering cho gradient (không dùng vì không có gradient)*/
#define LV_DITHER_GRADIENT 0
#if LV_DITHER_GRADIENT
    #define LV_DITHER_ERROR_DIFFUSION 0
#endif

/*Buffer tối đa cho xoay ảnh bằng phần mềm (không dùng - project xoay màn hình bằng
 *tft.setRotation() ở tầng driver TFT_eSPI, không bật sw_rotate trong lv_disp_drv)*/
#define LV_DISP_ROT_MAX_BUF (10*1024)

/*-------------
 * GPU tăng tốc phần cứng
 *-----------*/
/*ESP32 không có GPU 2D chuyên dụng được LVGL hỗ trợ -> tắt toàn bộ (tránh nhầm sang STM32/NXP/SDL)*/
#define LV_USE_GPU_ARM2D        0
#define LV_USE_GPU_STM32_DMA2D  0
#define LV_USE_GPU_SWM341_DMA2D 0
#define LV_USE_GPU_NXP_PXP      0
#define LV_USE_GPU_NXP_VG_LITE  0
#define LV_USE_GPU_SDL          0

/*-------------
 * Ghi log (Logging)
 *-----------*/

/*Bật module log của LVGL (đang tắt để tiết kiệm flash/CPU; bật lại nếu cần debug sâu)*/
#define LV_USE_LOG 0
#if LV_USE_LOG
    /*Mức độ log: TRACE (chi tiết nhất) > INFO > WARN > ERROR > USER > NONE*/
    #define LV_LOG_LEVEL LV_LOG_LEVEL_WARN

    /*1: in log bằng printf; 0: phải tự đăng ký callback lv_log_register_print_cb()*/
    #define LV_LOG_PRINTF 0

    /*Bật/tắt log TRACE cho từng module (chỉ có tác dụng khi LV_USE_LOG=1)*/
    #define LV_LOG_TRACE_MEM        1
    #define LV_LOG_TRACE_TIMER      1
    #define LV_LOG_TRACE_INDEV      1
    #define LV_LOG_TRACE_DISP_REFR  1
    #define LV_LOG_TRACE_EVENT      1
    #define LV_LOG_TRACE_OBJ_CREATE 1
    #define LV_LOG_TRACE_LAYOUT     1
    #define LV_LOG_TRACE_ANIM       1
#endif  /*LV_USE_LOG*/

/*-------------
 * Kiểm tra lỗi (Assert)
 *-----------*/

/*Bật assert khi thao tác thất bại hoặc dữ liệu không hợp lệ*/
#define LV_USE_ASSERT_NULL          1   /*Kiểm tra tham số NULL (rất nhanh, nên bật)*/
#define LV_USE_ASSERT_MALLOC        1   /*Kiểm tra cấp phát bộ nhớ thành công hay không (rất nhanh, nên bật)*/
#define LV_USE_ASSERT_STYLE         0   /*Kiểm tra style đã khởi tạo đúng chưa*/
#define LV_USE_ASSERT_MEM_INTEGRITY 0   /*Kiểm tra tính toàn vẹn bộ nhớ (chậm)*/
#define LV_USE_ASSERT_OBJ           0   /*Kiểm tra loại/tồn tại của object (chậm)*/

/*Xử lý riêng khi assert xảy ra, ví dụ để restart MCU. Mặc định: dừng chương trình (while(1))*/
#define LV_ASSERT_HANDLER_INCLUDE <stdint.h>
#define LV_ASSERT_HANDLER while(1);

/*-------------
 * Khác
 *-----------*/

/*Hiện CPU usage và FPS trên màn hình (bật khi cần đo hiệu năng thực tế)*/
#define LV_USE_PERF_MONITOR 0
#if LV_USE_PERF_MONITOR
    #define LV_USE_PERF_MONITOR_POS LV_ALIGN_BOTTOM_RIGHT
#endif

/*Hiện bộ nhớ đã dùng và mức phân mảnh (bật khi cần kiểm tra sau khi giảm LV_MEM_SIZE)*/
#define LV_USE_MEM_MONITOR 0
#if LV_USE_MEM_MONITOR
    #define LV_USE_MEM_MONITOR_POS LV_ALIGN_BOTTOM_LEFT
#endif

/*Tô màu ngẫu nhiên vùng vừa vẽ lại (chỉ dùng để debug hiệu năng vẽ)*/
#define LV_USE_REFR_DEBUG 0

/*Dùng hàm snprintf tự viết thay vì mặc định (không cần, dùng snprintf chuẩn của ESP32)*/
#define LV_SPRINTF_CUSTOM 0
#if LV_SPRINTF_CUSTOM
    #define LV_SPRINTF_INCLUDE <stdio.h>
    #define lv_snprintf  snprintf
    #define lv_vsnprintf vsnprintf
#else
    #define LV_SPRINTF_USE_FLOAT 0
#endif

/*Cho phép gán user_data vào object (giữ bật vì có thể hữu ích, chi phí không đáng kể)*/
#define LV_USE_USER_DATA 1

/*Garbage Collector - chỉ dùng khi LVGL được bind với ngôn ngữ bậc cao (MicroPython...). Không dùng ở đây*/
#define LV_ENABLE_GC 0
#if LV_ENABLE_GC != 0
    #define LV_GC_INCLUDE "gc.h"
#endif

/*=====================
 *  CẤU HÌNH TRÌNH BIÊN DỊCH
 *====================*/

#define LV_BIG_ENDIAN_SYSTEM 0                /*ESP32 là little-endian*/
#define LV_ATTRIBUTE_TICK_INC                 /*Attribute riêng cho hàm lv_tick_inc()*/
#define LV_ATTRIBUTE_TIMER_HANDLER            /*Attribute riêng cho hàm lv_timer_handler()*/
#define LV_ATTRIBUTE_FLUSH_READY              /*Attribute riêng cho hàm lv_disp_flush_ready()*/
#define LV_ATTRIBUTE_MEM_ALIGN_SIZE 1         /*Yêu cầu căn lề bộ nhớ cho buffer*/
#define LV_ATTRIBUTE_MEM_ALIGN                /*Ép căn lề bộ nhớ, ví dụ __attribute__((aligned(4)))*/
#define LV_ATTRIBUTE_LARGE_CONST              /*Đánh dấu mảng hằng lớn (bitmap font)*/
#define LV_ATTRIBUTE_LARGE_RAM_ARRAY          /*Prefix cho mảng lớn khai báo trong RAM*/
#define LV_ATTRIBUTE_FAST_MEM                 /*Đặt hàm quan trọng về tốc độ vào vùng nhớ nhanh*/
#define LV_ATTRIBUTE_DMA                      /*Prefix cho biến dùng trong thao tác GPU/DMA (không dùng vì không có GPU)*/

/*Export hằng số nguyên cho binding (MicroPython...). Không dùng nhưng cần định nghĩa để biên dịch*/
#define LV_EXPORT_CONST_INT(int_value) struct _silence_gcc_warning

/*Mở rộng phạm vi toạ độ từ -32k..32k lên -4M..4M (không cần vì màn hình chỉ 320x240)*/
#define LV_USE_LARGE_COORD 0

/*==================
 *   CẤU HÌNH FONT
 *===================*/

/*Font tiếng Việt build sẵn của LVGL bản tuỳ biến*/
#define LV_FONT_TIENGVIET_8    0
#define LV_FONT_TIENGVIET_10   1
#define LV_FONT_TIENGVIET_12   1
#define LV_FONT_TIENGVIET_14   0
#define LV_FONT_TIENGVIET_16   1
#define LV_FONT_TIENGVIET_18   0
#define LV_FONT_TIENGVIET_20   0
#define LV_FONT_TIENGVIET_22   0
#define LV_FONT_TIENGVIET_24   0
#define LV_FONT_TIENGVIET_26   0
#define LV_FONT_TIENGVIET_28   0
#define LV_FONT_TIENGVIET_30   0
#define LV_FONT_TIENGVIET_32   0
#define LV_FONT_TIENGVIET_34   0
#define LV_FONT_TIENGVIET_36   0
#define LV_FONT_TIENGVIET_38   0
#define LV_FONT_TIENGVIET_40   0
#define LV_FONT_TIENGVIET_42   0
#define LV_FONT_TIENGVIET_48   0

// Font Symbol
#define LV_FONT_SYMBOL_14  1
#define LV_FONT_SYMBOL_16  0
#define LV_FONT_SYMBOL_18  0
#define LV_FONT_SYMBOL_20  0

/*Khai báo trước các font tuỳ biến (để trống vì đã LV_FONT_DECLARE trong globals.h)*/
#define LV_FONT_CUSTOM_DECLARE

/*Font mặc định khi widget không chỉ định font riêng (label trong project luôn set font
 *tường minh qua FONT_NORMAL/FONT_LOG nên font này hiếm khi được dùng, giữ làm phương án dự phòng)*/
#define LV_FONT_DEFAULT &lv_font_tiengviet_10

/*Bật hỗ trợ font lớn/nhiều ký tự - GIỮ NGUYÊN =1 vì lv_font_VN_12/16 cần cờ này để build
 *đúng (đây là phần đã fix lỗi "missing font" trước đó, không nên tắt)*/
#define LV_FONT_FMT_TXT_LARGE 1

/*Hỗ trợ font nén (không dùng, font hiện tại build ở dạng không nén --no-compress)*/
#define LV_USE_FONT_COMPRESSED 0

/*Subpixel rendering (không dùng, không cần cho màn TFT thường)*/
#define LV_USE_FONT_SUBPX 0

/*Vẽ ký tự placeholder khi thiếu glyph (giữ bật để dễ phát hiện lỗi thiếu ký tự tiếng Việt)*/
#define LV_USE_FONT_PLACEHOLDER 1

/*=================
 *  CẤU HÌNH VĂN BẢN
 *=================*/

/*Bảng mã ký tự - BẮT BUỘC UTF-8 để hiển thị tiếng Việt có dấu*/
#define LV_TXT_ENC LV_TXT_ENC_UTF8

/*Các ký tự cho phép ngắt dòng*/
#define LV_TXT_BREAK_CHARS " ,.;:-_"

/*Ngắt từ dài giữa chừng nếu từ dài hơn giá trị này (0 = tắt)*/
#define LV_TXT_LINE_BREAK_LONG_LEN 0
#define LV_TXT_LINE_BREAK_LONG_PRE_MIN_LEN 3
#define LV_TXT_LINE_BREAK_LONG_POST_MIN_LEN 3

/*Ký tự điều khiển đổi màu chữ trong chuỗi (recolor)*/
#define LV_TXT_COLOR_CMD "#"

/*Hỗ trợ văn bản 2 chiều (trộn chữ Left-to-Right và Right-to-Left) - tiếng Việt không cần*/
#define LV_USE_BIDI 0
#if LV_USE_BIDI
    #define LV_BIDI_BASE_DIR_DEF LV_BASE_DIR_AUTO
#endif

/*Xử lý ký tự Ả Rập/Ba Tư (không cần cho tiếng Việt)*/
#define LV_USE_ARABIC_PERSIAN_CHARS 0

/*==================
 *  WIDGET CƠ BẢN
 *================*/

/*Project chỉ dùng lv_obj_create() (làm khung/nền) và lv_label_create() (hiển thị chữ)
 *-> tắt toàn bộ widget cơ bản khác để giảm flash*/

#define LV_USE_ARC        0   /*Không dùng*/
#define LV_USE_BAR        0   /*Không dùng*/
#define LV_USE_BTN        0   /*Không dùng*/
#define LV_USE_BTNMATRIX  0   /*Không dùng*/
#define LV_USE_CANVAS     1   /*Không dùng*/
#define LV_USE_CHECKBOX   0   /*Không dùng*/
#define LV_USE_DROPDOWN   0   /*Không dùng*/
#define LV_USE_IMG        1   /*Không dùng - UI không có ảnh*/

#define LV_USE_LABEL      1   /*Widget chính của toàn bộ UI*/
#if LV_USE_LABEL
    #define LV_LABEL_TEXT_SELECTION 0 /*Không dùng - không có touch/encoder để bôi đen chọn chữ*/
    #define LV_LABEL_LONG_TXT_HINT 1  /*Lưu thông tin phụ để vẽ nhanh hơn với chữ dài (log, lịch sử...)*/
#endif

#define LV_USE_LINE       0   /*Không dùng*/
#define LV_USE_ROLLER     0   /*Không dùng*/
#define LV_USE_SLIDER     0   /*Không dùng*/
#define LV_USE_SWITCH     0   /*Không dùng*/
#define LV_USE_TEXTAREA   0   /*Không dùng*/
#define LV_USE_TABLE      0   /*Không dùng*/

/*==================
 * WIDGET MỞ RỘNG
 *==================*/

/*Không dùng bất kỳ widget mở rộng nào (chart, list, keyboard, calendar, meter...) -> tắt hết*/

#define LV_USE_ANIMIMG    0
#define LV_USE_CALENDAR   0
#define LV_USE_CHART      0
#define LV_USE_COLORWHEEL 0
#define LV_USE_IMGBTN     0
#define LV_USE_KEYBOARD   0
#define LV_USE_LED        0
#define LV_USE_LIST       0
#define LV_USE_MENU       0
#define LV_USE_METER      0
#define LV_USE_MSGBOX     0
#define LV_USE_SPAN       0
#define LV_USE_SPINBOX    0
#define LV_USE_SPINNER    0
#define LV_USE_TABVIEW    0
#define LV_USE_TILEVIEW   0
#define LV_USE_WIN        0

/*-----------
 * Theme
 *----------*/

/*Toàn bộ obj trong ui.cpp đều tự set bg_color/bg_opa/border/radius/text thủ công
 *-> không cần theme mặc định, tắt hết để giảm flash*/
#define LV_USE_THEME_DEFAULT 0
#define LV_USE_THEME_BASIC   0
#define LV_USE_THEME_MONO    0

/*-----------
 * Layout
 *----------*/

/*Không dùng Flexbox - project đặt vị trí bằng lv_obj_set_pos() thủ công*/
#define LV_USE_FLEX 0

/*Không dùng Grid layout*/
#define LV_USE_GRID 0

/*---------------------
 * Thư viện bên thứ ba
 *--------------------*/

/*Project không đọc/ghi file (fopen/FATFS...), không giải mã ảnh PNG/BMP/JPG/GIF,
 *không dùng QR code, FreeType, Rlottie hay FFmpeg -> tắt toàn bộ để giảm flash tối đa*/
#define LV_USE_FS_STDIO 0
#define LV_USE_FS_POSIX 0
#define LV_USE_FS_WIN32 0
#define LV_USE_FS_FATFS 0
#define LV_USE_PNG      0
#define LV_USE_BMP      0
#define LV_USE_SJPG     0
#define LV_USE_GIF      0
#define LV_USE_QRCODE   1
#define LV_USE_FREETYPE 0
#define LV_USE_RLOTTIE  0
#define LV_USE_FFMPEG   0

/*-----------
 * Khác
 *----------*/

/*Các tính năng phụ trợ không dùng đến trong project -> tắt hết*/
#define LV_USE_SNAPSHOT    0   /*Chụp ảnh snapshot của object*/
#define LV_USE_MONKEY      0   /*Test ngẫu nhiên (monkey test)*/
#define LV_USE_GRIDNAV     0   /*Điều hướng bằng grid (dùng với encoder/bàn phím)*/
#define LV_USE_FRAGMENT    0   /*lv_obj fragment*/
#define LV_USE_IMGFONT     0   /*Dùng ảnh làm ký tự font*/
#define LV_USE_MSG         0   /*Hệ thống message pub/sub*/
#define LV_USE_IME_PINYIN  0   /*Bộ gõ tiếng Trung Pinyin - không liên quan tiếng Việt*/

/*==================
* VÍ DỤ & DEMO
*==================*/

/*Không build ví dụ/demo mẫu của LVGL để giảm dung lượng flash*/
#define LV_BUILD_EXAMPLES 0
#define LV_USE_DEMO_WIDGETS 0
#define LV_USE_DEMO_KEYPAD_AND_ENCODER 0
#define LV_USE_DEMO_BENCHMARK 0
#define LV_USE_DEMO_STRESS 0
#define LV_USE_DEMO_MUSIC 0

/*--KẾT THÚC LV_CONF_H--*/

#endif /*LV_CONF_H*/

#endif /*Kết thúc "Content enable"*/