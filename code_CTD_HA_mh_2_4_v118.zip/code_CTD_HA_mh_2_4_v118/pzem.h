#pragma once
#include <RTClib.h>

void readPZEM();
void updateKWh(const DateTime &now);

// Công suất tức thời theo chế độ hiện tại (Tổng CT1+CT2, hoặc Hiệu CT1-CT2)
float totalWattValue();