#pragma once

// ═══════════════════════════════════════════════════════════
// WIFI PORTAL — Cấu hình WiFi + MQTT qua Web AP (thay thế BLE)
// Khi chưa có WiFi (hoặc user chọn "Kết nối WiFi" trong Cài đặt),
// ESP32 tự phát Access Point riêng (SD_<CHIP_ID>_Config), người dùng
// dùng điện thoại/máy tính kết nối vào AP đó rồi mở trình duyệt tới
// http://192.168.4.1 để nhập SSID/mật khẩu WiFi + thông tin MQTT Broker.
// Sau khi lưu, thiết bị tự khởi động lại để áp dụng cấu hình mới.
// ═══════════════════════════════════════════════════════════

// Mã thiết bị — GIỮ NGUYÊN quy tắc đặt tên cũ (SD_XXXX), không đổi.
extern String deviceId;      // SD_XXXX
extern String deviceType;    // pzem_meter
extern bool   wifiPortalActive;

void initDeviceId();         // Gọi sớm nhất trong setup()
void startWifiPortal();      // Bật AP + Web Server cấu hình
void stopWifiPortal();       // Tắt AP + Web Server
void handleWifiPortal();     // Gọi trong loop() — xử lý request web
