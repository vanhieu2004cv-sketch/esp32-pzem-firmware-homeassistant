/*
 * WiFi Portal — Cấu hình WiFi + MQTT qua Web AP (thay thế BLE Provisioning)
 *
 * Khi cần cấu hình (chưa có WiFi, hoặc user chọn "Kết nối WiFi" trong Cài
 * đặt), ESP32 phát 1 Access Point riêng với tên SD_<CHIP_ID>_Config.
 * Người dùng kết nối điện thoại/máy tính vào AP này, mở trình duyệt tới
 * http://192.168.4.1 (tự động bật lên nhờ DNS "captive portal" trên hầu hết
 * điện thoại) để nhập:
 *   - Tên WiFi (SSID) + mật khẩu
 *   - Địa chỉ MQTT Broker (host) + port
 *   - Tài khoản/mật khẩu MQTT (tùy chọn, nếu Broker yêu cầu xác thực)
 *
 * Sau khi bấm "Lưu", thiết bị lưu cấu hình vào NVS rồi tự khởi động lại
 * (ESP.restart()) để kết nối WiFi + MQTT với cấu hình mới — đơn giản và
 * chắc chắn hơn nhiều so với việc tự chuyển đổi trạng thái ngay trong lúc
 * AP vẫn đang chạy.
 */

#include "globals.h"
#include "log.h"
#include "mode.h"
#include "storage.h"
#include "wifi_portal.h"

#include <WebServer.h>
#include <DNSServer.h>
#include <vector>
#include <algorithm>

// ─── Cấu hình AP ─────────────────────────────────────────────
#define WIFI_PORTAL_AP_PASS "12345678"   // Tối thiểu 8 ký tự theo yêu cầu ESP32 SoftAP
#define WIFI_PORTAL_DNS_PORT 53

// ─── Device Identity — GIỮ NGUYÊN, không đổi mã thiết bị ────
String deviceId   = "";   // SD_XXXX
String deviceType = "";   // pzem_meter

bool wifiPortalActive = false;

static WebServer  server(80);
static DNSServer   dnsServer;
static String      apName;   // SD_XXXX_Config

// ─── Máy trạng thái kết nối WiFi bất đồng bộ (chạy trong handleWifiPortal) ──
// QUAN TRỌNG: KHÔNG được gọi WiFi.begin() rồi chờ (block) ngay trong handler
// của /save nữa. Lý do: ESP32 SoftAP + STA dùng CHUNG 1 radio nên phải hoạt
// động trên CÙNG 1 kênh (channel). Khi STA bắt đầu kết nối tới router thật ở
// kênh khác với kênh hiện tại của SoftAP, module tự động chuyển kênh AP ngay
// lập tức (không cần đợi kết nối xong) → điện thoại đang associate với AP bị
// rớt liên kết trong chốc lát để re-associate lại ở kênh mới. Nếu việc này
// xảy ra NGAY TRONG LÚC request POST /save đang mở (đang chờ response), phiên
// TCP của chính request đó bị đứt giữa chừng → trình duyệt không nhận được
// response nào cả => đúng hiện tượng "trang web bị sập", dù điện thoại vẫn
// tự re-associate lại AP rất nhanh nên người dùng thấy WiFi vẫn "đang kết nối".
//
// Cách xử lý: /save CHỈ lưu tạm dữ liệu rồi trả response "Đang kết nối..."
// NGAY LẬP TỨC (đóng request đó lại an toàn). Việc đồng bộ kênh AP + gọi
// WiFi.begin() thật sự chỉ diễn ra SAU đó, trong loop(), tách rời khỏi request
// đã đóng. Trang web dùng JS poll GET /status (mỗi lần là 1 request mới, độc
// lập) để lấy tiến độ — nếu đúng lúc đó AP có đổi kênh làm rớt 1 lần poll thì
// điện thoại tự re-associate và lần poll kế tiếp vẫn thành công bình thường,
// không còn treo trang vĩnh viễn nữa.
enum class ConnectState { IDLE, PENDING_START, CONNECTING, CONNECTED, FAILED };
static volatile ConnectState connState = ConnectState::IDLE;
static String        pendingSsid, pendingPass, pendingMHost, pendingMUser, pendingMPass;
static int           pendingMPort = 1883;
static unsigned long connectStartAt  = 0;   // thời điểm (millis) bắt đầu gọi WiFi.begin() thật
static unsigned long connectDeadline = 0;   // hạn chót coi như thất bại
static unsigned long restartAt       = 0;   // 0 = chưa lên lịch restart
static const unsigned long CONNECT_START_DELAY_MS = 400;    // đợi response /save chắc chắn đã gửi xong
static const unsigned long CONNECT_TIMEOUT_MS      = 12000;
static const unsigned long RESTART_DELAY_MS        = 2500;  // đợi client kịp poll thấy "connected"

// ═══════════════════════════════════════════════════════════
// INIT DEVICE ID (mã thiết bị) — không thay đổi so với bản cũ
// ═══════════════════════════════════════════════════════════
void initDeviceId() {
    uint64_t mac = ESP.getEfuseMac();
    char idBuf[12];
    snprintf(idBuf, sizeof(idBuf), "SD_%04X", (uint16_t)(mac >> 32));
    deviceId   = String(idBuf);
    deviceType = "pzem_meter";
    Serial.printf("[Device] deviceId=%s type=%s\n", deviceId.c_str(), deviceType.c_str());
}

// Khai báo trước — hàm này được định nghĩa phía dưới (dùng cho /scan) nhưng
// buildConfigPage() ở trên cũng cần dùng để escape chuỗi JSON/JS an toàn.
static String escapeJson(const String &s);

// ═══════════════════════════════════════════════════════════
// TRANG HTML CẤU HÌNH
// ═══════════════════════════════════════════════════════════
static String buildConfigPage() {
    String html;
    html.reserve(5200);
    html += (
        "<!DOCTYPE html><html lang='vi'><head><meta charset='utf-8'>"
        "<meta name='viewport' content='width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no'>"
        "<title>Cấu hình thiết bị</title>"
        "<style>"
        ":root{"
          "--bg:#0b0f19;--card:#151c2c;--input-bg:#1a2336;--border:rgba(255,255,255,.08);"
          "--border-active:#3b82f6;--text:#f8fafc;--text-sub:#94a3b8;--accent:#3b82f6;"
          "--accent-light:rgba(59,130,246,.15);--success:#22c55e;--danger:#ef4444;--radius:12px;"
        "}"
        "*{box-sizing:border-box;margin:0;padding:0;"
          "font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;"
          "-webkit-tap-highlight-color:transparent;}"
        "body{background-color:var(--bg);color:var(--text);min-height:100vh;"
          "display:flex;justify-content:center;padding:0;}"
        ".app-container{width:100%;max-width:480px;padding:24px 18px 40px;}"
        ".header{display:flex;align-items:center;gap:14px;margin-bottom:24px;"
          "padding-bottom:16px;border-bottom:1px solid var(--border);}"
        ".icon-box{width:44px;height:44px;border-radius:12px;"
          "background:linear-gradient(135deg,#2563eb,#1d4ed8);display:flex;"
          "align-items:center;justify-content:center;flex-shrink:0;"
          "box-shadow:0 4px 12px rgba(37,99,235,.3);}"
        ".icon-box svg{width:24px;height:24px;fill:#fff;}"
        ".header-info h1{font-size:18px;font-weight:700;color:var(--text);}"
        ".device-tag{display:inline-flex;align-items:center;gap:6px;margin-top:3px;"
          "font-size:12px;color:var(--accent);font-weight:600;}"
        ".device-tag .dot{width:6px;height:6px;border-radius:50%;background:var(--success);}"
        ".group-title{font-size:12px;font-weight:700;text-transform:uppercase;"
          "letter-spacing:.6px;color:var(--text-sub);margin:20px 0 10px 4px;}"
        ".field{margin-bottom:14px;position:relative;}"
        "label{display:block;font-size:13px;color:var(--text-sub);"
          "margin-bottom:6px;margin-left:2px;}"
        ".input-box{position:relative;display:flex;align-items:center;}"
        "input{width:100%;height:48px;padding:0 14px;background:var(--input-bg);"
          "border:1px solid var(--border);border-radius:var(--radius);color:var(--text);"
          "font-size:15px;outline:none;transition:border-color .2s;}"
        "input:focus{border-color:var(--border-active);}"
        "input::placeholder{color:#475569;}"
        ".btn-inline-scan{position:absolute;right:6px;height:36px;padding:0 12px;"
          "background:var(--accent-light);border:none;border-radius:8px;color:var(--accent);"
          "font-size:12.5px;font-weight:600;cursor:pointer;display:flex;align-items:center;"
          "gap:6px;}"
        ".btn-inline-scan:active{opacity:.8;}"
        ".btn-inline-scan:disabled{opacity:.6;}"
        ".btn-pw-toggle{position:absolute;right:6px;height:36px;padding:0 12px;"
          "background:transparent;border:none;color:var(--text-sub);font-size:12px;"
          "font-weight:600;cursor:pointer;}"
        ".wifi-dropdown{margin-top:6px;background:var(--card);border:1px solid var(--border);"
          "border-radius:var(--radius);max-height:200px;overflow-y:auto;display:none;"
          "box-shadow:0 10px 25px rgba(0,0,0,.5);}"
        ".wifi-dropdown.show{display:block;}"
        ".wifi-item{display:flex;align-items:center;justify-content:space-between;"
          "padding:12px 14px;border-bottom:1px solid var(--border);cursor:pointer;}"
        ".wifi-item:last-child{border-bottom:none;}"
        ".wifi-item:active{background:rgba(255,255,255,.05);}"
        ".wifi-name{font-size:14px;font-weight:500;overflow:hidden;text-overflow:ellipsis;"
          "white-space:nowrap;flex:1;margin-right:8px;}"
        ".wifi-signal{display:flex;align-items:flex-end;gap:2px;height:12px;flex:0 0 auto;}"
        ".wifi-signal span{width:3px;background:#334155;border-radius:1px;}"
        ".wifi-signal span:nth-child(1){height:30%;}"
        ".wifi-signal span:nth-child(2){height:50%;}"
        ".wifi-signal span:nth-child(3){height:75%;}"
        ".wifi-signal span:nth-child(4){height:100%;}"
        ".wifi-signal.level-3 span:nth-child(-n+3),.wifi-signal.level-4 span{background:var(--success);}"
        ".wifi-signal.level-2 span:nth-child(-n+2){background:#f59e0b;}"
        ".wifi-signal.level-1 span:nth-child(1){background:var(--danger);}"
        ".wifi-msg{padding:12px 14px;text-align:center;color:var(--text-sub);font-size:13px;}"
        ".wifi-msg.err{color:var(--danger);}"
        ".btn-submit{width:100%;height:50px;margin-top:28px;background:#22c55e;border:none;"
          "border-radius:var(--radius);color:#fff;font-size:16px;font-weight:700;cursor:pointer;"
          "display:flex;align-items:center;justify-content:center;gap:8px;"
          "box-shadow:0 6px 20px rgba(34,197,94,.25);}"
        ".btn-submit:active{transform:scale(.99);opacity:.9;}"
        ".btn-submit:disabled{opacity:.7;}"
        ".spin{width:14px;height:14px;border:2px solid rgba(255,255,255,.3);"
          "border-top-color:#fff;border-radius:50%;animation:spin .8s linear infinite;display:none;}"
        ".spin.active{display:inline-block;}"
        ".btn-inline-scan .spin{border:2px solid rgba(59,130,246,.3);border-top-color:var(--accent);}"
        "@keyframes spin{to{transform:rotate(360deg);}}"
        ".mode-options{display:flex;flex-direction:column;gap:8px;}"
        ".mode-opt{display:flex;align-items:center;gap:10px;padding:12px 14px;"
          "background:var(--input-bg);border:1px solid var(--border);border-radius:var(--radius);"
          "font-size:14.5px;cursor:pointer;}"
        ".mode-opt input{width:16px;height:16px;accent-color:var(--accent);flex-shrink:0;}"
        ".title-cards{display:flex;flex-direction:column;gap:10px;}"
        ".title-card{background:var(--input-bg);border:1px solid var(--border);"
          "border-radius:var(--radius);padding:12px 14px;}"
        ".title-card label{display:flex;align-items:center;gap:6px;font-size:12px;"
          "color:var(--text-sub);margin-bottom:8px;}"
        ".title-card input{height:42px;background:var(--card);}"
        "footer{margin-top:30px;text-align:center;font-size:12px;color:var(--text-sub);opacity:.6;}"
        "</style></head><body><div class='app-container'>"
    );

    html += (
        "<div class='header'><div class='icon-box'>"
        "<svg viewBox='0 0 24 24'><path d='M12 3C6.95 3 2.55 5.5 0 9.34L12 21 24 9.34C21.45 5.5 17.05 3 12 3zm0 4.5c3.25 0 6.18 1.42 8.2 3.67L12 19.3 3.8 11.17C5.82 8.92 8.75 7.5 12 7.5z'/></svg>"
        "</div><div class='header-info'><h1>Cấu hình kết nối</h1>"
        "<div class='device-tag'><span class='dot'></span><span>Thiết bị: "
    );
    html += deviceId;
    html += ("</span></div></div></div>");

    html += ("<form method='POST' action='/save' id='cfgForm'>");

    html += ("<div class='group-title'>1. Mạng WiFi</div>");
    html += (
        "<div class='field'><label for='ssid'>Tên mạng WiFi (SSID)</label>"
        "<div class='input-box'>"
        "<input id='ssid' name='ssid' maxlength='32' required autocomplete='off' "
        "placeholder=\"Chạm 'Tìm' hoặc tự nhập tên\">"
        "<button type='button' class='btn-inline-scan' id='scanBtn'>"
        "<span class='spin' id='scanSpin'></span><span id='scanTxt'>🔍 Tìm</span>"
        "</button></div>"
        "<div class='wifi-dropdown' id='wifiDropdown'></div></div>"
    );
    html += (
        "<div class='field'><label for='pass'>Mật khẩu WiFi</label>"
        "<div class='input-box'>"
        "<input id='pass' name='pass' type='password' maxlength='64' "
        "placeholder='Để trống nếu là mạng mở'>"
        "<button type='button' class='btn-pw-toggle' data-for='pass'>HIỆN</button>"
        "</div></div>"
    );

    html += ("<div class='group-title'>2. MQTT Broker (Home Assistant)</div>");
    html += ("<div class='field'><label>Địa chỉ Broker (Host/IP)</label>"
               "<input name='mqtt_host' maxlength='64' value='") + mqttHost +
            ("' placeholder='vd: 192.168.1.10 hoặc homeassistant.local'></div>");
    html += ("<div class='field'><label>Cổng (Port)</label>"
               "<input name='mqtt_port' type='number' value='") + String(mqttPort) +
            ("'></div>");
    html += ("<div class='field'><label>Tài khoản MQTT (User)</label>"
               "<input name='mqtt_user' maxlength='32' value='") + mqttUser +
            ("' placeholder='Tùy chọn'></div>");
    html += (
        "<div class='field'><label>Mật khẩu MQTT</label>"
        "<div class='input-box'>"
        "<input id='mqtt_pass' name='mqtt_pass' type='password' maxlength='64' placeholder='Tùy chọn'>"
        "<button type='button' class='btn-pw-toggle' data-for='mqtt_pass'>HIỆN</button>"
        "</div></div>"
    );

    html += ("<div class='group-title'>3. Chế độ hoạt động</div>");
    html += ("<div class='field'><div class='mode-options' id='modeOptions'>");
    for (int i = 0; i < (int)MODE_COUNT; i++) {
        OperatingMode mi = (OperatingMode)i;
        html += "<label class='mode-opt'><input type='radio' name='mode' value='" + String(i) + "'";
        if (operatingMode == mi) html += " checked";
        html += "> " + String(modeLabel(mi)) + "</label>";
    }
    html += ("</div></div>");

    html += ("<div class='group-title'>4. Tên hiển thị màn hình (theo chế độ đang chọn)</div>");
    html += ("<div class='title-cards' id='titleGroupNormal'"
             + String(operatingMode == MODE_NGAYDEM ? " style='display:none'" : "") + ">");
    html += "<div class='title-card'><label for='title_ct1'>Màn hình 1</label>"
            "<input id='title_ct1' name='title_ct1' maxlength='24' value='" + String(titleCT1()) + "'></div>";
    html += "<div class='title-card'><label for='title_ct2'>Màn hình 2</label>"
            "<input id='title_ct2' name='title_ct2' maxlength='24' value='" + String(titleCT2()) + "'></div>";
    html += "<div class='title-card'><label for='title_total'>Màn hình tổng</label>"
            "<input id='title_total' name='title_total' maxlength='24' value='" + String(titleTotal()) + "'></div>";
    html += ("</div>");

    html += ("<div class='title-cards' id='titleGroupNgd'"
             + String(operatingMode != MODE_NGAYDEM ? " style='display:none'" : "") + ">");
    html += "<div class='title-card'><label for='title_ngd_setting'>Cài đặt thời gian</label>"
            "<input id='title_ngd_setting' name='title_ngd_setting' maxlength='24' value='" + String(titleNgdSetting()) + "'></div>";
    html += "<div class='title-card'><label for='title_ngd_p1'>Thông số 1</label>"
            "<input id='title_ngd_p1' name='title_ngd_p1' maxlength='24' value='" + String(titleNgdP1()) + "'></div>";
    html += "<div class='title-card'><label for='title_ngd_p2'>Thông số 2</label>"
            "<input id='title_ngd_p2' name='title_ngd_p2' maxlength='24' value='" + String(titleNgdP2()) + "'></div>";
    html += "<div class='title-card'><label for='title_ngd_p3'>Thông số 3</label>"
            "<input id='title_ngd_p3' name='title_ngd_p3' maxlength='24' value='" + String(titleNgdP3()) + "'></div>";
    html += ("</div>");

    html += (
        "<button type='submit' class='btn-submit' id='saveBtn'>"
        "<span class='spin' id='saveSpin'></span><span id='saveTxt'>Lưu &amp; Kết Nối</span>"
        "</button></form>"
    );
    html += ("<footer>") + deviceId + (" &bull; ") + deviceType + ("</footer>");
    html += ("</div>");   // .app-container

    // ─── Dữ liệu tên hiển thị (đã tùy chỉnh hoặc mặc định) của cả 4 chế độ,
    // dùng để JS đổi nội dung các card khi người dùng chọn chế độ khác ────────
    String modeTitlesJs = "{";
    for (int i = 0; i < (int)MODE_COUNT; i++) {
        OperatingMode mi = (OperatingMode)i;
        const char* ct1 = customTitleCT1[i].length()   ? customTitleCT1[i].c_str()   : defaultTitleCT1(mi);
        const char* ct2 = customTitleCT2[i].length()   ? customTitleCT2[i].c_str()   : defaultTitleCT2(mi);
        const char* tot = customTitleTotal[i].length() ? customTitleTotal[i].c_str() : defaultTitleTotal(mi);
        if (i) modeTitlesJs += ",";
        modeTitlesJs += String(i) + ":{ct1:\"" + escapeJson(String(ct1)) + "\","
                        "ct2:\"" + escapeJson(String(ct2)) + "\","
                        "total:\"" + escapeJson(String(tot)) + "\"}";
    }
    modeTitlesJs += "}";

    // Tên 4 màn hình của riêng chế độ "Ngày & Đêm" (không phụ thuộc mode index)
    String ngdTitlesJs = "{setting:\"" + escapeJson(String(titleNgdSetting())) + "\","
                          "p1:\"" + escapeJson(String(titleNgdP1())) + "\","
                          "p2:\"" + escapeJson(String(titleNgdP2())) + "\","
                          "p3:\"" + escapeJson(String(titleNgdP3())) + "\"}";

    // ─── JS: quét WiFi thật qua /scan, dropdown, hiện/ẩn mật khẩu, trạng thái lưu ───
    html += (
        "<script>"
        "var modeTitles=" + modeTitlesJs + ";"
        "var ngdTitles=" + ngdTitlesJs + ";"
        "var NGD_MODE=" + String((int)MODE_NGAYDEM) + ";"
        "document.querySelectorAll('#modeOptions input[name=mode]').forEach(function(r){"
          "r.addEventListener('change',function(){"
            "var isNgd=(this.value==NGD_MODE);"
            "document.getElementById('titleGroupNormal').style.display=isNgd?'none':'';"
            "document.getElementById('titleGroupNgd').style.display=isNgd?'':'none';"
            "if(isNgd){"
              "document.getElementById('title_ngd_setting').value=ngdTitles.setting;"
              "document.getElementById('title_ngd_p1').value=ngdTitles.p1;"
              "document.getElementById('title_ngd_p2').value=ngdTitles.p2;"
              "document.getElementById('title_ngd_p3').value=ngdTitles.p3;"
            "}else{"
              "var t=modeTitles[this.value];"
              "if(!t)return;"
              "document.getElementById('title_ct1').value=t.ct1;"
              "document.getElementById('title_ct2').value=t.ct2;"
              "document.getElementById('title_total').value=t.total;"
            "}"
          "});"
        "});"
        "function renderSignal(rssi){"
          "var lvl=1;"
          "if(rssi>=-60)lvl=4;else if(rssi>=-70)lvl=3;else if(rssi>=-80)lvl=2;"
          "return '<div class=\"wifi-signal level-'+lvl+'\"><span></span><span></span><span></span><span></span></div>';"
        "}"
        "function scanWifi(){"
          "var spin=document.getElementById('scanSpin');"
          "var txt=document.getElementById('scanTxt');"
          "var btn=document.getElementById('scanBtn');"
          "var dropdown=document.getElementById('wifiDropdown');"
          "btn.disabled=true;spin.className='spin active';txt.textContent='';"
          "fetch('/scan').then(function(r){return r.json();}).then(function(nets){"
            "btn.disabled=false;spin.className='spin';txt.textContent='🔍 Tìm';"
            "dropdown.innerHTML='';"
            "if(!nets.length){"
              "dropdown.innerHTML='<div class=\"wifi-msg\">Không thấy mạng nào. Bấm Tìm lại.</div>';"
            "}else{"
              "nets.forEach(function(net){"
                "var item=document.createElement('div');item.className='wifi-item';"
                "item.innerHTML='<span class=\"wifi-name\">'+net.ssid+(net.secure?' 🔒':'')+'</span>'+renderSignal(net.rssi);"
                "item.onclick=function(){"
                  "document.getElementById('ssid').value=net.ssid;"
                  "dropdown.classList.remove('show');"
                  "if(net.secure)document.getElementById('pass').focus();"
                "};"
                "dropdown.appendChild(item);"
              "});"
            "}"
            "dropdown.classList.add('show');"
          "}).catch(function(){"
            "btn.disabled=false;spin.className='spin';txt.textContent='🔍 Tìm';"
            "dropdown.innerHTML='<div class=\"wifi-msg err\">Quét thất bại, thử lại.</div>';"
            "dropdown.classList.add('show');"
          "});"
        "}"
        "document.getElementById('scanBtn').addEventListener('click',scanWifi);"
        "window.addEventListener('load',scanWifi);"
        "document.addEventListener('click',function(e){"
          "var dropdown=document.getElementById('wifiDropdown');"
          "var scanBtn=document.getElementById('scanBtn');"
          "if(!dropdown.contains(e.target)&&!scanBtn.contains(e.target)){"
            "dropdown.classList.remove('show');"
          "}"
        "});"
        "document.querySelectorAll('.btn-pw-toggle').forEach(function(btn){"
          "btn.addEventListener('click',function(){"
            "var input=document.getElementById(this.getAttribute('data-for'));"
            "var isPw=input.type==='password';"
            "input.type=isPw?'text':'password';"
            "this.textContent=isPw?'ẨN':'HIỆN';"
          "});"
        "});"
        "document.getElementById('cfgForm').addEventListener('submit',function(){"
          "document.getElementById('saveBtn').disabled=true;"
          "document.getElementById('saveSpin').className='spin active';"
          "document.getElementById('saveTxt').textContent='Đang lưu...';"
        "});"
        "</script>"
    );

    html += ("</body></html>");
    return html;
}

static void handleRoot() {
    server.send(200, "text/html; charset=utf-8", buildConfigPage());
}

// Bắt các domain lạ (captive portal detection của điện thoại) → điều hướng về trang cấu hình
static void handleNotFound() {
    handleRoot();
}

// ═══════════════════════════════════════════════════════════
// QUÉT WIFI GẦN ĐÓ — trả về danh sách JSON cho trang cấu hình
// ═══════════════════════════════════════════════════════════
static String escapeJson(const String &s) {
    String out;
    out.reserve(s.length() + 4);
    for (size_t i = 0; i < s.length(); i++) {
        char c = s[i];
        if (c == '"' || c == '\\') { out += '\\'; out += c; }
        else if ((unsigned char)c >= 0x20) { out += c; }   // bỏ ký tự điều khiển
    }
    return out;
}

struct WifiNet {
    String  ssid;
    int32_t rssi;
    bool    secure;
};

static void handleScan() {
    int n = WiFi.scanNetworks(false, true);   // đồng bộ, kể cả AP ẩn

    std::vector<WifiNet> nets;
    nets.reserve(n > 0 ? n : 0);
    for (int i = 0; i < n; i++) {
        String ssid = WiFi.SSID(i);
        if (ssid.length() == 0) continue;   // bỏ mạng ẩn không có tên
        int32_t rssi   = WiFi.RSSI(i);
        bool    secure = (WiFi.encryptionType(i) != WIFI_AUTH_OPEN);

        bool merged = false;
        for (auto &net : nets) {
            if (net.ssid == ssid) {          // cùng SSID (nhiều AP) → giữ tín hiệu mạnh nhất
                if (rssi > net.rssi) { net.rssi = rssi; net.secure = secure; }
                merged = true;
                break;
            }
        }
        if (!merged) nets.push_back({ ssid, rssi, secure });
    }
    std::sort(nets.begin(), nets.end(),
              [](const WifiNet &a, const WifiNet &b) { return a.rssi > b.rssi; });

    String json;
    json.reserve(64 + nets.size() * 48);
    json += "[";
    for (size_t i = 0; i < nets.size(); i++) {
        if (i) json += ",";
        json += "{\"ssid\":\"" + escapeJson(nets[i].ssid) + "\","
                "\"rssi\":" + String(nets[i].rssi) + ","
                "\"secure\":" + (nets[i].secure ? "true" : "false") + "}";
    }
    json += "]";
    WiFi.scanDelete();

    server.send(200, "application/json; charset=utf-8", json);
}

// ─── HTML shell dùng chung cho các trang thông báo nhỏ ──────
static String pageShell(const String &body) {
    return String((
        "<!DOCTYPE html><html lang='vi'><head><meta charset='utf-8'>"
        "<meta name='viewport' content='width=device-width,initial-scale=1'>"
        "<style>"
        "body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;"
        "font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;"
        "background:radial-gradient(circle at 50% -10%,#1b2740 0%,#0b0f17 55%);"
        "color:#e8ecf3;padding:16px;}"
        ".card{max-width:380px;width:100%;background:#161d2b;border:1px solid #2a3346;"
        "border-radius:18px;padding:28px 22px;text-align:center;"
        "box-shadow:0 20px 50px -20px rgba(0,0,0,.6);}"
        ".ic{font-size:36px;margin-bottom:10px;}"
        "h3{margin:0 0 8px;font-size:17px;}"
        "p{margin:0 0 6px;font-size:13.5px;color:#8b95a8;line-height:1.6;}"
        ".hint{margin-top:10px;font-size:12px;color:#57607a;}"
        "a.btn{display:inline-block;margin-top:18px;padding:11px 26px;border-radius:10px;"
        "background:#2f81f7;color:#fff;text-decoration:none;font-size:14px;font-weight:600;}"
        ".spin{width:22px;height:22px;margin:16px auto 0;border-radius:50%;"
        "border:3px solid rgba(255,255,255,.15);border-top-color:#2f81f7;"
        "animation:spin .8s linear infinite;}"
        "@keyframes spin{to{transform:rotate(360deg);}}"
        "</style></head><body><div class='card'>"
    )) + body + ("</div></body></html>");
}

// Tìm kênh (channel) hiện tại của SSID mục tiêu bằng cách quét lại — dùng để
// đồng bộ kênh AP TRƯỚC khi gọi WiFi.begin(), tránh việc module tự đổi kênh
// AP giữa chừng làm rớt liên kết của điện thoại (xem giải thích ở khối
// ConnectState phía trên). Trả về 0 nếu không quét thấy (khi đó cứ để
// WiFi.begin() tự xử lý như bình thường).
static int findChannelForSsid(const String &ssid) {
    int n = WiFi.scanNetworks(false, true);
    int bestCh = 0;
    int32_t bestRssi = -1000;
    for (int i = 0; i < n; i++) {
        if (WiFi.SSID(i) == ssid) {
            int32_t rssi = WiFi.RSSI(i);
            if (rssi > bestRssi) { bestRssi = rssi; bestCh = WiFi.channel(i); }
        }
    }
    WiFi.scanDelete();
    return bestCh;
}

// Trang "Đang kết nối..." — trả về NGAY LẬP TỨC khi bấm Lưu (đóng request cũ
// một cách an toàn), sau đó tự poll GET /status (mỗi lần là 1 request TCP
// mới, độc lập với request /save đã đóng) để cập nhật tiến độ thật.
static String buildConnectingPage(const String &ssid) {
    String body =
        String(("<div class='ic' id='icon'>📡</div>"
        "<h3 id='title'>Đang kết nối WiFi...</h3>"
        "<p>Đang thử kết nối tới <b style='color:#e8ecf3'>")) + ssid +
        ("</b></p>"
        "<div class='spin' id='spin'></div>"
        "<p class='hint' id='hint'>Đừng tắt nguồn hoặc rời khỏi trang này.</p>"
        "<div id='result' style='display:none;margin-top:4px'>"
          "<a class='btn' href='/'>Nhập lại cấu hình</a>"
        "</div>");

    String page = pageShell(body);
    String script = String((
        "<script>"
        "function poll(){"
          "fetch('/status').then(function(r){return r.json();}).then(function(d){"
            "if(d.state==='connected'){"
              "document.getElementById('icon').textContent='✅';"
              "var t=document.getElementById('title');"
              "t.textContent='Kết nối thành công!';t.style.color='#3fb950';"
              "document.getElementById('hint').textContent="
                "'Thiết bị đang khởi động lại để áp dụng cấu hình...';"
            "}else if(d.state==='failed'){"
              "document.getElementById('spin').style.display='none';"
              "document.getElementById('icon').textContent='❌';"
              "var t2=document.getElementById('title');"
              "t2.textContent='Không kết nối được WiFi';t2.style.color='#f85149';"
              "document.getElementById('hint').textContent="
                "'Sai mật khẩu hoặc không thấy mạng. AP cấu hình vẫn đang bật, kiểm tra lại và thử lại.';"
              "document.getElementById('result').style.display='block';"
            "}else{"
              "setTimeout(poll,1000);"
            "}"
          "}).catch(function(){ setTimeout(poll,1500); });"
        "}"
        "setTimeout(poll,600);"
        "</script></body></html>"
    ));
    page.replace("</body></html>", script);
    return page;
}

static void handleStatus() {
    String state;
    switch (connState) {
        case ConnectState::CONNECTED:  state = "connected";  break;
        case ConnectState::FAILED:     state = "failed";     break;
        case ConnectState::IDLE:       state = "idle";       break;
        default:                       state = "connecting"; break;   // PENDING_START, CONNECTING
    }
    String json = String("{\"state\":\"") + state + "\"}";
    server.send(200, "application/json; charset=utf-8", json);
}

static void handleSave() {
    String ssid     = server.arg("ssid");
    String pass     = server.arg("pass");
    String mHost    = server.arg("mqtt_host");
    String mPortStr = server.arg("mqtt_port");
    String mUser    = server.arg("mqtt_user");
    String mPass    = server.arg("mqtt_pass");
    String modeStr  = server.arg("mode");
    String tCt1     = server.arg("title_ct1");
    String tCt2     = server.arg("title_ct2");
    String tTotal   = server.arg("title_total");
    String tNgdSet  = server.arg("title_ngd_setting");
    String tNgdP1   = server.arg("title_ngd_p1");
    String tNgdP2   = server.arg("title_ngd_p2");
    String tNgdP3   = server.arg("title_ngd_p3");

    // ── Chế độ hoạt động + tên hiển thị 3 màn hình ───────────
    // Áp dụng và lưu ngay (không phụ thuộc WiFi kết nối thành công hay
    // không), vì đây là cấu hình độc lập với WiFi/MQTT.
    OperatingMode prevMode = operatingMode;
    int modeInt = modeStr.toInt();
    if (modeStr.length() > 0 && modeInt >= 0 && modeInt < (int)MODE_COUNT) {
        operatingMode = (OperatingMode)modeInt;
    }
    bool modeChanged = (operatingMode != prevMode);
    tCt1.trim();
    tCt2.trim();
    tTotal.trim();
    // Nếu người dùng không sửa (giữ nguyên tên mặc định) hoặc để trống →
    // dùng tên mặc định như cũ (lưu chuỗi rỗng = "chưa tùy chỉnh").
    customTitleCT1[operatingMode] =
        (tCt1.length() == 0 || tCt1 == String(defaultTitleCT1(operatingMode))) ? "" : tCt1;
    customTitleCT2[operatingMode] =
        (tCt2.length() == 0 || tCt2 == String(defaultTitleCT2(operatingMode))) ? "" : tCt2;
    customTitleTotal[operatingMode] =
        (tTotal.length() == 0 || tTotal == String(defaultTitleTotal(operatingMode))) ? "" : tTotal;

    // ── Tên hiển thị 4 màn hình con của chế độ "Ngày & Đêm" ──
    tNgdSet.trim();
    tNgdP1.trim();
    tNgdP2.trim();
    tNgdP3.trim();
    customTitleNgdSetting = (tNgdSet.length() == 0 || tNgdSet == String(defaultTitleNgdSetting())) ? "" : tNgdSet;
    customTitleNgdP1      = (tNgdP1.length()  == 0 || tNgdP1  == String(defaultTitleNgdP1()))      ? "" : tNgdP1;
    customTitleNgdP2      = (tNgdP2.length()  == 0 || tNgdP2  == String(defaultTitleNgdP2()))      ? "" : tNgdP2;
    customTitleNgdP3      = (tNgdP3.length()  == 0 || tNgdP3  == String(defaultTitleNgdP3()))      ? "" : tNgdP3;

    // Đổi sang chế độ khác (qua Web Server) → xóa hết dữ liệu đã lưu của
    // mọi chế độ, giống hệt hành vi khi đổi chế độ bằng nút bấm trên màn
    // hình LCD (KHÔNG đụng tới cấu hình mạng WiFi/MQTT).
    if (modeChanged) {
        resetAllData();   // tự gọi savePrefs() bên trong
        addLog(("[OK] Portal: Đổi chế độ → " + String(modeLabel(operatingMode))).c_str());
    }

    savePrefs();
    //addLog("[OK] Portal: Đã lưu chế độ + tên hiển thị màn hình");

    // ── Kiểm tra SSID rỗng ───────────────────────────────────
    if (ssid.length() == 0) {
        server.send(400, "text/html; charset=utf-8", pageShell(
            "<div class='ic'>⚠️</div>"
            "<h3 style='color:#f85149'>Thiếu thông tin</h3>"
            "<p>Vui lòng nhập tên WiFi (SSID) trước khi lưu.</p>"
            "<a class='btn' href='/'>Quay lại</a>"
        ));
        return;
    }

    mHost.trim();
    if (mHost.length() == 0) mHost = "broker.hivemq.com";   // fallback mặc định
    int mPort = mPortStr.toInt();
    if (mPort <= 0) mPort = 1883;

    // ── KHÔNG gọi WiFi.begin() và KHÔNG chờ (block) ở đây nữa ────────────
    // Chỉ lưu tạm dữ liệu vào biến pending* rồi trả response ngay lập tức để
    // đóng an toàn request /save hiện tại. Việc đồng bộ kênh AP + kết nối
    // WiFi thật sự sẽ diễn ra sau, trong loop() (xem handleWifiPortal()) —
    // tách rời khỏi request này nên không còn nguy cơ "trang web bị sập"
    // nếu ESP32 phải đổi kênh AP giữa chừng.
    pendingSsid  = ssid;
    pendingPass  = pass;
    pendingMHost = mHost;
    pendingMPort = mPort;
    pendingMUser = mUser;
    pendingMPass = mPass;
    connState      = ConnectState::PENDING_START;
    connectStartAt = millis() + CONNECT_START_DELAY_MS;

    server.send(200, "text/html; charset=utf-8", buildConnectingPage(ssid));
}

// ═══════════════════════════════════════════════════════════
// START / STOP PORTAL
// ═══════════════════════════════════════════════════════════
void startWifiPortal() {
    if (wifiPortalActive) return;

    WiFi.mode(WIFI_AP_STA);   // AP_STA để vừa phát AP vừa quét WiFi xung quanh được
    apName = deviceId + "_Config";
    WiFi.softAP(apName.c_str(), WIFI_PORTAL_AP_PASS);

    IPAddress apIP = WiFi.softAPIP();
    dnsServer.start(WIFI_PORTAL_DNS_PORT, "*", apIP);

    server.on("/", HTTP_GET, handleRoot);
    server.on("/scan", HTTP_GET, handleScan);
    server.on("/save", HTTP_POST, handleSave);
    server.on("/status", HTTP_GET, handleStatus);
    server.onNotFound(handleNotFound);
    server.begin();

    wifiPortalActive = true;
    Serial.printf("[Portal] AP: %s (pass: %s), IP: %s\n",
                   apName.c_str(), WIFI_PORTAL_AP_PASS, apIP.toString().c_str());
    addLog("[OK] Portal: Đang phát AP cấu hình WiFi");
}

void stopWifiPortal() {
    if (!wifiPortalActive) return;

    server.stop();
    dnsServer.stop();
    WiFi.softAPdisconnect(true);
    wifiPortalActive = false;
    Serial.println("[Portal] Đã tắt AP cấu hình.");
    addLog("[OK] Portal: Đã tắt");
}

// ═══════════════════════════════════════════════════════════
// XỬ LÝ TRONG loop()
// ═══════════════════════════════════════════════════════════
void handleWifiPortal() {
    if (!wifiPortalActive) return;
    dnsServer.processNextRequest();
    server.handleClient();

    // ── Tiếp tục máy trạng thái kết nối WiFi (bất đồng bộ, không block) ──
    switch (connState) {
    case ConnectState::PENDING_START:
        if ((long)(millis() - connectStartAt) >= 0) {
            // Đồng bộ kênh AP với kênh của router thật (nếu quét thấy) TRƯỚC
            // khi gọi WiFi.begin(), để ESP32 không phải tự đổi kênh AP giữa
            // chừng — chính là nguyên nhân làm rớt liên kết điện thoại trước
            // đây. Việc quét này có thể mất 1-2s và tạm không bơm server/dns
            // trong lúc đó — giống hệt cơ chế /scan sẵn có trong code, không
            // phải là điều mới, và không còn liên quan gì tới request /save
            // (đã đóng từ trước) nên không gây "sập trang" nữa.
            int ch = findChannelForSsid(pendingSsid);
            if (ch > 0) {
                WiFi.softAP(apName.c_str(), WIFI_PORTAL_AP_PASS, ch);
            }
            WiFi.disconnect(false);                          // chỉ ngắt STA cũ, giữ nguyên AP
            WiFi.begin(pendingSsid.c_str(), pendingPass.c_str());
            connectDeadline = millis() + CONNECT_TIMEOUT_MS;
            connState = ConnectState::CONNECTING;
        }
        break;

    case ConnectState::CONNECTING:
        if (WiFi.status() == WL_CONNECTED) {
            wifiSSID       = pendingSsid;
            wifiPASS       = pendingPass;
            mqttHost       = pendingMHost;
            mqttPort       = pendingMPort;
            mqttUser       = pendingMUser;
            mqttPass       = pendingMPass;
            wifiConfigured = true;
            savePrefs();
            //addLog("[OK] Portal: Đã lưu cấu hình WiFi + MQTT — đang restart");
            connState = ConnectState::CONNECTED;
            restartAt = millis() + RESTART_DELAY_MS;   // đợi client kịp poll thấy "connected"
        } else if ((long)(millis() - connectDeadline) >= 0) {
            WiFi.disconnect(true);   // chỉ dừng STA, AP không hề bị đụng tới
            addLog("[ERR] Portal: Kết nối WiFi thất bại");
            connState = ConnectState::FAILED;
        }
        break;

    case ConnectState::CONNECTED:
        if (restartAt && (long)(millis() - restartAt) >= 0) {
            ESP.restart();
        }
        break;

    default:
        break;   // IDLE, FAILED — không làm gì, chờ người dùng thử lại từ '/'
    }
}