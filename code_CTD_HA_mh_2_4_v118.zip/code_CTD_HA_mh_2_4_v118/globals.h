#pragma once

/*
 * ============================================================
 * ĐỒNG HỒ ĐIỆN KÉP - PZEM-004T v3.0 x2 + DS1307 + ST7789
 * v7 - LVGL v8.3.8 + TFT_eSPI + Web AP Cấu hình + MQTT (Home Assistant)
 * Font tiengviet, tiếng Việt có dấu, WiFi symbol LVGL
 * ============================================================
 */

#include <SPI.h>
#include <Wire.h>
#include <FS.h>
#include <lvgl.h>
#include <TFT_eSPI.h>
#include <PZEM004Tv30.h>
#include <RTClib.h>
#include <Preferences.h>
#include <WiFi.h>
#include <time.h>

// ── PINS ─────────────────────────────────────────────────────
#define PIN_TFT_BLK   23
#define PIN_BTN_OK     4
#define PIN_BTN_NEXT  15
#define PIN_LED        2
#define PIN_RTC_SDA   21
#define PIN_RTC_SCL   22
#define PIN_PZ1_TX    27
#define PIN_PZ1_RX    14
#define PIN_PZ2_TX    25
#define PIN_PZ2_RX    26

// ── NTP ──────────────────────────────────────────────────────
#define NTP_SERVER1   "pool.ntp.org"
#define NTP_SERVER2   "time.google.com"
#define NTP_TZ_OFFSET 7 * 3600
#define NTP_DST       0
#define NTP_SYNC_MS   (3600UL * 1000UL)

// ── DISPLAY ──────────────────────────────────────────────────
// Màn hình 2.4" ST7789, độ phân giải 240x320, xoay ngang (rotation 1) → 320x240
#define SCR_W   320
#define SCR_H   240
#define TITLE_H  30

// ── LVGL BUFFER ──────────────────────────────────────────────
#define LV_BUF_LINES 8

// ── LVGL COLORS ──────────────────────────────────────────────
#define LV_C_BG       lv_color_make(0,   0,   0)
#define LV_C_TITLE    lv_color_make(0,   255, 255)
#define LV_C_TEXT     lv_color_make(255, 255, 255)
#define LV_C_VAL      lv_color_make(255, 255, 0)
#define LV_C_GREEN    lv_color_make(0,   252, 0)
#define LV_C_RED      lv_color_make(255, 0,   0)
#define LV_C_ORANGE   lv_color_make(255, 164, 0)
#define LV_C_GRAY     lv_color_make(123, 125, 123)
#define LV_C_BLUE     lv_color_make(0,   68,  248)
#define LV_C_HILIGHT  lv_color_make(0,   86,  108)

// ── BUTTONS ──────────────────────────────────────────────────
#define DEBOUNCE_MS   50
#define HOLD_MS     5000

// ── TIMING ───────────────────────────────────────────────────
#define PZ_MS    2000
#define DISP_MS  1000

// ── NHẬT KÝ LỖI ──────────────────────────────────────────────
#define LOG_MAX     20
#define LOG_LINELEN 60

// ── PZEM ─────────────────────────────────────────────────────
#define PZ_FAIL_THRESH 5

// ── RTC ──────────────────────────────────────────────────────
#define RTC_RETRY_MS  30000UL

// ── SETTINGS ─────────────────────────────────────────────────
#define SETTINGS_ROWS 8

// ── MÀN HÌNH "THÁNG X" ───────────────────────────────────────
// Màn hình 320x240 cao hơn nên hiển thị được nhiều hàng hơn cùng lúc.
#define DAYHIST_ROWS_VISIBLE 8   // số hàng hiển thị cùng lúc, cuộn bằng NEXT

// ── FONT TOÀN CỤC ────────────────────────────────────────────
// Màn hình lớn (240x320)
LV_FONT_DECLARE(lv_font_tiengviet_16);
LV_FONT_DECLARE(lv_font_tiengviet_12);
LV_FONT_DECLARE(lv_font_tiengviet_10);
LV_FONT_DECLARE(lv_font_symbol_14);

extern const lv_font_t *FONT_NORMAL;
extern const lv_font_t *FONT_LOG;
extern const lv_font_t *FONT_SMALL;

// ── PZEM DATA ─────────────────────────────────────────────────
struct PZReading {
    float volt, amp, watt, kwh, hz, pf;
    bool  ok;
};

// ── NHẬT KÝ ──────────────────────────────────────────────────
struct LogEntry {
    char msg[LOG_LINELEN];
    char ts[10];
};

// ── SCREENS ──────────────────────────────────────────────────
// "Tháng X" / "Biểu đồ năm Y" / "Thống kê tháng X-1" không còn là màn
// hình cấp cao nhất — chúng nằm bên trong màn hình "Tổng" (xem
// inTotalDetail / totalDetailIndex bên dưới).
enum ScreenID { SCR_CT1 = 0, SCR_CT2, SCR_TOTAL, SCR_COUNT };

// ── OPERATING MODE ────────────────────────────────────────────
enum OperatingMode { MODE_SUM = 0, MODE_DIFF = 1, MODE_NLMT = 2, MODE_NGAYDEM = 3, MODE_COUNT = 4 };
extern OperatingMode operatingMode;

extern bool inModeSelect;
extern int  modeSelectRow;

// ── TÊN TIÊU ĐỀ MÀN HÌNH TÙY CHỈNH (nhập từ Web Server) ───────
// Mỗi chế độ (MODE_SUM/MODE_DIFF/MODE_NLMT) có 1 bộ tên riêng cho 3 màn
// hình. Chuỗi rỗng ("") = chưa tùy chỉnh → dùng tên mặc định theo chế độ.
// (Chế độ MODE_NGAYDEM không dùng 3 biến này — xem bộ tên riêng 4 màn
// hình của nó ở phần "CHẾ ĐỘ NGÀY & ĐÊM" bên dưới.)
extern String customTitleCT1[MODE_COUNT];
extern String customTitleCT2[MODE_COUNT];
extern String customTitleTotal[MODE_COUNT];

// ═════════════════════════════════════════════════════════════
// CHẾ ĐỘ "NGÀY & ĐÊM" (MODE_NGAYDEM)
// Chỉ dùng PZEM1. Theo dõi kWh tích lũy (không reset ngày/tháng) trong
// 1 khung thời gian TGBĐ → TGKT do người dùng cấu hình, tách riêng
// sản lượng "ban ngày" (06:00-18:00) và "ban đêm" (18:00-06:00).
// Biến của chế độ này hoàn toàn tách biệt để tránh xung đột dữ liệu
// với các chế độ MODE_SUM/MODE_DIFF/MODE_NLMT ở trên.
// ═════════════════════════════════════════════════════════════
#define NGD_DAY_START_HOUR 6    // Ban ngày: [6h, 18h)
#define NGD_DAY_END_HOUR   18   // Ban đêm : [18h, 6h hôm sau)

// 4 màn hình con của chế độ Ngày & Đêm — chuyển bằng NEXT (khi đang
// chạy/đã kết thúc), lặp vòng tròn.
enum NgayDemScreen { NGD_SCR_SETTING = 0, NGD_SCR_P1, NGD_SCR_P2, NGD_SCR_P3, NGD_SCR_COUNT };
extern int ngdScreenIndex;

// Trạng thái quá trình ghi dữ liệu của chế độ Ngày & Đêm
enum NgayDemStatus { NGD_CHUA_CAUHINH = 0, NGD_CHO_BATDAU = 1, NGD_DANG_CHAY = 2, NGD_DA_KETTHUC = 3 };
extern NgayDemStatus ngdStatus;

// ── Cấu hình TGBĐ (đang chỉnh, dùng khi ngdStatus == NGD_CHUA_CAUHINH) ──
extern int ngdCfgYear, ngdCfgMonth, ngdCfgDay, ngdCfgHour, ngdCfgMinute;
extern int ngdSoNgay;             // Số ngày cấu hình (1-99)

// Con trỏ + trạng thái chỉnh sửa của màn hình "Cài đặt thời gian"
// ngdCursorPos: 0=Giờ,1=Phút,2=Ngày,3=Tháng,4=Năm (của TGBĐ), 5=Số ngày
extern int  ngdCursorPos;
extern bool ngdEditing;           // true = đang ở bước tăng/giảm giá trị (đã nhấn OK chọn field)

// ── TGBĐ/TGKT đã LƯU (dùng khi ngdStatus != NGD_CHUA_CAUHINH) ─────────
extern uint32_t ngdStartEpoch;    // TGBĐ đã lưu (unixtime theo giờ nội bộ RTC/NTP)
extern uint32_t ngdEndEpoch;      // TGKT = TGBĐ + Số ngày (tự tính, chỉ hiển thị)

// ── Dữ liệu tích lũy trong suốt quá trình chạy (KHÔNG reset theo
//    ngày/tháng — chỉ reset khi cấu hình lại) ──────────────────────────
extern float ngdKwhDay;           // kWh ban ngày (tích lũy)
extern float ngdKwhNight;         // kWh ban đêm (tích lũy)
extern float ngdEnergyStart;      // Mốc kWh lũy kế của PZEM1 lúc bắt đầu chạy
extern float ngdLastEnergy;       // Giá trị kWh PZEM1 đọc lần gần nhất (tính delta an toàn)

// ── Công suất Max/TB/Min (chỉ tính khi đang chạy) ─────────────────────
extern float    ngdPowerMax;
extern float    ngdPowerMin;
extern float    ngdPowerSum;      // Tổng cộng dồn công suất từng lần đọc — dùng tính trung bình
extern uint32_t ngdPowerSamples;

// ── Tên tiêu đề 4 màn hình con của chế độ Ngày & Đêm, tùy chỉnh qua
//    Web Server (rỗng = dùng tên mặc định) ────────────────────────────
extern String customTitleNgdSetting;
extern String customTitleNgdP1;
extern String customTitleNgdP2;
extern String customTitleNgdP3;

// ── EXTERN GLOBALS ────────────────────────────────────────────
extern TFT_eSPI tft;

extern HardwareSerial pzSerial1;
extern HardwareSerial pzSerial2;
extern PZEM004Tv30   pzSensor1;
extern PZEM004Tv30   pzSensor2;

extern RTC_DS1307 rtc;
extern bool rtcOK;
extern bool usingNTPTime;
extern unsigned long tRTCRetry;

extern Preferences prefs;

extern String wifiSSID;
extern String wifiPASS;
extern bool   wifiConnected;
extern bool   wifiConfigured;

// ── Cấu hình MQTT Broker (Home Assistant) — nhập qua Web AP ──
extern String mqttHost;
extern int    mqttPort;
extern String mqttUser;
extern String mqttPass;

// ── Web AP Portal screen flag ─────────────────────────────────
// true = đang hiển thị màn hình "Cấu hình WiFi" (AP đang phát sóng,
// chờ người dùng vào http://192.168.4.1 để cấu hình)
extern bool inWifiConfig;

extern unsigned long tLastNTP;
extern bool          ntpSynced;

extern LogEntry logBuf[LOG_MAX];
extern int      logCount;
extern bool     inLogView;
extern int      logScroll;

extern ScreenID currentScreen;
extern bool     inSettings;
extern int      settingsRow;

// ── Chế độ xem chi tiết bên trong màn hình "Tổng" ──────────────
// true = đang ở chế độ xem chi tiết (vào bằng cách nhấn OK 1 lần khi
// đang ở màn hình "Tổng", thoát ra cũng bằng cách nhấn OK 1 lần nữa).
// totalDetailIndex: 0 = "Tháng X", 1 = "Biểu đồ năm Y",
//                   2 = "Thống kê tháng X-1" — chuyển bằng nút NEXT,
//                   lặp lại vòng tròn.
extern bool inTotalDetail;
extern int  totalDetailIndex;

// ── Chế độ xem chi tiết bên trong "Công tơ 1" / "Công tơ 2" ────
// Y hệt cơ chế inTotalDetail/totalDetailIndex ở trên nhưng áp dụng
// riêng cho từng công tơ (Tháng X / Biểu đồ năm Y / Thống kê tháng X-1
// của riêng công tơ đó).
extern bool inCT1Detail;
extern int  ct1DetailIndex;
extern bool inCT2Detail;
extern int  ct2DetailIndex;

// ── Màn hình "Thông tin thiết bị" ──────────────────────────────
extern bool     inDeviceInfo;

extern PZReading rd1, rd2;

extern float kwhDay1, kwhDay2;
extern float kwhMonth1[12], kwhMonth2[12];
extern float chartData[12];
extern int   lastDay, lastMonth, lastYear;
extern float eStart1, eStart2;
extern float mStart1, mStart2;

extern int pz1FailCnt, pz2FailCnt;

extern unsigned long tOkDown;
extern unsigned long tNxDown;
extern bool prevOK;
extern bool prevNEXT;

extern unsigned long tLedToggle;
extern bool          ledState;

extern unsigned long tLastPZ;
extern unsigned long tLastDisp;

// ── kWh TỔNG/HIỆU (màn hình Total) ──────────────────────────
extern float kwhDayTotal;
extern float kwhMonTotal[12];
extern float chartDataTotal[12];

// ── LỊCH SỬ kWh THEO NGÀY TRONG THÁNG (màn hình "Tháng X") ──
// dayHistCurMonth[i]  = kWh (Tổng/Hiệu theo mode) của ngày (i+1) trong
//                       tháng đang chạy (dayHistCurMonthIdx/dayHistCurYear).
// Chỉ được ghi vào đúng thời điểm "chốt sổ" khi sang ngày mới —
// ngày hiện tại (đang chạy dở) KHÔNG hiển thị cho tới khi chốt sổ.
extern float dayHistCurMonth[31];
extern float dayHistPrevMonth[31];   // Lịch sử ngày của tháng liền trước
extern int   dayHistCurMonthIdx;     // Tháng (1-12) mà dayHistCurMonth đang lưu
extern int   dayHistCurYear;         // Năm tương ứng
extern int   dayHistPrevMonthIdx;    // Tháng (1-12) mà dayHistPrevMonth đang lưu
extern int   dayHistPrevYear;        // Năm tương ứng của tháng trước
extern bool  dayHistShowPrev;        // true = đang xem "Tháng X-1"
extern int   dayHistScroll;          // hàng đầu tiên đang hiển thị (cuộn bằng NEXT)

// ── LỊCH SỬ kWh THEO NGÀY CỦA TỪNG CÔNG TƠ RIÊNG (màn hình "Tháng X"
//    bên trong "Công tơ 1" / "Công tơ 2") — cùng tháng/năm với
//    dayHistCurMonthIdx/dayHistCurYear ở trên (dùng chung mốc tháng).
extern float dayHistCurMonth1[31];   // Công tơ 1
extern float dayHistCurMonth2[31];   // Công tơ 2

// ── LỊCH SỬ BIỂU ĐỒ NĂM TRƯỚC (màn hình "Biểu đồ") ──────────
extern float chartDataTotalPrev[12]; // Biểu đồ 12 tháng của năm liền trước
extern int   chartPrevYear;          // Năm mà chartDataTotalPrev đang lưu
extern bool  chartShowPrev;          // true = đang xem "Biểu đồ năm trước"

// ── SNAPSHOT kWh/THÁNG CỦA TỪNG CÔNG TƠ VÀO CUỐI NĂM ────────
// Dùng để tính "Thống kê tháng X-1" của Công tơ 1/2 khi tháng trước là
// tháng 12 của năm trước — lúc đó kwhMonth1[]/kwhMonth2[] hiện tại đã bị
// reset về 0 cho năm mới (tương tự chartDataTotalPrev[] ở trên, nhưng
// lưu riêng cho từng công tơ thay vì giá trị Tổng/Hiệu đã gộp).
extern float kwhMonth1Prev[12];
extern float kwhMonth2Prev[12];