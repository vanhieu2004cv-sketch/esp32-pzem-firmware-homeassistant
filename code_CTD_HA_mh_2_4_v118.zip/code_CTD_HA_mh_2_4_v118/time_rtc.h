#pragma once
#include <RTClib.h>

DateTime getTime();
void     syncNTP();
bool     applyNTPtoRTC();

// Số ngày trong 1 tháng (có tính năm nhuận cho tháng 2). month: 1-12.
int daysInMonth(int month, int year);
