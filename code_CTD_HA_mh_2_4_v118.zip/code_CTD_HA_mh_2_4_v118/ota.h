#pragma once
#include <stddef.h>

// Định nghĩa link raw chứa file cấu hình phiên bản JSON trên GitHub của bạn
#define OTA_JSON_URL "https://raw.githubusercontent.com/vanhieu2004cv-sketch/esp32-pzem-firmware-homeassistant/refs/heads/main/firmware-ha.json"

/*
  Cấu trúc file firmware-ha.json mẫu trên GitHub của bạn:
  {
    "version": "1.0.0",
    "url": "https://raw.githubusercontent.com/vanhieu2004cv-sketch/esp32-pzem-firmware-homeassistant/refs/heads/main/firmware-ha-100.bin"
  }
*/

// Phiên bản firmware hiện tại đang chạy trên máy
extern const char* CURRENT_FIRMWARE_VERSION;

// ── Báo tiến trình OTA ───────────────────────────────────────
// Các giai đoạn của quá trình cập nhật, dùng để hiển thị trạng thái lên màn hình
enum OtaStage {
    OTA_STAGE_DOWNLOADING,  // Đang tải...
    OTA_STAGE_WRITING,      // Đang ghi Flash...
    OTA_STAGE_RESTARTING    // Khởi động lại...
};

// Callback báo tiến trình: được gọi liên tục trong lúc tải + ghi flash
// stage: giai đoạn hiện tại; written/total: số byte đã tải / tổng số byte (dùng để tính % và KB)
typedef void (*OtaProgressCallback)(OtaStage stage, size_t written, size_t total);

bool checkNewUpdate();
bool performOTAUpdate(OtaProgressCallback onProgress = nullptr);

// Lấy thông tin phiên bản mới / dung lượng file .bin sau khi checkNewUpdate() trả về true
const char* getLatestVersionStr();
size_t      getUpdateSizeBytes();