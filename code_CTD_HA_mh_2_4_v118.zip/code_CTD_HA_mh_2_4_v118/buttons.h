#pragma once

void handleButtons();
void updateLED();
