/*
 * MQTT Client — PZEM Power Meter → Home Assistant (MQTT Discovery)
 *
 * Topics (Tasmota pattern, deviceId từ wifi_portal):
 *   tele/{id}/SENSOR   ← dữ liệu đo PZEM hiện tại (không retained, mỗi 2s)
 *   tele/{id}/STATE    ← heartbeat 5 phút (không retained)
 *   tele/{id}/LWT      ← trạng thái Online/Offline (retained, dùng làm
 *                         "availability_topic" cho mọi entity Home Assistant)
 *   stat/{id}/STATUS   ← trạng thái đầy đủ (retained)
 *
 * Khi kết nối MQTT thành công, thiết bị tự gửi các gói cấu hình
 * "homeassistant/sensor/.../config" (MQTT Auto Discovery) để Home
 * Assistant tự nhận diện thiết bị và tạo entity — không cần cấu hình
 * YAML thủ công. Chỉ gửi giá trị hiện tại/tích lũy (không gửi mảng lịch
 * sử ngày/tháng/năm) — Home Assistant tự lưu Long-Term Statistics và
 * tổng hợp báo cáo theo thời gian trên Energy Dashboard.
 */

#include "globals.h"
#include "log.h"
#include "wifi_portal.h"
#include "mqtt_client.h"
#include "mode.h"
#include "pzem.h"
#include "storage.h"
#include "time_rtc.h"
#include "ota.h"
#include "ngaydem.h"

#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <ESPmDNS.h>

static WiFiClient  wifiClient;
static PubSubClient mqtt(wifiClient);

bool mqttConnected = false;

// ─── Reconnect chạy trong task riêng (không chặn loop() chính) ──
// mqtt.connect() là hàm CHẶN: có thể treo rất lâu (DNS lookup của lwIP tự
// retry, TCP connect timeout, chờ CONNACK...) nếu broker/mDNS không phản
// hồi. Trước đây mqttReconnect() được gọi trực tiếp trong mqttLoop() (tức
// trong loop() chính) nên khi mất kết nối, toàn bộ loop() bị đứng theo —
// kể cả handleButtons() chạy sau đó — khiến máy "treo" không bấm được
// OK/NEXT. Nay việc reconnect được đưa ra chạy trong 1 task FreeRTOS
// riêng; loop() chính không đụng tới đối tượng mqtt/wifiClient trong lúc
// task đang chạy (xem cờ mqttReconnecting bên dưới) nên luôn phản hồi
// nút bấm bình thường dù kết nối mạng có bị treo bao lâu đi nữa.
static volatile bool mqttReconnecting = false;

// ─── mDNS ────────────────────────────────────────────────────
// Cho phép mqttHost là hostname dạng "ten-may.local" (thay vì chỉ IP tĩnh).
// Khi máy chạy Home Assistant đổi IP (DHCP cấp lại IP khác), thiết bị vẫn
// tự resolve lại tên mới nhất mỗi lần (re)connect thay vì lưu IP cũ.
static bool mdnsStarted = false;

static void ensureMDNS() {
    if (mdnsStarted) return;
    String mdnsName = deviceId.length() ? deviceId : String("esp32-ctd");
    if (MDNS.begin(mdnsName.c_str())) {
        mdnsStarted = true;
        Serial.printf("[MQTT] mDNS client khởi tạo OK (tên: %s)\n", mdnsName.c_str());
    } else {
        Serial.println("[MQTT] Lỗi khởi tạo mDNS client (không ảnh hưởng nếu mqttHost là IP tĩnh)");
    }
}

// Nếu mqttHost kết thúc bằng ".local", thử resolve trước và log ra IP tìm
// được — chỉ để chẩn đoán, không thay đổi hành vi kết nối (PubSubClient/
// WiFiClient tự resolve lại hostname khi gọi mqtt.connect()).
static void debugResolveMqttHost(const String& host) {
    if (!host.endsWith(".local")) return;
    ensureMDNS();
    String nameOnly = host.substring(0, host.length() - 6); // bỏ ".local"
    IPAddress resolvedIP = MDNS.queryHost(nameOnly.c_str(), 3000);
    if (resolvedIP.toString() == "0.0.0.0") {
        Serial.printf("[MQTT] [mDNS] Không resolve được '%s' — kiểm tra tên host hoặc "
                      "máy chạy HA có đang bật mDNS/Avahi không.\n", host.c_str());
    } else {
        Serial.printf("[MQTT] [mDNS] Resolve '%s' -> %s\n", host.c_str(), resolvedIP.toString().c_str());
    }
}

static String topicSensor;      // tele/{id}/SENSOR
static String topicStatus;      // stat/{id}/STATUS
static String topicTele;        // tele/{id}/STATE
static String topicLwt;         // tele/{id}/LWT  (availability, "Online"/"Offline")

static unsigned long lastHeartbeat = 0;
static unsigned long lastMqttTry   = 0;

// ─── BUILD TOPICS ────────────────────────────────────────────
static void buildTopics() {
    topicSensor = "tele/" + deviceId + "/SENSOR";
    topicStatus = "stat/" + deviceId + "/STATUS";
    topicTele   = "tele/" + deviceId + "/STATE";
    topicLwt    = "tele/" + deviceId + "/LWT";
}

// ═══════════════════════════════════════════════════════════
// SETUP
// ═══════════════════════════════════════════════════════════
void mqttSetup() {
    buildTopics();
    String host = mqttHost.length() ? mqttHost : String(MQTT_DEFAULT_HOST);
    int    port = mqttPort > 0 ? mqttPort : MQTT_DEFAULT_PORT;
    ensureMDNS();
    debugResolveMqttHost(host);
    mqtt.setServer(host.c_str(), port);
    // Đủ chỗ cho gói "SENSOR" lớn nhất (ct1+ct2+total+ngaydem, ~1.1-1.4KB)
    mqtt.setBufferSize(1792);
    Serial.printf("[MQTT] Broker: %s:%d\n", host.c_str(), port);
    Serial.printf("[MQTT] Sensor topic: %s\n", topicSensor.c_str());
}

// ═══════════════════════════════════════════════════════════
// RECONNECT
// ═══════════════════════════════════════════════════════════
bool mqttReconnect() {
    if (deviceId.length() == 0) return false;
    if (topicSensor.length() == 0) buildTopics();

    String host = mqttHost.length() ? mqttHost : String(MQTT_DEFAULT_HOST);
    int    port = mqttPort > 0 ? mqttPort : MQTT_DEFAULT_PORT;
    // Luôn resolve lại hostname (nếu là dạng "*.local") MỖI LẦN reconnect —
    // không được cache IP cũ, vì mục đích là tự bám theo host khi HA đổi IP.
    ensureMDNS();
    debugResolveMqttHost(host);
    mqtt.setServer(host.c_str(), port);
    // Đặt lại timeout mỗi lần reconnect (cùng lý do với buffer size bên dưới:
    // mqttSetup() có thể đã bị bỏ qua nếu WiFi kết nối chậm lúc khởi động).
    // Xem giải thích chi tiết trong mqttSetup().
    wifiClient.setTimeout(1500);   // ms — timeout TCP connect
    mqtt.setSocketTimeout(2);      // giây — timeout chờ CONNACK
    // QUAN TRỌNG: luôn đặt lại buffer size ở đây (không chỉ trong mqttSetup()).
    // Trước đây setBufferSize(1024) CHỈ nằm trong mqttSetup(), mà mqttSetup()
    // CHỈ được gọi khi WiFi kết nối kịp trong 8s đầu của setup(). Nếu WiFi
    // kết nối chậm hơn (rất hay gặp ngay sau khi ESP.restart() từ chế độ
    // AP cấu hình Web) thì mqttSetup() bị bỏ qua hoàn toàn, PubSubClient
    // dùng buffer mặc định chỉ 256 byte — quá nhỏ so với gói Discovery/Status
    // (~640-900 byte) nên publish() các gói này ÂM THẦM THẤT BẠI (không báo
    // lỗi, kết nối MQTT vẫn "connected" bình thường). Đây chính là lý do
    // "kết nối WiFi + MQTT thành công nhưng không thấy gói Discovery", và
    // chỉ hết khi khởi động lại lần nữa (lần đó WiFi tình cờ kết nối kịp
    // trong 8s nên mqttSetup() được gọi, buffer mới đủ lớn).
    // (Từ khi thêm chế độ "Ngày & Đêm", gói "SENSOR" đầy đủ có thể lên tới
    // ~1.1-1.4KB nên buffer được nâng lên 1792 byte cho an toàn.)
    mqtt.setBufferSize(1792);

    bool ok;
    if (mqttUser.length() > 0) {
        ok = mqtt.connect(deviceId.c_str(), mqttUser.c_str(), mqttPass.c_str(),
                           topicLwt.c_str(), 1, true, "Offline");
    } else {
        ok = mqtt.connect(deviceId.c_str(), topicLwt.c_str(), 1, true, "Offline");
    }

    if (ok) {
        mqtt.publish(topicLwt.c_str(), "Online", true);
        mqttConnected  = true;
        publishFullStatus();
        publishHADiscovery();     // gửi lại discovery mỗi lần (re)connect
        addLog("[OK] MQTT: Đã kết nối");
        Serial.println("[MQTT] Kết nối thành công.");
    } else {
        mqttConnected = false;
        Serial.printf("[MQTT] Kết nối thất bại, rc=%d\n", mqtt.state());
        addLog("[LỖI] MQTT: Không kết nối được");
    }
    return ok;
}

// Hàm chạy trong task FreeRTOS riêng — chỉ gọi mqttReconnect() (hàm chặn)
// rồi tự xoá task khi xong. Xem giải thích ở khai báo mqttReconnecting.
static void mqttReconnectTask(void* pvParameters) {
    mqttReconnect();
    mqttReconnecting = false;
    vTaskDelete(NULL);
}

// ═══════════════════════════════════════════════════════════
// LOOP
// ═══════════════════════════════════════════════════════════
void mqttLoop() {
    if (!wifiConnected) return;

    // Đang có task reconnect chạy nền — KHÔNG được đụng vào đối tượng
    // mqtt/wifiClient lúc này (không thread-safe), chỉ chờ task xong.
    if (mqttReconnecting) return;

    if (!mqtt.connected()) {
        mqttConnected = false;
        unsigned long now = millis();
        if (now - lastMqttTry > 8000) {
            lastMqttTry = now;
            mqttReconnecting = true;
            // Chạy mqttReconnect() (hàm CHẶN) trong task riêng, KHÔNG gọi
            // trực tiếp ở đây nữa — trước đây gọi thẳng trong loop() chính
            // khiến toàn bộ loop() (kể cả handleButtons()) bị đứng theo mỗi
            // khi mất kết nối MQTT (DNS lookup / TCP connect timeout / chờ
            // CONNACK có thể mất tới hàng chục giây), làm máy "treo" không
            // bấm được OK/NEXT.
            BaseType_t taskOk = xTaskCreatePinnedToCore(
                mqttReconnectTask, "mqttReconnect", 8192, nullptr, 1, nullptr, 1);
            if (taskOk != pdPASS) {
                // Không tạo được task (hiếm khi hết RAM) — bỏ qua lần này,
                // tự thử lại ở vòng lặp sau, không được rớt lại kiểu chặn cũ.
                mqttReconnecting = false;
            }
        }
        return;
    }

    mqttConnected = true;
    mqtt.loop();

    // Heartbeat telemetry
    if (millis() - lastHeartbeat > MQTT_HEARTBEAT_MS) {
        lastHeartbeat = millis();
        publishTelemetry();
    }
}

// ═══════════════════════════════════════════════════════════
// PUBLISH PZEM DATA  →  tele/{id}/SENSOR  (không retained)
// Gọi mỗi lần đọc PZEM xong (trong readPZEM() hoặc loop)
//
// Dữ liệu gửi lên thay đổi theo operatingMode hiện tại:
//   MODE_SUM  (Tổng CT1+CT2): ct1, ct2 đầy đủ + "total" = Tổng
//   MODE_DIFF (Hiệu CT1-CT2): ct1, ct2 đầy đủ + "total" = Hiệu
//   MODE_NLMT (NLMT)        : ct1="Tải tiêu thụ", ct2="Hòa lưới",
//                              total="Lấy lưới"
// Chỉ gửi giá trị hiện tại (tức thời) + tích lũy (kwh, kwh_day,
// kwh_month) — KHÔNG gửi mảng lịch sử theo ngày/tháng/năm.
// ═══════════════════════════════════════════════════════════
void publishPzemData() {
    if (!mqtt.connected()) return;

    int curMon = (lastMonth >= 1 && lastMonth <= 12) ? (lastMonth - 1) : 0;

    StaticJsonDocument<1536> doc;
    doc["device_id"]   = deviceId;
    doc["device_type"] = deviceType;
    doc["uptime"]      = millis() / 1000;
    doc["rssi"]        = WiFi.RSSI();
    doc["ip"]          = WiFi.localIP().toString();

    // Chế độ hiện tại
    doc["mode"]       = (int)operatingMode;
    doc["mode_label"] = modeLabel(operatingMode);

    // CT1 — tên hiển thị đổi theo chế độ (vd: "Tải tiêu thụ" với NLMT)
    JsonObject ct1 = doc.createNestedObject("ct1");
    ct1["title"] = titleCT1();
    ct1["volt"]  = rd1.ok ? rd1.volt : 0;
    ct1["amp"]   = rd1.ok ? rd1.amp  : 0;
    ct1["watt"]  = rd1.ok ? rd1.watt : 0;
    ct1["kwh"]   = rd1.ok ? rd1.kwh  : 0;
    ct1["hz"]    = rd1.ok ? rd1.hz   : 0;
    ct1["pf"]    = rd1.ok ? rd1.pf   : 0;
    ct1["ok"]    = rd1.ok;
    ct1["kwh_day"]   = kwhDay1;
    ct1["kwh_month"] = kwhMonth1[curMon];

    // CT2 — tên hiển thị đổi theo chế độ (vd: "Hòa lưới" với NLMT)
    JsonObject ct2 = doc.createNestedObject("ct2");
    ct2["title"] = titleCT2();
    ct2["volt"]  = rd2.ok ? rd2.volt : 0;
    ct2["amp"]   = rd2.ok ? rd2.amp  : 0;
    ct2["watt"]  = rd2.ok ? rd2.watt : 0;
    ct2["kwh"]   = rd2.ok ? rd2.kwh  : 0;
    ct2["hz"]    = rd2.ok ? rd2.hz   : 0;
    ct2["pf"]    = rd2.ok ? rd2.pf   : 0;
    ct2["ok"]    = rd2.ok;
    ct2["kwh_day"]   = kwhDay2;
    ct2["kwh_month"] = kwhMonth2[curMon];

    // Tổng/Hiệu (hoặc "Lấy lưới" với NLMT) — đã tính sẵn theo applyMode()
    JsonObject total = doc.createNestedObject("total");
    total["title"]     = titleTotal();
    total["watt"]      = totalWattValue();
    total["kwh_day"]   = kwhDayTotal;
    total["kwh_month"] = kwhMonTotal[curMon];
    // Tiền điện ước tính tháng này (bậc thang EVN + VAT), khớp với màn hình "Tổng"
    total["money_month"] = calculateElectricityCost(kwhMonTotal[curMon]);

    // Chế độ "Ngày & Đêm" — luôn gửi (giá trị chỉ có ý nghĩa khi mode==MODE_NGAYDEM)
    JsonObject ngd = doc.createNestedObject("ngaydem");
    ngd["title_setting"] = titleNgdSetting();
    ngd["title_p1"]      = titleNgdP1();
    ngd["title_p2"]      = titleNgdP2();
    ngd["title_p3"]      = titleNgdP3();
    ngd["status"]        = (int)ngdStatus;
    ngd["status_label"]  = ngdStatusLabel();
    ngd["start"]         = (uint32_t)ngdStartEpoch;
    ngd["end"]           = (uint32_t)ngdEndEpoch;
    ngd["kwh_day"]       = ngdKwhDay;
    ngd["kwh_night"]     = ngdKwhNight;
    float ngdTotal = ngdKwhDay + ngdKwhNight;
    ngd["kwh_total"]     = ngdTotal;
    ngd["percent_day"]   = (ngdTotal > 0) ? (ngdKwhDay / ngdTotal * 100.0f) : 0.0f;
    ngd["watt"]          = (operatingMode == MODE_NGAYDEM && rd1.ok) ? rd1.watt : 0;
    ngd["power_max"]     = ngdPowerMax;
    ngd["power_min"]     = ngdPowerMin;
    ngd["power_avg"]     = (ngdPowerSamples > 0) ? (ngdPowerSum / (float)ngdPowerSamples) : 0.0f;

    char buf[1536];
    size_t n = serializeJson(doc, buf, sizeof(buf));
    mqtt.publish(topicSensor.c_str(), (uint8_t*)buf, n, false);
    Serial.printf("[MQTT] pub %s (mode=%s)\n", topicSensor.c_str(), modeLabel(operatingMode));
}

// ═══════════════════════════════════════════════════════════
// PUBLISH FULL STATUS  →  stat/{id}/STATUS  (retained)
// ═══════════════════════════════════════════════════════════
void publishFullStatus() {
    if (!mqtt.connected()) return;

    StaticJsonDocument<640> doc;
    doc["device_id"]   = deviceId;
    doc["device_type"] = deviceType;
    doc["uptime"]      = millis() / 1000;
    doc["rssi"]        = WiFi.RSSI();
    doc["ip"]          = WiFi.localIP().toString();
    doc["wifi_ssid"]   = wifiSSID;
    doc["rtc_ok"]      = rtcOK;
    doc["ntp_synced"]  = ntpSynced;

    doc["mode"]       = (int)operatingMode;
    doc["mode_label"] = modeLabel(operatingMode);

    // Dữ liệu kWh ngày/tháng hiện tại
    doc["kwh_day1"]   = kwhDay1;
    doc["kwh_day2"]   = kwhDay2;
    doc["kwh_day_total"]  = kwhDayTotal;

    // Công suất tức thời
    doc["watt1"] = rd1.ok ? rd1.watt : 0;
    doc["watt2"] = rd2.ok ? rd2.watt : 0;

    char buf[640];
    size_t n = serializeJson(doc, buf, sizeof(buf));
    mqtt.publish(topicStatus.c_str(), (uint8_t*)buf, n, true);  // retained
    Serial.printf("[MQTT] pub %s (status)\n", topicStatus.c_str());
}

// ═══════════════════════════════════════════════════════════
// PUBLISH TELEMETRY  →  tele/{id}/STATE  (không retained)
// ═══════════════════════════════════════════════════════════
void publishTelemetry() {
    if (!mqtt.connected()) return;

    StaticJsonDocument<256> doc;
    doc["uptime"] = millis() / 1000;
    doc["rssi"]   = WiFi.RSSI();
    doc["ip"]     = WiFi.localIP().toString();
    doc["mode"]   = (int)operatingMode;
    doc["watt1"]  = rd1.ok ? rd1.watt : 0;
    doc["watt2"]  = rd2.ok ? rd2.watt : 0;
    doc["kwh_day1"] = kwhDay1;
    doc["kwh_day2"] = kwhDay2;

    char buf[256];
    size_t n = serializeJson(doc, buf, sizeof(buf));
    mqtt.publish(topicTele.c_str(), (uint8_t*)buf, n, false);
    Serial.printf("[MQTT] pub %s (telemetry)\n", topicTele.c_str());
}

// ═══════════════════════════════════════════════════════════
// HOME ASSISTANT MQTT DISCOVERY
// ═══════════════════════════════════════════════════════════
// Gửi 1 gói cấu hình "homeassistant/sensor/{deviceId}/{objectId}/config"
// (retained) cho mỗi entity. Home Assistant subscribe sẵn
// "homeassistant/+/+/+/config" nên sẽ tự nhận và tạo entity ngay khi
// thiết bị publish — không cần thao tác gì thêm phía HA.
//
// unique_id KHÔNG đổi giữa các lần gọi (chỉ phụ thuộc deviceId + objectId)
// nên nếu gọi lại (vd. sau khi đổi "Chọn chế độ") sẽ CẬP NHẬT entity cũ
// (đổi tên hiển thị) thay vì tạo entity mới.
// ═══════════════════════════════════════════════════════════
static void publishHASensor(const char* objectId, const String& name, const char* unit,
                             const char* deviceClass, const char* stateClass,
                             const String& valueTemplate, bool diagnostic = false) {
    if (!mqtt.connected()) return;

    String uniqueId = deviceId + "_" + objectId;
    String topic = "homeassistant/sensor/" + deviceId + "/" + String(objectId) + "/config";

    DynamicJsonDocument doc(768);
    doc["name"]     = name;
    doc["uniq_id"]  = uniqueId;
    doc["stat_t"]   = topicSensor;
    doc["val_tpl"]  = valueTemplate;
    if (unit && unit[0])        doc["unit_of_meas"] = unit;
    if (deviceClass && deviceClass[0]) doc["dev_cla"] = deviceClass;
    if (stateClass && stateClass[0])   doc["stat_cla"] = stateClass;
    doc["avty_t"]       = topicLwt;
    doc["pl_avail"]     = "Online";
    doc["pl_not_avail"] = "Offline";
    if (diagnostic) doc["ent_cat"] = "diagnostic";

    JsonObject dev = doc.createNestedObject("dev");
    JsonArray ids = dev.createNestedArray("ids");
    ids.add(deviceId);
    dev["name"] = "Công Tơ Điện " + deviceId;
    dev["mf"]   = "SDevice VN";
    dev["mdl"]  = "CTD2N";
    dev["sw"]   = CURRENT_FIRMWARE_VERSION;

    char buf[768];
    size_t n = serializeJson(doc, buf, sizeof(buf));
    mqtt.publish(topic.c_str(), (uint8_t*)buf, n, true);  // retained
}

void publishHADiscovery() {
    if (!mqtt.connected()) return;

    String t1 = String(titleCT1());
    String t2 = String(titleCT2());
    String tT = String(titleTotal());

    // ── CT1 ──────────────────────────────────────────────────
    publishHASensor("ct1_volt",  t1 + " - Điện áp",   "V",   "voltage",   "measurement",
                     "{{ value_json.ct1.volt }}");
    publishHASensor("ct1_amp",   t1 + " - Dòng điện",  "A",   "current",   "measurement",
                     "{{ value_json.ct1.amp }}");
    publishHASensor("ct1_watt",  t1 + " - Công suất",  "W",   "power",     "measurement",
                     "{{ value_json.ct1.watt }}");
    publishHASensor("ct1_kwh",   t1 + " - Điện năng (tích lũy)", "kWh", "energy", "total_increasing",
                     "{{ value_json.ct1.kwh }}");
    publishHASensor("ct1_hz",    t1 + " - Tần số",     "Hz",  "frequency", "measurement",
                     "{{ value_json.ct1.hz }}");
    publishHASensor("ct1_pf",    t1 + " - Hệ số công suất", "", "", "measurement",
                     "{{ value_json.ct1.pf }}");
    publishHASensor("ct1_kwh_day",   t1 + " - Điện năng hôm nay", "kWh", "energy", "total",
                     "{{ value_json.ct1.kwh_day }}");
    publishHASensor("ct1_kwh_month", t1 + " - Điện năng tháng này", "kWh", "energy", "total",
                     "{{ value_json.ct1.kwh_month }}");

    // ── CT2 ──────────────────────────────────────────────────
    publishHASensor("ct2_volt",  t2 + " - Điện áp",   "V",   "voltage",   "measurement",
                     "{{ value_json.ct2.volt }}");
    publishHASensor("ct2_amp",   t2 + " - Dòng điện",  "A",   "current",   "measurement",
                     "{{ value_json.ct2.amp }}");
    publishHASensor("ct2_watt",  t2 + " - Công suất",  "W",   "power",     "measurement",
                     "{{ value_json.ct2.watt }}");
    publishHASensor("ct2_kwh",   t2 + " - Điện năng (tích lũy)", "kWh", "energy", "total_increasing",
                     "{{ value_json.ct2.kwh }}");
    publishHASensor("ct2_hz",    t2 + " - Tần số",     "Hz",  "frequency", "measurement",
                     "{{ value_json.ct2.hz }}");
    publishHASensor("ct2_pf",    t2 + " - Hệ số công suất", "", "", "measurement",
                     "{{ value_json.ct2.pf }}");
    publishHASensor("ct2_kwh_day",   t2 + " - Điện năng hôm nay", "kWh", "energy", "total",
                     "{{ value_json.ct2.kwh_day }}");
    publishHASensor("ct2_kwh_month", t2 + " - Điện năng tháng này", "kWh", "energy", "total",
                     "{{ value_json.ct2.kwh_month }}");

    // ── Tổng/Hiệu (hoặc "Lấy lưới" với NLMT) ────────────────
    publishHASensor("total_watt",      tT + " - Công suất", "W", "power", "measurement",
                     "{{ value_json.total.watt }}");
    publishHASensor("total_kwh_day",   tT + " - Điện năng hôm nay", "kWh", "energy", "total",
                     "{{ value_json.total.kwh_day }}");
    publishHASensor("total_kwh_month", tT + " - Điện năng tháng này", "kWh", "energy", "total",
                     "{{ value_json.total.kwh_month }}");
    publishHASensor("total_money_month", tT + " - Tiền điện tháng này", "VND", "monetary", "total",
                     "{{ value_json.total.money_month }}");

    // ── Chế độ "Ngày & Đêm" — luôn đăng ký (chỉ có ý nghĩa khi mode==Ngày&Đêm) ──
    String tNgd = String(titleNgdP1());
    publishHASensor("ngd_kwh_day",   tNgd + " - kWh ban ngày", "kWh", "energy", "total",
                     "{{ value_json.ngaydem.kwh_day }}");
    publishHASensor("ngd_kwh_night", tNgd + " - kWh ban đêm", "kWh", "energy", "total",
                     "{{ value_json.ngaydem.kwh_night }}");
    publishHASensor("ngd_kwh_total", tNgd + " - Tổng kWh", "kWh", "energy", "total",
                     "{{ value_json.ngaydem.kwh_total }}");
    publishHASensor("ngd_percent_day", tNgd + " - % Sd ban ngày", "%", "", "measurement",
                     "{{ value_json.ngaydem.percent_day }}");
    publishHASensor("ngd_watt", String(titleNgdP2()) + " - Công suất", "W", "power", "measurement",
                     "{{ value_json.ngaydem.watt }}");
    publishHASensor("ngd_power_max", String(titleNgdP3()) + " - CS Max", "W", "power", "measurement",
                     "{{ value_json.ngaydem.power_max }}");
    publishHASensor("ngd_power_avg", String(titleNgdP3()) + " - CS TB", "W", "power", "measurement",
                     "{{ value_json.ngaydem.power_avg }}");
    publishHASensor("ngd_power_min", String(titleNgdP3()) + " - CS Min", "W", "power", "measurement",
                     "{{ value_json.ngaydem.power_min }}");
    publishHASensor("ngd_status", String(titleNgdSetting()) + " - Trạng thái", "", "", "",
                     "{{ value_json.ngaydem.status_label }}");

    // ── Chẩn đoán thiết bị ───────────────────────────────────
    publishHASensor("rssi", "Cường độ WiFi", "dBm", "signal_strength", "measurement",
                     "{{ value_json.rssi }}", true);
    publishHASensor("ip", "Địa chỉ IP", "", "", "",
                     "{{ value_json.ip }}", true);
    publishHASensor("uptime", "Thời gian hoạt động", "s", "duration", "measurement",
                     "{{ value_json.uptime }}", true);

    Serial.println("[MQTT] Đã gửi Home Assistant MQTT Discovery");
    //addLog("[OK] MQTT: Đã gửi cấu hình HA Discovery");
}

// ═══════════════════════════════════════════════════════════
// NGẮT KẾT NỐI MQTT CHỦ ĐỘNG
// Publish LWT "Offline" (retained) TRƯỚC khi disconnect, để Home
// Assistant nhận biết ngay thiết bị đã rời mạng (broker sẽ không tự
// gửi LWT khi client disconnect() hợp lệ, chỉ gửi khi mất kết nối
// đột ngột). Dùng khi vào lại màn hình "Cấu hình WiFi".
// ═══════════════════════════════════════════════════════════
void mqttDisconnectExplicit() {
    // Nếu task reconnect nền đang chạy thì không đụng vào đối tượng mqtt ở
    // đây (không thread-safe) — bỏ qua, mqttLoop() đã tắt kết nối khi vào
    // Cấu hình WiFi (wifiPortalActive) nên không cần disconnect thủ công lúc này.
    if (mqttReconnecting) { mqttConnected = false; return; }

    if (mqtt.connected()) {
        mqtt.publish(topicLwt.c_str(), "Offline", true);
        delay(150); // đảm bảo gói tin kịp gửi trước khi đóng socket
        mqtt.disconnect();
    }
    mqttConnected = false;
}