#include "globals.h"
#include "log.h"
#include "time_rtc.h"

// ═════════════════════════════════════════════════════════════
// THỜI GIAN
// ═════════════════════════════════════════════════════════════
DateTime getTime() {
    if (rtcOK) {
        DateTime t = rtc.now();
        if (t.year() >= 2024 && t.year() <= 2099) {
            usingNTPTime = false;
            return t;
        } else {
            if (!usingNTPTime) addLog("[LỖI] RTC: Giá trị thời gian không hợp lệ");
            rtcOK = false;
            tRTCRetry = millis();
        }
    } else {
        if (millis() - tRTCRetry >= RTC_RETRY_MS) {
            tRTCRetry = millis();
            if (rtc.begin()) {
                DateTime t = rtc.now();
                if (t.year() >= 2024 && t.year() <= 2099) {
                    rtcOK = true;
                    addLog("[OK] RTC: Phục hồi thành công");
                    usingNTPTime = false;
                    return t;
                }
            }
        }
    }

    if (ntpSynced) {
        struct tm ti;
        if (getLocalTime(&ti)) {
            usingNTPTime = true;
            return DateTime(ti.tm_year + 1900, ti.tm_mon + 1, ti.tm_mday,
                            ti.tm_hour, ti.tm_min, ti.tm_sec);
        }
    }

    usingNTPTime = false;
    return DateTime(2024, 1, 1, 0, 0, 0);
}

void syncNTP() {
    if (!wifiConnected) return;
    configTime(NTP_TZ_OFFSET, NTP_DST, NTP_SERVER1, NTP_SERVER2);

    struct tm ti;
    unsigned long t0 = millis();
    bool got = false;
    while (millis() - t0 < 5000) {
        if (getLocalTime(&ti)) { got = true; break; }
        delay(100);
    }

    if (!got) { addLog("[LỖI] NTP: Không lấy được thời gian"); return; }

    ntpSynced = true;
    char buf[40];
    snprintf(buf, sizeof(buf), "[OK] NTP: %04d-%02d-%02d %02d:%02d:%02d",
             ti.tm_year + 1900, ti.tm_mon + 1, ti.tm_mday,
             ti.tm_hour, ti.tm_min, ti.tm_sec);
    addLog(buf);
    if (applyNTPtoRTC()) addLog("[OK] NTP->RTC: Cập nhật thành công");
}

bool applyNTPtoRTC() {
    if (!rtcOK) return false;
    struct tm ti;
    if (!getLocalTime(&ti)) return false;
    rtc.adjust(DateTime(ti.tm_year + 1900, ti.tm_mon + 1, ti.tm_mday,
                        ti.tm_hour, ti.tm_min, ti.tm_sec));
    return true;
}

// ── Số ngày trong 1 tháng (month: 1-12), có tính năm nhuận ───
int daysInMonth(int month, int year) {
    static const int dim[12] = {31,28,31,30,31,30,31,31,30,31,30,31};
    if (month < 1 || month > 12) return 30;
    if (month == 2) {
        bool leap = (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
        return leap ? 29 : 28;
    }
    return dim[month - 1];
}
