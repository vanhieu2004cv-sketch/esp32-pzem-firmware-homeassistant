#include "globals.h"
#include "log.h"
#include "mode.h"
#include "storage.h"
#include "pzem.h"

// ═════════════════════════════════════════════════════════════
// PZEM READ
// ═════════════════════════════════════════════════════════════
void readPZEM() {
    float v1 = pzSensor1.voltage();
    rd1.ok = !isnan(v1);
    if (rd1.ok) {
        rd1.volt = v1;
        rd1.amp  = pzSensor1.current();
        rd1.watt = pzSensor1.power();
        rd1.kwh  = pzSensor1.energy();
        rd1.hz   = pzSensor1.frequency();
        rd1.pf   = pzSensor1.pf();
        pz1FailCnt = 0;
    } else {
        pz1FailCnt++;
        if (pz1FailCnt == PZ_FAIL_THRESH) addLog("[LỖI] PZEM1: Mất tín hiệu");
    }

    float v2 = pzSensor2.voltage();
    rd2.ok = !isnan(v2);
    if (rd2.ok) {
        rd2.volt = v2;
        rd2.amp  = pzSensor2.current();
        rd2.watt = pzSensor2.power();
        rd2.kwh  = pzSensor2.energy();
        rd2.hz   = pzSensor2.frequency();
        rd2.pf   = pzSensor2.pf();
        pz2FailCnt = 0;
    } else {
        pz2FailCnt++;
        if (pz2FailCnt == PZ_FAIL_THRESH) addLog("[LỖI] PZEM2: Mất tín hiệu");
    }
}

// ── Tính giá trị tổng/hiệu theo chế độ ──────────────────────
// MODE_SUM : CT1 + CT2
// MODE_DIFF: CT1 - CT2  (âm → 0)
// MODE_NLMT: CT1 - CT2  (giống DIFF, chỉ khác tên)
static float applyMode(float v1, float v2) {
    if (operatingMode == MODE_SUM) return v1 + v2;
    float diff = v1 - v2;
    return (diff >= 0) ? diff : 0;
}

// Công suất tức thời theo chế độ hiện tại — dùng chung cho UI và MQTT
float totalWattValue() {
    float w1 = rd1.ok ? rd1.watt : 0;
    float w2 = rd2.ok ? rd2.watt : 0;
    return applyMode(w1, w2);
}

// ═════════════════════════════════════════════════════════════
// kWh TRACKING
// ═════════════════════════════════════════════════════════════
// Thứ tự xử lý khi phát hiện đổi ngày/tháng/năm (chạy mỗi PZ_MS):
//   (1) Chốt sổ NGÀY vừa kết thúc vào dayHistCurMonth[]  (dùng kwhDayTotal
//       đã tích lũy đủ cả ngày — TRƯỚC khi nó bị reset về 0)
//   (2) Chốt sổ THÁNG vừa kết thúc vào kwhMonth[]/chartDataTotal[]
//   (3) Nếu sang năm mới: snapshot toàn bộ chartDataTotal[] (đã có đủ
//       dữ liệu tháng 12 nhờ bước 2 chạy trước) vào chartDataTotalPrev[]
//       rồi mới xóa để bắt đầu năm mới
//   (4) Nếu sang tháng mới: xoay dayHistCurMonth[] → dayHistPrevMonth[]
//   (5) Dời mốc eStart/mStart, reset kWh ngày về 0
// → Đảm bảo dữ liệu "ngày cũ"/"tháng cũ"/"năm cũ" luôn được lưu lại đầy đủ
//   TRƯỚC khi vùng nhớ tương ứng bị ghi đè cho kỳ mới.
void updateKWh(const DateTime &now) {
    int d = now.day(), m = now.month(), y = now.year();
    if (y < 2024) return;

    if (lastDay == 0) {
        lastDay = d; lastMonth = m; lastYear = y;
        eStart1 = rd1.ok ? rd1.kwh : 0;
        eStart2 = rd2.ok ? rd2.kwh : 0;
        mStart1 = eStart1; mStart2 = eStart2;
        dayHistCurMonthIdx = m;
        dayHistCurYear     = y;
        savePrefs(); return;
    }

    bool dayChanged   = (d != lastDay);
    bool monthChanged = (m != lastMonth);
    bool yearChanged  = (y != lastYear);

    // ── (1) Chốt sổ NGÀY vừa qua vào lịch sử "Tháng X" ────────
    if (dayChanged) {
        int oldDayIdx = lastDay - 1;   // ngày vừa kết thúc, vẫn thuộc dayHistCurMonth hiện tại
        if (oldDayIdx >= 0 && oldDayIdx < 31) {
            dayHistCurMonth[oldDayIdx]  = kwhDayTotal;
            dayHistCurMonth1[oldDayIdx] = kwhDay1;
            dayHistCurMonth2[oldDayIdx] = kwhDay2;
        }
    }

    // ── (2) Chốt sổ THÁNG vừa qua ──────────────────────────────
    if (monthChanged) {
        int pm = lastMonth - 1;
        if (pm >= 0 && pm < 12) {
            kwhMonth1[pm] = rd1.ok ? (rd1.kwh - mStart1) : kwhMonth1[pm];
            kwhMonth2[pm] = rd2.ok ? (rd2.kwh - mStart2) : kwhMonth2[pm];
            chartData[pm]      = kwhMonth1[pm] + kwhMonth2[pm];
            kwhMonTotal[pm]    = applyMode(kwhMonth1[pm], kwhMonth2[pm]);
            chartDataTotal[pm] = kwhMonTotal[pm];
        }
        mStart1 = rd1.ok ? rd1.kwh : mStart1;
        mStart2 = rd2.ok ? rd2.kwh : mStart2;
    }

    // ── (3) Chốt sổ NĂM vừa qua — snapshot biểu đồ trước khi xóa ─
    if (yearChanged) {
        for (int i = 0; i < 12; i++) chartDataTotalPrev[i] = chartDataTotal[i];
        for (int i = 0; i < 12; i++) {
            kwhMonth1Prev[i] = kwhMonth1[i];
            kwhMonth2Prev[i] = kwhMonth2[i];
        }
        chartPrevYear = lastYear;

        for (int i = 0; i < 12; i++) {
            kwhMonth1[i] = kwhMonth2[i] = chartData[i] = 0;
            kwhMonTotal[i] = chartDataTotal[i] = 0;
        }
        addLog("[OK] Năm mới: Đã lưu biểu đồ năm cũ, reset biểu đồ");
    }

    // ── (4) Sang tháng mới → xoay lịch sử ngày ─────────────────
    if (monthChanged) {
        for (int i = 0; i < 31; i++) dayHistPrevMonth[i] = dayHistCurMonth[i];
        dayHistPrevMonthIdx = dayHistCurMonthIdx;
        dayHistPrevYear     = dayHistCurYear;

        for (int i = 0; i < 31; i++) {
            dayHistCurMonth[i]  = 0;
            dayHistCurMonth1[i] = 0;
            dayHistCurMonth2[i] = 0;
        }
        dayHistCurMonthIdx = m;
        dayHistCurYear     = y;

        lastMonth = m;
        kwhDay1 = kwhDay2 = kwhDayTotal = 0;
    }

    if (yearChanged) lastYear = y;

    // ── (5) Sang ngày mới → dời mốc, reset kWh ngày ────────────
    if (dayChanged) {
        lastDay = d;
        eStart1 = rd1.ok ? rd1.kwh : eStart1;
        eStart2 = rd2.ok ? rd2.kwh : eStart2;
        kwhDay1 = kwhDay2 = kwhDayTotal = 0;
    }

    if (dayChanged || monthChanged || yearChanged) savePrefs();

    // ── Tính kWh hiện tại (chạy mỗi lần gọi) ───────────────────
    if (rd1.ok && rd1.kwh >= eStart1) kwhDay1 = rd1.kwh - eStart1;
    if (rd2.ok && rd2.kwh >= eStart2) kwhDay2 = rd2.kwh - eStart2;

    int cm = m - 1;
    if (rd1.ok) kwhMonth1[cm] = rd1.kwh - mStart1;
    if (rd2.ok) kwhMonth2[cm] = rd2.kwh - mStart2;
    chartData[cm] = kwhMonth1[cm] + kwhMonth2[cm];

    // Tổng/Hiệu theo chế độ
    kwhDayTotal    = applyMode(kwhDay1, kwhDay2);
    kwhMonTotal[cm] = applyMode(kwhMonth1[cm], kwhMonth2[cm]);
    chartDataTotal[cm] = kwhMonTotal[cm];
}