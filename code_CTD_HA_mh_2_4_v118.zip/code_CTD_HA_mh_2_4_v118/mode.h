#pragma once
#include "globals.h"

// Tên tiêu đề màn hình theo chế độ
const char* titleCT1();
const char* titleCT2();
const char* titleTotal();
const char* modeLabel(OperatingMode m);

// Tên mặc định theo 1 chế độ bất kỳ (không phụ thuộc operatingMode hiện tại)
// — dùng để Web Server hiển thị/so sánh tên mặc định của từng chế độ.
const char* defaultTitleCT1(OperatingMode m);
const char* defaultTitleCT2(OperatingMode m);
const char* defaultTitleTotal(OperatingMode m);

// ── Tên tiêu đề 4 màn hình con của chế độ "Ngày & Đêm" ────────
const char* titleNgdSetting();
const char* titleNgdP1();
const char* titleNgdP2();
const char* titleNgdP3();
const char* defaultTitleNgdSetting();
const char* defaultTitleNgdP1();
const char* defaultTitleNgdP2();
const char* defaultTitleNgdP3();

// Tính tiền điện bậc thang EVN + VAT 8% (đồng/kWh, dùng chung cho UI và MQTT/HA)
float calculateElectricityCost(float kwh);