#pragma once
#include <lvgl.h>
#include <RTClib.h>

// ── LVGL Helper widgets ───────────────────────────────────────
lv_obj_t* make_label(lv_obj_t *parent, int x, int y,
                     const char *txt, lv_color_t color);
lv_obj_t* make_label_f(lv_obj_t *parent, int x, int y,
                       const char *txt, lv_color_t color,
                       const lv_font_t *font);
lv_obj_t* make_rect(lv_obj_t *parent, int x, int y,
                    int w, int h, lv_color_t color);
lv_obj_t* make_title_bar(lv_obj_t *parent, lv_color_t bg_color);
lv_obj_t* new_screen();

// ── Draw screens ─────────────────────────────────────────────
void drawScreen();
void drawCT(int ct);
void drawTotal();
void drawDayHist();        // Màn hình "Tháng X" (Tổng) — lịch sử kWh từng ngày
int  dayHistTotalRows();   // Tổng số hàng của bảng "Tháng X" (dùng cho cuộn NEXT)
void drawChart();          // Màn hình "Biểu đồ năm Y" (Tổng)
void drawPrevMonthStat();  // Màn hình "Thống kê tháng X-1" (Tổng)
void drawTotalDetail();    // Điều phối 3 màn hình con bên trong "Tổng"
                            // theo totalDetailIndex (0/1/2)

// ── "Tháng X" / "Biểu đồ năm Y" / "Thống kê tháng X-1" của riêng
//    Công tơ 1 / Công tơ 2 — bên trong màn hình "Công tơ 1" / "Công tơ 2",
//    y hệt cơ chế của "Tổng" ở trên.
void drawCT1Detail();      // Điều phối theo ct1DetailIndex (0/1/2)
void drawCT2Detail();      // Điều phối theo ct2DetailIndex (0/1/2)
void drawWifiConfig();    // Màn hình Cấu hình WiFi + MQTT qua Web AP
void drawSettings();
void drawLogView();
void drawModeSelect();
void drawDeviceInfo();   // Màn hình "Thông tin thiết bị"

// ── Chế độ "Ngày & Đêm" ────────────────────────────────────────
void drawNgayDem();       // Điều phối 4 màn hình con theo ngdScreenIndex
void drawNgdSetting();    // "Cài đặt thời gian"
void drawNgdP1();         // "Thông số 1" — kWh ngày/đêm/tổng/% ngày
void drawNgdP2();         // "Thông số 2" — CS(W), Điện áp/Hz, Dòng/Hệ số
void drawNgdP3();         // "Thông số 3" — CS Max/TB/Min