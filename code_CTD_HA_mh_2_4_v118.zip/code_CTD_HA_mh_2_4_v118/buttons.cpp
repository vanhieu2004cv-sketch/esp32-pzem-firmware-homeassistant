#include "globals.h"
#include "log.h"
#include "mode.h"
#include "storage.h"
#include "ui.h"
#include "wifi_portal.h"
#include "mqtt_client.h"
#include "buttons.h"
#include "ota.h"
#include "ngaydem.h"

// ═════════════════════════════════════════════════════════════
// BUTTONS
// ═════════════════════════════════════════════════════════════

// ── Ngưỡng giữ đồng thời NEXT + OK dùng cho chế độ "Ngày & Đêm"
//    (Lưu & chạy / Đặt lại cấu hình) ──────────────────────────
#define NGD_COMBO_HOLD_MS 1500UL

// ── Màn hình tiến trình OTA (thanh %, số KB đã tải, trạng thái) ─
static lv_obj_t *otaProgBarBg   = nullptr;
static lv_obj_t *otaProgBarFill = nullptr;
static lv_obj_t *otaProgPercent = nullptr;
static lv_obj_t *otaProgKB      = nullptr;
static lv_obj_t *otaProgStatus  = nullptr;

#define OTA_BAR_X 20
#define OTA_BAR_Y 120
#define OTA_BAR_W (SCR_W - 40)
#define OTA_BAR_H 22

// Trong lúc kiểm tra/tải OTA, vòng lặp chính loop() không chạy nên KHÔNG có ai
// gọi lv_tick_inc() cho LVGL → bộ đếm thời gian nội bộ đứng yên → lv_timer_handler()
// sẽ không bao giờ thấy "đến lúc vẽ lại", làm màn hình bị đứng hình dù dữ liệu vẫn
// đang chạy ngầm. Hàm này tự bơm tick theo thời gian thực (millis()) trước khi vẽ,
// dùng thay cho lv_timer_handler() ở mọi nơi trong toàn bộ luồng Kiểm tra cập nhật.
static unsigned long otaLastTickMs = 0;
static void otaPumpLvgl() {
    unsigned long nowMs = millis();
    if (otaLastTickMs == 0) otaLastTickMs = nowMs;
    lv_tick_inc(nowMs - otaLastTickMs);
    otaLastTickMs = nowMs;
    lv_timer_handler();
}

// Khởi tạo màn hình tiến trình OTA — gọi 1 lần trước khi bắt đầu cập nhật
static void drawOtaProgressScreen() {
    lv_obj_t *scr = new_screen();
    make_label(scr, 20, 15, "Đang cập nhật firmware", LV_C_TITLE);

    otaProgBarBg   = make_rect(scr, OTA_BAR_X, OTA_BAR_Y, OTA_BAR_W, OTA_BAR_H, LV_C_HILIGHT);
    otaProgBarFill = make_rect(scr, OTA_BAR_X, OTA_BAR_Y, 0, OTA_BAR_H, LV_C_GREEN);

    otaProgPercent = make_label(scr, OTA_BAR_X, OTA_BAR_Y - 26, "0%", LV_C_VAL);
    otaProgKB      = make_label(scr, OTA_BAR_X, OTA_BAR_Y + OTA_BAR_H + 10, "0 KB / 0 KB", LV_C_TEXT);
    otaProgStatus  = make_label(scr, OTA_BAR_X, OTA_BAR_Y + OTA_BAR_H + 40, "Đang tải...", LV_C_ORANGE);

    otaPumpLvgl();
}

// Callback báo tiến trình OTA — cập nhật thanh %, số KB đã tải và trạng thái
static void otaProgressCallback(OtaStage stage, size_t written, size_t total) {
    static unsigned long tLastUiUpdate = 0;
    unsigned long nowMs = millis();
    bool finished = (total > 0 && written >= total);

    // Giới hạn tần suất vẽ lại (~10 lần/giây) để không làm chậm quá trình tải,
    // nhưng luôn vẽ ngay khi đổi giai đoạn hoặc khi tải xong
    if (stage == OTA_STAGE_DOWNLOADING && !finished && (nowMs - tLastUiUpdate < 100)) return;
    tLastUiUpdate = nowMs;

    int pct = (total > 0) ? (int)((written * 100UL) / total) : 0;
    if (pct > 100) pct = 100;

    if (otaProgBarFill) lv_obj_set_width(otaProgBarFill, (OTA_BAR_W * pct) / 100);

    if (otaProgPercent) {
        char buf[8];
        snprintf(buf, sizeof(buf), "%d%%", pct);
        lv_label_set_text(otaProgPercent, buf);
    }

    if (otaProgKB) {
        char buf[32];
        snprintf(buf, sizeof(buf), "%u KB / %u KB",
                 (unsigned)(written / 1024), (unsigned)(total / 1024));
        lv_label_set_text(otaProgKB, buf);
    }

    if (otaProgStatus) {
        const char *txt = "Đang tải...";
        if (stage == OTA_STAGE_WRITING)    txt = "Đang ghi Flash...";
        if (stage == OTA_STAGE_RESTARTING) txt = "Khởi động lại...";
        lv_label_set_text(otaProgStatus, txt);
    }

    otaPumpLvgl();
}

void handleButtons() {
    bool okNow = digitalRead(PIN_BTN_OK);
    bool nxNow = digitalRead(PIN_BTN_NEXT);

    // ── Chế độ "Ngày & Đêm": phát hiện giữ ĐỒNG THỜI NEXT + OK ────────
    // (Lưu cấu hình & chạy / Đặt lại cấu hình). Khi tổ hợp này được kích
    // hoạt, 2 sự kiện "nhả nút" đơn lẻ (OK và NEXT) chắc chắn sẽ xảy ra
    // ngay sau đó — dùng suppressOkRelease/suppressNxRelease để bỏ qua
    // đúng 1 lần xử lý nhả nút đơn cho mỗi nút, tránh kích hoạt nhầm
    // hành động của nút đơn lẻ (di chuyển con trỏ / bật chế độ edit...).
    static unsigned long ngdComboStart  = 0;
    static bool          ngdComboFired  = false;
    static bool          suppressOkRelease = false;
    static bool          suppressNxRelease = false;

    if (operatingMode == MODE_NGAYDEM && !inSettings && !inModeSelect &&
        !inWifiConfig && !inLogView && !inDeviceInfo) {
        bool bothDown = (okNow == LOW && nxNow == LOW);
        if (bothDown) {
            if (ngdComboStart == 0) ngdComboStart = millis();
            else if (!ngdComboFired && millis() - ngdComboStart >= NGD_COMBO_HOLD_MS) {
                ngdComboFired = true;
                suppressOkRelease = true;
                suppressNxRelease = true;
                ngdHandleComboHold();
                drawScreen();
            }
        } else {
            ngdComboStart = 0;
            ngdComboFired = false;
        }
    } else {
        ngdComboStart = 0;
        ngdComboFired = false;
    }

    // ── Phát hiện nhấn OK ────────────────────────────────────
    if (prevOK == HIGH && okNow == LOW) tOkDown = millis();
    if (prevOK == LOW && okNow == HIGH) {
        unsigned long held = millis() - tOkDown;

        if (suppressOkRelease) {
            // Vừa xử lý tổ hợp giữ NEXT+OK ở trên — bỏ qua sự kiện nhả OK này
            suppressOkRelease = false;
        }

        // --- Chế độ "Ngày & Đêm" ---
        else if (!inSettings && !inModeSelect && !inWifiConfig && !inLogView && !inDeviceInfo &&
                 operatingMode == MODE_NGAYDEM && held < HOLD_MS) {
            // Chỉ có tác dụng ở màn hình "Cài đặt thời gian" trong lúc CHƯA
            // cấu hình: bật/tắt chế độ chỉnh giá trị field đang chọn.
            // Khi đã lưu cấu hình (đang chạy/đã kết thúc), OK không có tác
            // dụng gì (chỉ NEXT đổi màn hình, giữ NEXT+OK để đặt lại).
            if (ngdScreenIndex == NGD_SCR_SETTING && ngdStatus == NGD_CHUA_CAUHINH) {
                ngdToggleEdit();
                drawScreen();
            }
        }

        // --- Màn hình Cấu hình WiFi (Web AP) ---
        else if (inWifiConfig) {
            // Nhấn OK → quay về màn hình Cài đặt
            // AP + Web Server vẫn tiếp tục chạy nền
            inWifiConfig = false;
            inSettings   = true;
            drawSettings();
        }

        // --- Màn hình Nhật ký lỗi ---
        else if (inLogView) {
            inLogView  = false;
            inSettings = true;
            logScroll  = 0;
            drawSettings();
        }

        // --- Màn hình Thông tin thiết bị ---
        else if (inDeviceInfo) {
            inDeviceInfo = false;
            inSettings   = true;
            drawSettings();
        }

        // --- Màn hình Chọn chế độ ---
        else if (inModeSelect) {
            OperatingMode newMode = (OperatingMode)modeSelectRow;
            if (newMode != operatingMode) {
                operatingMode = newMode;
                // Đổi sang chế độ BẤT KỲ (kể cả Ngày & Đêm) → xóa hết dữ liệu
                // đã lưu của mọi chế độ để tránh xung đột/nhầm lẫn dữ liệu cũ
                // (KHÔNG đụng tới cấu hình mạng WiFi/MQTT — xem resetAllData()).
                resetAllData();   // resetAllData() đã tự savePrefs() (kèm operatingMode mới)
                char logbuf[40];
                snprintf(logbuf, sizeof(logbuf), "[OK] Chế độ: %s", modeLabel(operatingMode));
                addLog(logbuf);
                publishFullStatus();   // cập nhật retained "mode" ngay, không chờ heartbeat
                publishHADiscovery();  // cập nhật tên entity theo chế độ mới ngay (không chờ reconnect)
            }
            inModeSelect = false;
            inSettings   = true;
            drawSettings();
        }

        // --- Màn hình "Công tơ 1" / "Công tơ 2" / "Tổng" — nhấn OK 1 lần để
        //     vào/thoát chế độ xem chi tiết ("Tháng X" / "Biểu đồ năm Y" /
        //     "Thống kê tháng X-1") của màn hình đang hiển thị ---
        else if (!inSettings && held < HOLD_MS &&
                 !inCT1Detail && !inCT2Detail && !inTotalDetail &&
                 (currentScreen == SCR_CT1 || currentScreen == SCR_CT2 || currentScreen == SCR_TOTAL)) {
            if (currentScreen == SCR_CT1)      { inCT1Detail   = true; ct1DetailIndex   = 0; }
            else if (currentScreen == SCR_CT2) { inCT2Detail   = true; ct2DetailIndex   = 0; }
            else                                { inTotalDetail = true; totalDetailIndex = 0; }
            drawScreen();
        }
        else if (!inSettings && held < HOLD_MS && (inCT1Detail || inCT2Detail || inTotalDetail)) {
            // Thoát chế độ xem chi tiết, quay lại màn hình cha
            inCT1Detail = inCT2Detail = inTotalDetail = false;
            drawScreen();
        }

        // --- Vào cài đặt (giữ OK) ---
        else if (!inSettings && held >= HOLD_MS) {
            inSettings  = true;
            settingsRow = 0;
            drawSettings();
        }

        // --- Trong màn hình cài đặt ---
        else if (inSettings && held < HOLD_MS) {
            switch (settingsRow) {
                case 0:  // Xóa hết dữ liệu
                    resetAllData();
                    { lv_obj_t *s = new_screen(); make_label(s, 20, 55, "Đã reset!", LV_C_GREEN); lv_timer_handler(); }
                    delay(1500);
                    inSettings = false;
                    break;

                case 1:  // Kết nối WiFi → vào màn hình Cấu hình WiFi (Web AP)
                    // Báo Offline lên MQTT trước khi ngắt (nếu đang kết nối)
                    mqttDisconnectExplicit();
                    // Xóa cấu hình WiFi đã lưu
                    wifiSSID = "";
                    wifiPASS = "";
                    wifiConnected  = false;
                    wifiConfigured = false;
                    WiFi.disconnect(false);  // KHÔNG deinit driver — startWifiPortal() sẽ chuyển sang AP ngay sau đó
                    savePrefs();
                    addLog("[OK] WiFi: Đã xóa cấu hình cũ");
                    // Bật Access Point để người dùng cấu hình WiFi + MQTT qua trình duyệt
                    startWifiPortal();
                    // Chuyển sang màn hình hướng dẫn
                    inSettings   = false;
                    inWifiConfig = true;
                    drawWifiConfig();
                    break;

                case 2:  // Nhật ký lỗi
                    inLogView  = true;
                    logScroll  = 0;
                    inSettings = false;
                    drawLogView();
                    break;

                case 3:  // Kiểm tra cập nhật (Mục mới)
                    {
                        lv_obj_t *s = new_screen();
                        make_label(s, 20, 55, "Đang kiểm tra...", LV_C_TITLE);
                        otaPumpLvgl();

                        if (checkNewUpdate()) {
                            // Hiển thị giao diện hỏi người dùng: phiên bản hiện tại,
                            // phiên bản mới và dung lượng file cần tải
                            lv_obj_t *sConfirm = new_screen();
                            make_label(sConfirm, 20, 15, "Phát hiện bản mới!", LV_C_GREEN);

                            char lineCur[40], lineNew[40], lineSize[32];
                            snprintf(lineCur, sizeof(lineCur), "Hiện tại: %s", CURRENT_FIRMWARE_VERSION);
                            snprintf(lineNew, sizeof(lineNew), "Bản mới:  %s", getLatestVersionStr());
                            size_t szBytes = getUpdateSizeBytes();
                            if (szBytes > 0)
                                snprintf(lineSize, sizeof(lineSize), "Dung lượng: %u KB", (unsigned)(szBytes / 1024));
                            else
                                snprintf(lineSize, sizeof(lineSize), "Dung lượng: --");

                            make_label(sConfirm, 20, 50,  lineCur,  LV_C_TEXT);
                            make_label(sConfirm, 20, 75,  lineNew,  LV_C_TEXT);
                            make_label(sConfirm, 20, 100, lineSize, LV_C_TEXT);
                            make_label(sConfirm, 20, 140, "[OK]: Cập nhật ngay", LV_C_TEXT);
                            make_label(sConfirm, 20, 165, "[NEXT]: Hủy bỏ", LV_C_TEXT);
                            otaPumpLvgl();

                            // Vòng lặp quét phím cục bộ (chờ tối đa 10 giây)
                            unsigned long startWait = millis();
                            bool userSelect = false;
                            while (millis() - startWait < 10000) {
                                bool okBtn = digitalRead(PIN_BTN_OK);
                                bool nxBtn = digitalRead(PIN_BTN_NEXT);

                                if (okBtn == LOW) { // Người dùng nhấn OK -> Cập nhật
                                    // Vẽ màn hình tiến trình: thanh %, số KB đã tải, trạng thái
                                    drawOtaProgressScreen();

                                    if (!performOTAUpdate(otaProgressCallback)) {
                                        lv_obj_t *sFail = new_screen();
                                        make_label(sFail, 20, 55, "Cập nhật thất bại!", LV_C_RED);
                                        otaPumpLvgl();
                                        delay(2000);
                                    }
                                    // Nếu thành công, performOTAUpdate() đã tự ESP.restart()
                                    // nên các dòng phía dưới sẽ không chạy tới.
                                    userSelect = true;
                                    break;
                                }
                                if (nxBtn == LOW) { // Người dùng nhấn NEXT -> Hủy bỏ
                                    userSelect = true;
                                    break;
                                }
                                otaPumpLvgl();
                                delay(50);
                            }
                        } else {
                            lv_obj_t *sNo = new_screen();
                            make_label(sNo, 20, 55, "Phiên bản đã mới nhất", LV_C_TEXT);
                            otaPumpLvgl();
                            delay(1500);
                        }
                    }
                    drawSettings(); // Trả lại giao diện Menu cài đặt sau khi xong
                    break;

                case 4:  // Chọn chế độ (Tăng index từ 3 lên 4)
                    inModeSelect  = true;
                    modeSelectRow = (int)operatingMode;
                    inSettings    = false;
                    drawModeSelect();
                    break;

                case 5:  // Thông tin thiết bị (Mục mới)
                    inDeviceInfo = true;
                    inSettings   = false;
                    drawDeviceInfo();
                    break;

                case 6:  // Khởi động lại (Mục mới)
                    {
                        // Không tạo màn hình riêng: dòng "Khởi động lại..." đã có sẵn
                        // mặc định trong quá trình khởi động ESP32.
                        addLog("[OK] Khởi động lại thiết bị theo yêu cầu người dùng");
                        ESP.restart();
                    }
                    break;

                case 7:  // Quay lại (Tăng index từ 5 lên 7)
                    inSettings = false;
                    break;
            }
        }
    }
    prevOK = okNow;

    // ── Phát hiện nhấn NEXT ──────────────────────────────────
    if (prevNEXT == HIGH && nxNow == LOW) tNxDown = millis();
    if (prevNEXT == LOW && nxNow == HIGH) {
        if (suppressNxRelease) {
            // Vừa xử lý tổ hợp giữ NEXT+OK ở trên — bỏ qua sự kiện nhả NEXT này
            suppressNxRelease = false;
        }
        else if (millis() - tNxDown >= DEBOUNCE_MS) {
            if (!inSettings && !inModeSelect && !inWifiConfig && !inLogView && !inDeviceInfo &&
                operatingMode == MODE_NGAYDEM) {
                // --- Chế độ "Ngày & Đêm" ---
                if (ngdScreenIndex == NGD_SCR_SETTING && ngdStatus == NGD_CHUA_CAUHINH) {
                    // Đang cấu hình: NEXT di chuyển con trỏ (chưa edit) hoặc
                    // tăng giá trị field đang chọn (đang edit)
                    if (ngdEditing) ngdEditIncrement();
                    else            ngdCursorNext();
                } else {
                    // Đã lưu cấu hình (đang chạy/đã kết thúc): NEXT đổi giữa 4 màn hình
                    ngdNextScreen();
                }
                drawScreen();
            } else if (inWifiConfig) {
                // NEXT không làm gì trong màn hình Cấu hình WiFi
            } else if (inLogView) {
                if (logScroll + 1 < logCount) logScroll++;
                drawLogView();
            } else if (inDeviceInfo) {
                // NEXT không làm gì trong màn hình Thông tin thiết bị
            } else if (inModeSelect) {
                modeSelectRow = (modeSelectRow + 1) % (int)MODE_COUNT;
                drawModeSelect();
            } else if (inSettings) {
                settingsRow = (settingsRow + 1) % SETTINGS_ROWS;
                drawSettings();
            } else if (inCT1Detail) {
                // Đang ở chế độ xem chi tiết bên trong "Công tơ 1" → NEXT chuyển
                // vòng tròn giữa 3 màn hình con: Tháng X → Biểu đồ năm Y →
                // Thống kê tháng X-1 → quay lại Tháng X.
                ct1DetailIndex = (ct1DetailIndex + 1) % 3;
                drawCT1Detail();
            } else if (inCT2Detail) {
                // Y hệt trên nhưng cho "Công tơ 2"
                ct2DetailIndex = (ct2DetailIndex + 1) % 3;
                drawCT2Detail();
            } else if (inTotalDetail) {
                // Đang ở chế độ xem chi tiết bên trong "Tổng" → NEXT chuyển vòng
                // tròn giữa 3 màn hình con: Tháng X → Biểu đồ năm Y →
                // Thống kê tháng X-1 → quay lại Tháng X.
                totalDetailIndex = (totalDetailIndex + 1) % 3;
                drawTotalDetail();
            } else {
                // Chuyển giữa 3 màn hình cấp cao nhất: Công tơ 1 → Công tơ 2 → Tổng
                currentScreen = (ScreenID)((int(currentScreen) + 1) % int(SCR_COUNT));
            }
        }
    }
    prevNEXT = nxNow;
}

void updateLED() {
    if (wifiConnected) { digitalWrite(PIN_LED, HIGH); return; }
    uint32_t interval = wifiConfigured ? 800 : 200;
    if (millis() - tLedToggle >= interval) {
        tLedToggle = millis();
        ledState   = !ledState;
        digitalWrite(PIN_LED, ledState);
    }
}