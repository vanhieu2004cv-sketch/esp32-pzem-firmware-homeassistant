#include "globals.h"
#include "log.h"

// ── NHẬT KÝ LỖI ──────────────────────────────────────────────
void addLog(const char *msg) {
    char ts[10] = "??:??:??";
    struct tm ti;
    if (getLocalTime(&ti)) {
        snprintf(ts, sizeof(ts), "%02d:%02d:%02d", ti.tm_hour, ti.tm_min, ti.tm_sec);
    } else if (rtcOK) {
        DateTime r = rtc.now();
        if (r.year() >= 2024)
            snprintf(ts, sizeof(ts), "%02d:%02d:%02d", r.hour(), r.minute(), r.second());
    }
    if (logCount < LOG_MAX) {
        strncpy(logBuf[logCount].msg, msg, LOG_LINELEN - 1);
        logBuf[logCount].msg[LOG_LINELEN - 1] = '\0';
        strncpy(logBuf[logCount].ts, ts, sizeof(ts));
        logCount++;
    } else {
        for (int i = 0; i < LOG_MAX - 1; i++) logBuf[i] = logBuf[i + 1];
        strncpy(logBuf[LOG_MAX - 1].msg, msg, LOG_LINELEN - 1);
        logBuf[LOG_MAX - 1].msg[LOG_LINELEN - 1] = '\0';
        strncpy(logBuf[LOG_MAX - 1].ts, ts, sizeof(ts));
    }
    Serial.printf("[LOG %s] %s\n", ts, msg);
}
