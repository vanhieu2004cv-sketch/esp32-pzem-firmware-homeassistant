#include "globals.h"
#include "mode.h"

// ── Tên tiêu đề tùy chỉnh theo chế độ, nhập từ Web Server ────
// Rỗng ("") = người dùng chưa sửa/không đổi gì → dùng tên mặc định như cũ.
String customTitleCT1[MODE_COUNT];
String customTitleCT2[MODE_COUNT];
String customTitleTotal[MODE_COUNT];

// Tên tiêu đề 4 màn hình con của chế độ "Ngày & Đêm" (riêng, không dùng
// mảng theo MODE_COUNT như trên vì chế độ này chỉ có đúng 1 bộ tên)
String customTitleNgdSetting;
String customTitleNgdP1;
String customTitleNgdP2;
String customTitleNgdP3;

const char* defaultTitleCT1(OperatingMode m) {
    return (m == MODE_NLMT) ? "Tải tiêu thụ" : "Công tơ 1";
}

const char* defaultTitleCT2(OperatingMode m) {
    return (m == MODE_NLMT) ? "Hòa lưới" : "Công tơ 2";
}

const char* defaultTitleTotal(OperatingMode m) {
    if (m == MODE_NLMT)  return "Lấy lưới";
    if (m == MODE_DIFF)  return "Hiệu CT1 - CT2";
    return "Tổng CT1 + CT2";
}

const char* titleCT1() {
    return customTitleCT1[operatingMode].length() ? customTitleCT1[operatingMode].c_str()
                                                    : defaultTitleCT1(operatingMode);
}

const char* titleCT2() {
    return customTitleCT2[operatingMode].length() ? customTitleCT2[operatingMode].c_str()
                                                    : defaultTitleCT2(operatingMode);
}

const char* titleTotal() {
    return customTitleTotal[operatingMode].length() ? customTitleTotal[operatingMode].c_str()
                                                       : defaultTitleTotal(operatingMode);
}

const char* modeLabel(OperatingMode m) {
    switch (m) {
        case MODE_SUM:     return "Tổng CT1 + CT2";
        case MODE_DIFF:    return "Hiệu CT1 - CT2";
        case MODE_NLMT:    return "NLMT";
        case MODE_NGAYDEM: return "Ngày & Đêm";
        default:           return "?";
    }
}

// ── Tên tiêu đề 4 màn hình con của chế độ "Ngày & Đêm" ────────
const char* defaultTitleNgdSetting() { return "Cài đặt thời gian"; }
const char* defaultTitleNgdP1()      { return "Thông số 1"; }
const char* defaultTitleNgdP2()      { return "Thông số 2"; }
const char* defaultTitleNgdP3()      { return "Thông số 3"; }

const char* titleNgdSetting() {
    return customTitleNgdSetting.length() ? customTitleNgdSetting.c_str() : defaultTitleNgdSetting();
}
const char* titleNgdP1() {
    return customTitleNgdP1.length() ? customTitleNgdP1.c_str() : defaultTitleNgdP1();
}
const char* titleNgdP2() {
    return customTitleNgdP2.length() ? customTitleNgdP2.c_str() : defaultTitleNgdP2();
}
const char* titleNgdP3() {
    return customTitleNgdP3.length() ? customTitleNgdP3.c_str() : defaultTitleNgdP3();
}

// ── Tính tiền điện bậc thang EVN + VAT 8% ────────────────────
// Đơn giá (đồng/kWh):
// Bậc 1: 0-50 → 1984, Bậc 2: 51-100 → 2050,
// Bậc 3: 101-200 → 2380, Bậc 4: 201-300 → 2998,
// Bậc 5: 301-400 → 3350, Bậc 6: 401+ → 3460
// Dùng chung cho màn hình LVGL (ui.cpp) và dữ liệu gửi lên MQTT/Home
// Assistant (mqtt_client.cpp) để 2 nơi luôn khớp số tiền hiển thị.
float calculateElectricityCost(float kwh) {
    if (kwh <= 0) return 0.0f;

    float cost = 0.0f;

    // Bậc 1: 0 - 50 kWh
    if (kwh <= 50) {
        cost += kwh * 1984;
    } else {
        cost += 50 * 1984;
        // Bậc 2: 51 - 100 kWh
        if (kwh <= 100) {
            cost += (kwh - 50) * 2050;
        } else {
            cost += 50 * 2050;
            // Bậc 3: 101 - 200 kWh
            if (kwh <= 200) {
                cost += (kwh - 100) * 2380;
            } else {
                cost += 100 * 2380;
                // Bậc 4: 201 - 300 kWh
                if (kwh <= 300) {
                    cost += (kwh - 200) * 2998;
                } else {
                    cost += 100 * 2998;
                    // Bậc 5: 301 - 400 kWh
                    if (kwh <= 400) {
                        cost += (kwh - 300) * 3350;
                    } else {
                        cost += 100 * 3350;
                        // Bậc 6: Từ 401 kWh trở lên
                        cost += (kwh - 400) * 3460;
                    }
                }
            }
        }
    }

    // Cộng thêm 8% thuế GTGT
    cost *= 1.08f;
    return cost;
}