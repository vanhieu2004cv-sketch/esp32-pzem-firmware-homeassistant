#include "globals.h"
#include "log.h"
#include "mode.h"
#include "storage.h"
#include "ngaydem.h"

// ═════════════════════════════════════════════════════════════
// PREFERENCES (NVS)
// ═════════════════════════════════════════════════════════════
void loadPrefs() {
    prefs.begin("pm", false);
    wifiSSID       = prefs.getString("ssid", "");
    wifiPASS       = prefs.getString("pass", "");
    mqttHost       = prefs.getString("mhost", "broker.hivemq.com");
    mqttPort       = prefs.getInt("mport", 1883);
    mqttUser       = prefs.getString("muser", "");
    mqttPass       = prefs.getString("mpass", "");
    operatingMode  = (OperatingMode)prefs.getInt("mode", (int)MODE_SUM);
    if (operatingMode >= MODE_COUNT) operatingMode = MODE_SUM;

    // Tên tiêu đề màn hình tùy chỉnh theo từng chế độ (rỗng = dùng mặc định)
    for (int i = 0; i < MODE_COUNT; i++) {
        customTitleCT1[i]   = prefs.getString(("ct1_" + String(i)).c_str(), "");
        customTitleCT2[i]   = prefs.getString(("ct2_" + String(i)).c_str(), "");
        customTitleTotal[i] = prefs.getString(("ctt_" + String(i)).c_str(), "");
    }

    // kWh từng công tơ
    kwhDay1   = prefs.getFloat("kd1", 0);
    kwhDay2   = prefs.getFloat("kd2", 0);
    lastDay   = prefs.getInt("ld",  0);
    lastMonth = prefs.getInt("lm",  0);
    lastYear  = prefs.getInt("ly",  0);
    eStart1   = prefs.getFloat("es1", 0);
    eStart2   = prefs.getFloat("es2", 0);
    mStart1   = prefs.getFloat("ms1", 0);
    mStart2   = prefs.getFloat("ms2", 0);
    for (int i = 0; i < 12; i++) {
        kwhMonth1[i] = prefs.getFloat(("a" + String(i)).c_str(), 0);
        kwhMonth2[i] = prefs.getFloat(("b" + String(i)).c_str(), 0);
    }

    // kWh tổng/hiệu (biểu đồ)
    kwhDayTotal = prefs.getFloat("kdt", 0);
    for (int i = 0; i < 12; i++) {
        kwhMonTotal[i]  = prefs.getFloat(("t" + String(i)).c_str(), 0);
        chartDataTotal[i] = kwhMonTotal[i];
    }

    // Lịch sử kWh theo ngày trong tháng ("Tháng X" / "Tháng X-1")
    prefs.getBytes("dhCur",  dayHistCurMonth,  sizeof(dayHistCurMonth));
    prefs.getBytes("dhPrev", dayHistPrevMonth, sizeof(dayHistPrevMonth));
    dayHistCurMonthIdx  = prefs.getInt("dhCurM",  0);
    dayHistCurYear      = prefs.getInt("dhCurY",  0);
    dayHistPrevMonthIdx = prefs.getInt("dhPrevM", 0);
    dayHistPrevYear     = prefs.getInt("dhPrevY", 0);

    // Lịch sử kWh theo ngày của từng công tơ riêng ("Tháng X" bên trong
    // "Công tơ 1" / "Công tơ 2")
    prefs.getBytes("dhCur1", dayHistCurMonth1, sizeof(dayHistCurMonth1));
    prefs.getBytes("dhCur2", dayHistCurMonth2, sizeof(dayHistCurMonth2));

    // Lịch sử biểu đồ năm trước ("Biểu đồ năm trước")
    prefs.getBytes("chPrev", chartDataTotalPrev, sizeof(chartDataTotalPrev));
    chartPrevYear = prefs.getInt("chPrevY", 0);

    // Snapshot kWh/tháng của từng công tơ vào cuối năm trước
    prefs.getBytes("mo1Prev", kwhMonth1Prev, sizeof(kwhMonth1Prev));
    prefs.getBytes("mo2Prev", kwhMonth2Prev, sizeof(kwhMonth2Prev));

    // ── Chế độ "Ngày & Đêm" ────────────────────────────────────
    customTitleNgdSetting = prefs.getString("ngdTSet", "");
    customTitleNgdP1      = prefs.getString("ngdTP1",  "");
    customTitleNgdP2      = prefs.getString("ngdTP2",  "");
    customTitleNgdP3      = prefs.getString("ngdTP3",  "");

    ngdStatus = (NgayDemStatus)prefs.getInt("ngdSt", (int)NGD_CHUA_CAUHINH);
    if (ngdStatus < NGD_CHUA_CAUHINH || ngdStatus > NGD_DA_KETTHUC) ngdStatus = NGD_CHUA_CAUHINH;
    ngdScreenIndex = prefs.getInt("ngdScr", 0);
    if (ngdScreenIndex < 0 || ngdScreenIndex >= (int)NGD_SCR_COUNT) ngdScreenIndex = 0;

    ngdCfgYear   = prefs.getInt("ngdCY", 2024);
    ngdCfgMonth  = prefs.getInt("ngdCM", 1);
    ngdCfgDay    = prefs.getInt("ngdCD", 1);
    ngdCfgHour   = prefs.getInt("ngdCH", 0);
    ngdCfgMinute = prefs.getInt("ngdCMi", 0);
    ngdSoNgay    = prefs.getInt("ngdSN", 1);

    ngdStartEpoch = prefs.getUInt("ngdSE", 0);
    ngdEndEpoch   = prefs.getUInt("ngdEE", 0);

    ngdKwhDay      = prefs.getFloat("ngdKD", 0);
    ngdKwhNight    = prefs.getFloat("ngdKN", 0);
    ngdEnergyStart = prefs.getFloat("ngdES", 0);
    ngdLastEnergy  = prefs.getFloat("ngdLE", 0);

    ngdPowerMax     = prefs.getFloat("ngdPMax", 0);
    ngdPowerMin     = prefs.getFloat("ngdPMin", 0);
    ngdPowerSum     = prefs.getFloat("ngdPSum", 0);
    ngdPowerSamples = prefs.getUInt("ngdPSmp", 0);

    prefs.end();

    // Nếu chưa cấu hình (hoặc dữ liệu NVS trống lần đầu boot) → luôn đề
    // xuất lại TGBĐ = thời gian hiện tại (ngdResetConfig() tự đọc RTC/NTP)
    if (ngdStatus == NGD_CHUA_CAUHINH) {
        ngdResetConfig();
    } else {
        ngdCursorPos = 0;
        ngdEditing   = false;
    }

    // Cập nhật chartData từng công tơ
    for (int i = 0; i < 12; i++)
        chartData[i] = kwhMonth1[i] + kwhMonth2[i];
}

void savePrefs() {
    prefs.begin("pm", false);
    prefs.putString("ssid", wifiSSID);
    prefs.putString("pass", wifiPASS);
    prefs.putString("mhost", mqttHost);
    prefs.putInt("mport", mqttPort);
    prefs.putString("muser", mqttUser);
    prefs.putString("mpass", mqttPass);
    prefs.putInt("mode", (int)operatingMode);

    // Tên tiêu đề màn hình tùy chỉnh theo từng chế độ (rỗng = dùng mặc định)
    for (int i = 0; i < MODE_COUNT; i++) {
        prefs.putString(("ct1_" + String(i)).c_str(), customTitleCT1[i]);
        prefs.putString(("ct2_" + String(i)).c_str(), customTitleCT2[i]);
        prefs.putString(("ctt_" + String(i)).c_str(), customTitleTotal[i]);
    }

    // kWh từng công tơ
    prefs.putFloat("kd1", kwhDay1);
    prefs.putFloat("kd2", kwhDay2);
    prefs.putInt("ld",  lastDay);
    prefs.putInt("lm",  lastMonth);
    prefs.putInt("ly",  lastYear);
    prefs.putFloat("es1", eStart1);
    prefs.putFloat("es2", eStart2);
    prefs.putFloat("ms1", mStart1);
    prefs.putFloat("ms2", mStart2);
    for (int i = 0; i < 12; i++) {
        prefs.putFloat(("a" + String(i)).c_str(), kwhMonth1[i]);
        prefs.putFloat(("b" + String(i)).c_str(), kwhMonth2[i]);
    }

    // kWh tổng/hiệu (biểu đồ)
    prefs.putFloat("kdt", kwhDayTotal);
    for (int i = 0; i < 12; i++) {
        prefs.putFloat(("t" + String(i)).c_str(), kwhMonTotal[i]);
    }

    // Lịch sử kWh theo ngày trong tháng ("Tháng X" / "Tháng X-1")
    prefs.putBytes("dhCur",  dayHistCurMonth,  sizeof(dayHistCurMonth));
    prefs.putBytes("dhPrev", dayHistPrevMonth, sizeof(dayHistPrevMonth));
    prefs.putInt("dhCurM",  dayHistCurMonthIdx);
    prefs.putInt("dhCurY",  dayHistCurYear);
    prefs.putInt("dhPrevM", dayHistPrevMonthIdx);
    prefs.putInt("dhPrevY", dayHistPrevYear);

    // Lịch sử kWh theo ngày của từng công tơ riêng ("Tháng X" bên trong
    // "Công tơ 1" / "Công tơ 2")
    prefs.putBytes("dhCur1", dayHistCurMonth1, sizeof(dayHistCurMonth1));
    prefs.putBytes("dhCur2", dayHistCurMonth2, sizeof(dayHistCurMonth2));

    // Lịch sử biểu đồ năm trước ("Biểu đồ năm trước")
    prefs.putBytes("chPrev", chartDataTotalPrev, sizeof(chartDataTotalPrev));
    prefs.putInt("chPrevY", chartPrevYear);

    // Snapshot kWh/tháng của từng công tơ vào cuối năm trước
    prefs.putBytes("mo1Prev", kwhMonth1Prev, sizeof(kwhMonth1Prev));
    prefs.putBytes("mo2Prev", kwhMonth2Prev, sizeof(kwhMonth2Prev));

    // ── Chế độ "Ngày & Đêm" ────────────────────────────────────
    prefs.putString("ngdTSet", customTitleNgdSetting);
    prefs.putString("ngdTP1",  customTitleNgdP1);
    prefs.putString("ngdTP2",  customTitleNgdP2);
    prefs.putString("ngdTP3",  customTitleNgdP3);

    prefs.putInt("ngdSt",  (int)ngdStatus);
    prefs.putInt("ngdScr", ngdScreenIndex);

    prefs.putInt("ngdCY",  ngdCfgYear);
    prefs.putInt("ngdCM",  ngdCfgMonth);
    prefs.putInt("ngdCD",  ngdCfgDay);
    prefs.putInt("ngdCH",  ngdCfgHour);
    prefs.putInt("ngdCMi", ngdCfgMinute);
    prefs.putInt("ngdSN",  ngdSoNgay);

    prefs.putUInt("ngdSE", ngdStartEpoch);
    prefs.putUInt("ngdEE", ngdEndEpoch);

    prefs.putFloat("ngdKD", ngdKwhDay);
    prefs.putFloat("ngdKN", ngdKwhNight);
    prefs.putFloat("ngdES", ngdEnergyStart);
    prefs.putFloat("ngdLE", ngdLastEnergy);

    prefs.putFloat("ngdPMax", ngdPowerMax);
    prefs.putFloat("ngdPMin", ngdPowerMin);
    prefs.putFloat("ngdPSum", ngdPowerSum);
    prefs.putUInt("ngdPSmp",  ngdPowerSamples);

    prefs.end();
}

void resetAllData() {
    // ── Reset bộ đếm kWh lũy kế THẬT SỰ bên trong chip PZEM ────
    // (trước đây chỉ set mốc eStart/mStart về 0 mà không đụng tới PZEM,
    // khiến kWh/ngày nhảy vọt lên đúng bằng kWh lũy kế cũ của PZEM ở
    // lần tính tiếp theo — đây là bug đã phát hiện, nay được sửa triệt để).
    bool r1 = pzSensor1.resetEnergy();
    bool r2 = pzSensor2.resetEnergy();
    addLog(r1 ? "[OK] PZEM1: Đã reset bộ đếm kWh" : "[LỖI] PZEM1: Reset kWh thất bại");
    addLog(r2 ? "[OK] PZEM2: Đã reset bộ đếm kWh" : "[LỖI] PZEM2: Reset kWh thất bại");

    kwhDay1 = kwhDay2 = kwhDayTotal = 0;
    // Nếu reset PZEM thành công → bộ đếm vật lý đã về 0 nên mốc = 0.
    // Nếu thất bại (mất tín hiệu/lỗi Modbus) → dùng giá trị đọc được gần nhất
    // làm mốc để KHÔNG bị nhảy số ở lần tính kWh tiếp theo.
    eStart1 = r1 ? 0 : rd1.kwh;
    eStart2 = r2 ? 0 : rd2.kwh;
    mStart1 = eStart1;
    mStart2 = eStart2;
    lastDay = lastMonth = lastYear = 0;
    for (int i = 0; i < 12; i++) {
        kwhMonth1[i] = kwhMonth2[i] = chartData[i] = 0;
        kwhMonTotal[i] = chartDataTotal[i] = 0;
        chartDataTotalPrev[i] = 0;
        kwhMonth1Prev[i] = kwhMonth2Prev[i] = 0;
    }
    chartPrevYear = 0;
    chartShowPrev = false;

    for (int i = 0; i < 31; i++) {
        dayHistCurMonth[i]  = dayHistPrevMonth[i] = 0;
        dayHistCurMonth1[i] = dayHistCurMonth2[i] = 0;
    }
    dayHistCurMonthIdx = dayHistCurYear = 0;
    dayHistPrevMonthIdx = dayHistPrevYear = 0;
    dayHistShowPrev = false;
    dayHistScroll   = 0;

    // ── Chế độ "Ngày & Đêm" ─── reset toàn bộ cấu hình + dữ liệu tích lũy
    ngdResetConfig();

    // KHÔNG xóa cấu hình WiFi (wifiSSID/wifiPASS) — chỉ xóa các giá trị dữ liệu
    // đã lưu (kWh, lịch sử...). Giữ nguyên wifiConnected/wifiConfigured hiện tại.
    savePrefs();
    addLog("[OK] Đã xóa hết dữ liệu đã lưu");
}

// ═════════════════════════════════════════════════════════════
// RESET WIFI ONLY — dùng khi vào lại màn hình "Cấu hình WiFi"
// Chỉ xóa SSID/Password khỏi NVS + RAM để thiết bị quay lại chế độ
// chờ cấu hình qua Web AP. KHÔNG đụng tới dữ liệu kWh/lịch sử đo
// (khác với resetAllData() vốn xóa toàn bộ dữ liệu đo lường).
// ═════════════════════════════════════════════════════════════
void resetWifiOnly() {
    wifiSSID = "";
    wifiPASS = "";
    wifiConnected  = false;
    wifiConfigured = false;
    WiFi.disconnect(false);  // KHÔNG deinit driver — startWifiPortal() sẽ chuyển sang AP ngay sau đó

    prefs.begin("pm", false);
    prefs.putString("ssid", "");
    prefs.putString("pass", "");
    prefs.end();

    addLog("[OK] Đã xóa cấu hình WiFi");
}