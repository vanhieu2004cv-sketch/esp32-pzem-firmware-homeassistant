#include "globals.h"
#include "log.h"
#include "storage.h"
#include "time_rtc.h"
#include "ngaydem.h"

// ═════════════════════════════════════════════════════════════
// CHẾ ĐỘ "NGÀY & ĐÊM" — logic cấu hình + cập nhật dữ liệu
// ═════════════════════════════════════════════════════════════

bool ngdIsDaytime(const DateTime &t) {
    int h = t.hour();
    return (h >= NGD_DAY_START_HOUR && h < NGD_DAY_END_HOUR);
}

// ── Đặt lại toàn bộ cấu hình/dữ liệu, đề xuất TGBĐ = hiện tại ────────
void ngdResetConfig() {
    ngdStatus      = NGD_CHUA_CAUHINH;
    ngdScreenIndex = NGD_SCR_SETTING;
    ngdCursorPos   = 0;
    ngdEditing     = false;

    DateTime now = getTime();
    ngdCfgYear   = now.year();
    ngdCfgMonth  = now.month();
    ngdCfgDay    = now.day();
    ngdCfgHour   = now.hour();
    ngdCfgMinute = now.minute();
    ngdSoNgay    = 1;

    ngdStartEpoch = 0;
    ngdEndEpoch   = 0;

    ngdKwhDay      = 0;
    ngdKwhNight    = 0;
    ngdEnergyStart = 0;
    ngdLastEnergy  = 0;

    ngdPowerMax     = 0;
    ngdPowerMin     = 0;
    ngdPowerSum     = 0;
    ngdPowerSamples = 0;
}

// Tính TGKT xem trước dựa trên cấu hình đang chỉnh (chưa lưu)
DateTime ngdPreviewEnd() {
    DateTime start(ngdCfgYear, ngdCfgMonth, ngdCfgDay, ngdCfgHour, ngdCfgMinute, 0);
    return start + TimeSpan(ngdSoNgay, 0, 0, 0);
}

// Nhãn văn bản của ngdStatus — dùng chung cho màn hình LCD và JSON/HA
const char* ngdStatusLabel() {
    switch (ngdStatus) {
        case NGD_CHUA_CAUHINH: return "Chưa cấu hình";
        case NGD_CHO_BATDAU:   return "Chờ bắt đầu";
        case NGD_DANG_CHAY:    return "Đang chạy";
        case NGD_DA_KETTHUC:   return "Đã kết thúc";
        default:                return "?";
    }
}

// ── Cập nhật dữ liệu chạy nền — gọi mỗi lần đọc PZEM khi đang ở
//    MODE_NGAYDEM ─────────────────────────────────────────────────────
void ngdUpdate(const DateTime &now) {
    if (operatingMode != MODE_NGAYDEM) return;
    if (ngdStatus == NGD_CHUA_CAUHINH) return;   // Chưa lưu cấu hình gì cả

    uint32_t nowEpoch = now.unixtime();
    static unsigned long tLastNgdSave = 0;

    if (ngdStatus == NGD_CHO_BATDAU) {
        if (nowEpoch >= ngdStartEpoch) {
            ngdStatus      = NGD_DANG_CHAY;
            ngdEnergyStart = rd1.ok ? rd1.kwh : 0;
            ngdLastEnergy  = ngdEnergyStart;
            addLog("[OK] Ngày&Đêm: Bắt đầu ghi dữ liệu");
            savePrefs();
        }
        return;
    }

    if (ngdStatus == NGD_DANG_CHAY) {
        if (nowEpoch >= ngdEndEpoch) {
            ngdStatus = NGD_DA_KETTHUC;
            addLog("[OK] Ngày&Đêm: Đã kết thúc quá trình ghi dữ liệu");
            savePrefs();
            return;
        }

        if (rd1.ok) {
            float delta = rd1.kwh - ngdLastEnergy;
            if (delta < 0) delta = 0;   // PZEM bị reset/lỗi đọc thoáng qua → bỏ qua delta âm
            ngdLastEnergy = rd1.kwh;

            if (ngdIsDaytime(now)) ngdKwhDay += delta;
            else                    ngdKwhNight += delta;

            float w = rd1.watt;
            if (ngdPowerSamples == 0 || w > ngdPowerMax) ngdPowerMax = w;
            if (ngdPowerSamples == 0 || w < ngdPowerMin) ngdPowerMin = w;
            ngdPowerSum += w;
            ngdPowerSamples++;
        }

        // Lưu định kỳ (không lưu mỗi lần đọc để tránh mòn flash NVS)
        unsigned long ms = millis();
        if (ms - tLastNgdSave >= 60000UL || tLastNgdSave == 0) {
            tLastNgdSave = ms;
            savePrefs();
        }
    }
}

// ── Nút bấm: màn hình "Cài đặt thời gian" ─────────────────────
void ngdCursorNext() {
    ngdCursorPos = (ngdCursorPos + 1) % 6;
}

void ngdEditIncrement() {
    switch (ngdCursorPos) {
        case 0: ngdCfgHour = (ngdCfgHour + 1) % 24; break;
        case 1: ngdCfgMinute = (ngdCfgMinute + 1) % 60; break;
        case 2: {
            int dim = daysInMonth(ngdCfgMonth, ngdCfgYear);
            ngdCfgDay = (ngdCfgDay % dim) + 1;
            break;
        }
        case 3: {
            ngdCfgMonth = (ngdCfgMonth % 12) + 1;
            int dim = daysInMonth(ngdCfgMonth, ngdCfgYear);
            if (ngdCfgDay > dim) ngdCfgDay = dim;
            break;
        }
        case 4: {
            ngdCfgYear++;
            if (ngdCfgYear > 2099) ngdCfgYear = 2024;
            int dim = daysInMonth(ngdCfgMonth, ngdCfgYear);
            if (ngdCfgDay > dim) ngdCfgDay = dim;
            break;
        }
        case 5: {
            ngdSoNgay++;
            if (ngdSoNgay > 99) ngdSoNgay = 1;
            break;
        }
    }
}

void ngdToggleEdit() {
    ngdEditing = !ngdEditing;
}

void ngdNextScreen() {
    ngdScreenIndex = (ngdScreenIndex + 1) % (int)NGD_SCR_COUNT;
}

// ── Giữ NEXT+OK ────────────────────────────────────────────────────
void ngdHandleComboHold() {
    if (ngdStatus == NGD_CHUA_CAUHINH) {
        // Lưu cấu hình & bắt đầu (hoặc chờ bắt đầu nếu TGBĐ ở tương lai)
        DateTime start(ngdCfgYear, ngdCfgMonth, ngdCfgDay, ngdCfgHour, ngdCfgMinute, 0);
        DateTime end = start + TimeSpan(ngdSoNgay, 0, 0, 0);
        ngdStartEpoch = start.unixtime();
        ngdEndEpoch   = end.unixtime();

        DateTime now = getTime();
        uint32_t nowEpoch = now.unixtime();

        ngdKwhDay = ngdKwhNight = 0;
        ngdPowerMax = ngdPowerMin = ngdPowerSum = 0;
        ngdPowerSamples = 0;

        if (nowEpoch >= ngdEndEpoch) {
            // TGKT đã ở quá khứ ngay lúc lưu (người dùng chỉnh lùi) → coi như xong luôn
            ngdStatus = NGD_DA_KETTHUC;
        } else if (nowEpoch >= ngdStartEpoch) {
            ngdStatus      = NGD_DANG_CHAY;
            ngdEnergyStart = rd1.ok ? rd1.kwh : 0;
            ngdLastEnergy  = ngdEnergyStart;
        } else {
            ngdStatus = NGD_CHO_BATDAU;
        }

        ngdEditing     = false;
        ngdScreenIndex = NGD_SCR_SETTING;
        savePrefs();
        addLog("[OK] Ngày&Đêm: Đã lưu cấu hình");
    } else {
        // Đặt lại giá trị, quay lại màn hình "Cài đặt thời gian" để cấu hình lại
        ngdResetConfig();
        savePrefs();
        addLog("[OK] Ngày&Đêm: Đã đặt lại, chờ cấu hình mới");
    }
}
