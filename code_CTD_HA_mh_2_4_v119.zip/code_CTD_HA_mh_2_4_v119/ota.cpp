#include "globals.h"
#include "ota.h"
#include "log.h"
#include <WiFi.h>
#include <HTTPClient.h>
#include <Update.h>
#include <ArduinoJson.h>

// Định nghĩa phiên bản hiện tại (Bạn có thể đổi chuỗi này để khớp với app)
const char* CURRENT_FIRMWARE_VERSION = "1.1.9"; 

static String downloadUrl      = "";
static String latestVersionStr = "";
static size_t updateSizeBytes  = 0;   // Dung lượng file .bin (byte) của bản mới

const char* getLatestVersionStr() { return latestVersionStr.c_str(); }
size_t      getUpdateSizeBytes()  { return updateSizeBytes; }

bool checkNewUpdate() {
    if (WiFi.status() != WL_CONNECTED) {
        addLog("[OTA] WiFi chưa kết nối");
        return false;
    }

    HTTPClient http;
    // Bắt buộc tuân thủ chuyển hướng URL vì GitHub luôn redirect dữ liệu raw
    http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
    http.begin(OTA_JSON_URL);

    int httpCode = http.GET();
    if (httpCode == HTTP_CODE_OK) {
        String payload = http.getString();
        StaticJsonDocument<256> doc;
        DeserializationError error = deserializeJson(doc, payload);

        if (error) {
            addLog("[OTA] Lỗi giải mã JSON");
            http.end();
            return false;
        }

        const char* latestVersion = doc["version"] | "";
        const char* binUrl = doc["url"] | "";

        if (strlen(latestVersion) > 0 && String(latestVersion) != String(CURRENT_FIRMWARE_VERSION)) {
            downloadUrl      = String(binUrl);
            latestVersionStr = String(latestVersion);
            char logBuf[64];
            snprintf(logBuf, sizeof(logBuf), "[OTA] Bản mới: %s -> %s", CURRENT_FIRMWARE_VERSION, latestVersion);
            addLog(logBuf);
            http.end();

            // Truy vấn thêm dung lượng file .bin (qua header Content-Length) để hiển thị cho người dùng
            updateSizeBytes = 0;
            HTTPClient httpSize;
            httpSize.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
            httpSize.begin(downloadUrl);
            int sizeCode = httpSize.GET();
            if (sizeCode == HTTP_CODE_OK) {
                int sz = httpSize.getSize();
                if (sz > 0) updateSizeBytes = (size_t)sz;
            }
            httpSize.end();

            return true;
        } else {
            addLog("[OTA] Đang là bản mới nhất");
        }
    } else {
        char logBuf[40];
        snprintf(logBuf, sizeof(logBuf), "[OTA] Check lỗi: Mã %d", httpCode);
        addLog(logBuf);
    }
    http.end();
    return false;
}

bool performOTAUpdate(OtaProgressCallback onProgress) {
    if (downloadUrl.length() == 0) {
        addLog("[OTA] URL tải trống");
        return false;
    }

    HTTPClient http;
    http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
    http.begin(downloadUrl);

    int httpCode = http.GET();
    if (httpCode != HTTP_CODE_OK) {
        addLog("[OTA] Không thể tải file .bin");
        http.end();
        return false;
    }

    int contentLength = http.getSize();
    if (contentLength <= 0) {
        addLog("[OTA] Size file sai");
        http.end();
        return false;
    }
    updateSizeBytes = (size_t)contentLength;

    if (!Update.begin(contentLength)) {
        addLog("[OTA] Thiếu bộ nhớ Flash");
        http.end();
        return false;
    }

    // Tải + ghi Flash theo từng khối nhỏ (thay vì Update.writeStream() một lần) để có thể
    // báo tiến trình (%, số KB đã tải) lên màn hình trong lúc chạy
    WiFiClient* client = http.getStreamPtr();
    uint8_t buff[1024];
    size_t written = 0;
    unsigned long lastDataMs = millis();

    if (onProgress) onProgress(OTA_STAGE_DOWNLOADING, 0, (size_t)contentLength);

    while (http.connected() && written < (size_t)contentLength) {
        size_t avail = client->available();
        if (avail > 0) {
            size_t toRead = (avail > sizeof(buff)) ? sizeof(buff) : avail;
            int readBytes = client->readBytes(buff, toRead);
            if (readBytes > 0) {
                size_t w = Update.write(buff, readBytes);
                written += w;
                lastDataMs = millis();
                if (onProgress) onProgress(OTA_STAGE_DOWNLOADING, written, (size_t)contentLength);
            }
        } else {
            // Không có dữ liệu mới trong 15 giây → coi như mất kết nối
            if (millis() - lastDataMs > 15000) {
                addLog("[OTA] Mất kết nối khi tải");
                Update.abort();
                http.end();
                return false;
            }
            delay(1);
        }
    }

    if (written != (size_t)contentLength) {
        char logBuf[48];
        snprintf(logBuf, sizeof(logBuf), "[OTA] Lỗi ghi: %u/%d", (unsigned)written, contentLength);
        addLog(logBuf);
        Update.abort();
        http.end();
        return false;
    }

    // Hoàn tất ghi Flash (kiểm tra checksum / finalize phân vùng)
    if (onProgress) onProgress(OTA_STAGE_WRITING, written, (size_t)contentLength);

    if (Update.end()) {
        if (Update.isFinished()) {
            addLog("[OTA] Xong! Đang Reboot...");
            if (onProgress) onProgress(OTA_STAGE_RESTARTING, written, (size_t)contentLength);
            http.end();
            delay(1000);
            ESP.restart();
            return true;
        } else {
            addLog("[OTA] Lỗi chưa hoàn tất");
        }
    } else {
        char logBuf[48];
        snprintf(logBuf, sizeof(logBuf), "[OTA] Lỗi End: %s", Update.errorString());
        addLog(logBuf);
    }

    http.end();
    return false;
}