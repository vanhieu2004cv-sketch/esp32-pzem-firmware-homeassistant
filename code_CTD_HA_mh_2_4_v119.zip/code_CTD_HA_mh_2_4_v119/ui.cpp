#include "globals.h"
#include "time_rtc.h"
#include "mode.h"
#include "storage.h"
#include "ui.h"
#include "wifi_portal.h"
#include "pzem.h"
#include "ota.h"
#include "ngaydem.h"

// ── Căn giữa dọc label trong thanh tiêu đề ──────────────────
// TITLE_H=30px. Font tiengviet_16 có line-height ~20px (ascent+descent).
// Offset y = (30 - 20) / 2 = 5  → label trông cân giữa dọc.
#define TITLE_TEXT_Y  5

// ══════════════════════════════════════════════════════════════
// HELPER WIDGETS
// ══════════════════════════════════════════════════════════════

// ── Tạo label với font NORMAL, nền trong suốt ────────────────
lv_obj_t* make_label(lv_obj_t *parent, int x, int y,
                     const char *txt, lv_color_t color) {
    lv_obj_t *lbl = lv_label_create(parent);
    lv_label_set_text(lbl, txt);
    lv_obj_set_style_text_color(lbl, color, 0);
    lv_obj_set_style_text_font(lbl, FONT_NORMAL, 0);
    lv_obj_set_style_bg_opa(lbl, LV_OPA_TRANSP, 0);
    lv_obj_set_pos(lbl, x, y);
    return lbl;
}

// ── Tạo label với font tùy chọn ──────────────────────────────
lv_obj_t* make_label_f(lv_obj_t *parent, int x, int y,
                       const char *txt, lv_color_t color,
                       const lv_font_t *font) {
    lv_obj_t *lbl = lv_label_create(parent);
    lv_label_set_text(lbl, txt);
    lv_obj_set_style_text_color(lbl, color, 0);
    lv_obj_set_style_text_font(lbl, font, 0);
    lv_obj_set_style_bg_opa(lbl, LV_OPA_TRANSP, 0);
    lv_obj_set_pos(lbl, x, y);
    return lbl;
}

// ── Tạo hình chữ nhật màu đặc (đường kẻ, cột biểu đồ…) ──────
lv_obj_t* make_rect(lv_obj_t *parent, int x, int y,
                    int w, int h, lv_color_t color) {
    lv_obj_t *obj = lv_obj_create(parent);
    lv_obj_set_size(obj, w, h);
    lv_obj_set_pos(obj, x, y);
    lv_obj_set_style_bg_color(obj, color, 0);
    lv_obj_set_style_bg_opa(obj, LV_OPA_COVER, 0);
    lv_obj_set_style_border_width(obj, 0, 0);
    lv_obj_set_style_pad_all(obj, 0, 0);
    lv_obj_set_style_radius(obj, 0, 0);
    lv_obj_clear_flag(obj, LV_OBJ_FLAG_SCROLLABLE);
    return obj;
}

// ── Tạo thanh tiêu đề không bo góc, chữ căn giữa dọc ────────
lv_obj_t* make_title_bar(lv_obj_t *parent, lv_color_t bg_color) {
    lv_obj_t *bar = lv_obj_create(parent);
    lv_obj_set_size(bar, SCR_W, TITLE_H);
    lv_obj_set_pos(bar, 0, 0);
    lv_obj_set_style_bg_color(bar, bg_color, 0);
    lv_obj_set_style_bg_opa(bar, LV_OPA_COVER, 0);
    lv_obj_set_style_border_width(bar, 0, 0);
    lv_obj_set_style_pad_all(bar, 0, 0);
    lv_obj_set_style_radius(bar, 0, 0);          // KHÔNG bo góc
    lv_obj_clear_flag(bar, LV_OBJ_FLAG_SCROLLABLE);
    return bar;
}

// ── Xóa và chuẩn bị màn hình mới ────────────────────────────
lv_obj_t* new_screen() {
    lv_obj_t *scr = lv_scr_act();
    lv_obj_clean(scr);
    lv_obj_set_style_bg_color(scr, LV_C_BG, 0);
    lv_obj_set_style_bg_opa(scr, LV_OPA_COVER, 0);
    lv_obj_set_style_radius(scr, 0, 0);
    lv_obj_clear_flag(scr, LV_OBJ_FLAG_SCROLLABLE);
    return scr;
}

// ── Vẽ thanh tiêu đề chung (chỉ có hh:mm và WiFi symbol) ────
static void draw_title_bar(lv_obj_t *parent, const char *name, const DateTime &now) {
    lv_obj_t *bar = make_title_bar(parent, LV_C_TITLE);

    // Tên màn hình — căn giữa dọc bên trái
    lv_obj_t *lbl_name = lv_label_create(bar);
    lv_label_set_text(lbl_name, name);
    lv_obj_set_style_text_color(lbl_name, LV_C_BG, 0);
    lv_obj_set_style_text_font(lbl_name, FONT_NORMAL, 0);
    lv_obj_set_style_bg_opa(lbl_name, LV_OPA_TRANSP, 0);
    lv_obj_align(lbl_name, LV_ALIGN_LEFT_MID, 6, 0);

    // Chỉ hiển thị hh:mm — căn giữa dọc, lệch về phải
    char tbuf[6];
    snprintf(tbuf, sizeof(tbuf), "%02d:%02d", now.hour(), now.minute());
    lv_obj_t *lbl_time = lv_label_create(bar);
    lv_label_set_text(lbl_time, tbuf);
    lv_obj_set_style_text_color(lbl_time, LV_C_BG, 0);
    lv_obj_set_style_text_font(lbl_time, FONT_NORMAL, 0);
    lv_obj_set_style_bg_opa(lbl_time, LV_OPA_TRANSP, 0);
    lv_obj_align(lbl_time, LV_ALIGN_RIGHT_MID, -46, 0);

    // Icon WiFi — sát mép phải, căn giữa dọc
    const char *wifi_sym;
    lv_color_t  wifi_col;
    if (wifiConnected)       { wifi_sym = LV_SYMBOL_WIFI;  wifi_col = LV_C_GREEN;  }
    else if (wifiConfigured) { wifi_sym = LV_SYMBOL_WIFI;  wifi_col = LV_C_ORANGE; }
    else                     { wifi_sym = LV_SYMBOL_CLOSE; wifi_col = LV_C_RED;    }

    lv_obj_t *lbl_wifi = lv_label_create(bar);
    lv_label_set_text(lbl_wifi, wifi_sym);
    lv_obj_set_style_text_color(lbl_wifi, wifi_col, 0);
    lv_obj_set_style_text_font(lbl_wifi, &lv_font_symbol_14, 0);
    lv_obj_set_style_bg_opa(lbl_wifi, LV_OPA_TRANSP, 0);
    lv_obj_align(lbl_wifi, LV_ALIGN_RIGHT_MID, -6, 0);
}

// ══════════════════════════════════════════════════════════════
// DRAW SCREENS
// ══════════════════════════════════════════════════════════════
void drawScreen() {
    if (inWifiConfig)  { drawWifiConfig();  return; }
    if (inLogView)     { drawLogView();     return; }
    if (inModeSelect)  { drawModeSelect();  return; }
    if (inDeviceInfo)  { drawDeviceInfo();  return; }
    if (inSettings)    { drawSettings();    return; }
    if (inCT1Detail)   { drawCT1Detail();   return; }
    if (inCT2Detail)   { drawCT2Detail();   return; }
    if (inTotalDetail) { drawTotalDetail(); return; }
    if (operatingMode == MODE_NGAYDEM) { drawNgayDem(); return; }
    switch (currentScreen) {
        case SCR_CT1:   drawCT(1);   break;
        case SCR_CT2:   drawCT(2);   break;
        case SCR_TOTAL: drawTotal(); break;
        default: break;
    }
}

// ── Màn hình Công tơ ─────────────────────────────────────────
void drawCT(int ct) {
    PZReading &rd = (ct == 1) ? rd1 : rd2;
    float kwDay   = (ct == 1) ? kwhDay1   : kwhDay2;
    float *kwMon  = (ct == 1) ? kwhMonth1 : kwhMonth2;

    DateTime now = getTime();
    // Tiêu đề động theo chế độ
    const char *title = (ct == 1) ? titleCT1() : titleCT2();

    lv_obj_t *scr = new_screen();
    draw_title_bar(scr, title, now);

    int y0 = TITLE_H + 10;
    int lh = 36;

    struct Row { const char *label; char val[32]; lv_color_t vc; };
    Row rows[5] = {};

    rows[0].label = "CS(W):";
    if (rd.ok) snprintf(rows[0].val, sizeof(rows[0].val), "%.0f W", rd.watt);
    else       strncpy(rows[0].val, "--", sizeof(rows[0].val));
    rows[0].vc = LV_C_VAL;

    rows[1].label = "kWh/ngày:";
    snprintf(rows[1].val, sizeof(rows[1].val), "%.2f kWh", kwDay);
    rows[1].vc = LV_C_GREEN;

    int cm = now.month() - 1;
    rows[2].label = "kWh/tháng:";
    snprintf(rows[2].val, sizeof(rows[2].val), "%.2f kWh", kwMon[cm]);
    rows[2].vc = LV_C_GREEN;

    rows[3].label = "Điện áp/Hz:";
    if (rd.ok) snprintf(rows[3].val, sizeof(rows[3].val), "%.1fV     %.1fHz", rd.volt, rd.hz);
    else       strncpy(rows[3].val, "--", sizeof(rows[3].val));
    rows[3].vc = LV_C_ORANGE;

    rows[4].label = "Dòng/Hệ số:";
    if (rd.ok) snprintf(rows[4].val, sizeof(rows[4].val), "%.2fA     PF%.2f", rd.amp, rd.pf);
    else       strncpy(rows[4].val, "--", sizeof(rows[4].val));
    rows[4].vc = LV_C_ORANGE;

    for (int i = 0; i < 5; i++) {
        make_label(scr, 8,   y0 + i * lh, rows[i].label, LV_C_GRAY);
        make_label(scr, 130, y0 + i * lh, rows[i].val,   rows[i].vc);
    }

    if (!rd.ok) make_label(scr, 190, y0, "--LỖI--", LV_C_RED);
}

// ── Tính tiền điện bậc thang EVN + VAT 8% ────────────────────
// (Hàm calculateElectricityCost() dùng chung được định nghĩa trong mode.cpp
// để mqtt_client.cpp cũng có thể gửi đúng số tiền này lên Home Assistant.)

// ── Màn hình Tổng / Hiệu / Lấy lưới (theo chế độ) ───────────
void drawTotal() {
    DateTime now = getTime();
    lv_obj_t *scr = new_screen();
    draw_title_bar(scr, titleTotal(), now);   // Tiêu đề động

    // Điều chỉnh lại y0 và khoảng cách dòng lh một chút để vừa vặn 4 hàng chữ + đường kẻ
    // Chiều cao màn hình là 240px, TITLE_H = 30px -> còn lại 210px.
    // lh = 46px giúp 4 hàng chiếm 184px, rất cân đối.
    int y0 = TITLE_H + 10;
    int lh = 46;
    char buf[24];

    // Công suất theo chế độ
    float wattVal = totalWattValue();

    // Hàng 1: Công suất
    const char *csLabel = (operatingMode == MODE_SUM) ? "Tổng CS:" : "Hiệu CS:";
    make_label(scr, 8, y0, csLabel, LV_C_GRAY);
    snprintf(buf, sizeof(buf), "%.0f W", wattVal);
    make_label(scr, 130, y0, buf, LV_C_VAL);
    make_rect(scr, 0, y0 + lh - 8, SCR_W, 1, lv_color_make(40, 40, 40)); // Đường kẻ mờ hơn cho đẹp

    // Hàng 2: kWh/ngày
    make_label(scr, 8, y0 + lh, "kWh/ngày:", LV_C_GRAY);
    snprintf(buf, sizeof(buf), "%.2f kWh", kwhDayTotal);
    make_label(scr, 130, y0 + lh, buf, LV_C_GREEN);
    make_rect(scr, 0, y0 + lh * 2 - 8, SCR_W, 1, lv_color_make(40, 40, 40));

    // Hàng 3: kWh/tháng
    int cm = now.month() - 1;
    float currentMonthKwh = kwhMonTotal[cm];
    make_label(scr, 8, y0 + lh * 2, "kWh/tháng:", LV_C_GRAY);
    snprintf(buf, sizeof(buf), "%.2f kWh", currentMonthKwh);
    make_label(scr, 130, y0 + lh * 2, buf, LV_C_GREEN);
    make_rect(scr, 0, y0 + lh * 3 - 8, SCR_W, 1, lv_color_make(40, 40, 40));

    // Hàng 4: Tiền điện ước tính (MỚI)
    float moneyCost = calculateElectricityCost(currentMonthKwh);
    make_label(scr, 8, y0 + lh * 3, "Tiền điện:", LV_C_GRAY);
    
    // Định dạng hiển thị không lấy phần thập phân (vì tiền đ nhỏ nhất là 1đ)
    snprintf(buf, sizeof(buf), "%.0f đ", moneyCost);
    make_label(scr, 130, y0 + lh * 3, buf, LV_C_ORANGE); // Màu cam nổi bật cho tiền điện
}

// ── Tính tổng số "hàng" của bảng ngày (mỗi hàng = 1 cặp ngày trái/phải) ──
// Dùng chung cho drawDayHist() và logic cuộn NEXT trong buttons.cpp.
int dayHistTotalRows() {
    int monIdx = dayHistShowPrev ? dayHistPrevMonthIdx : dayHistCurMonthIdx;
    int yr     = dayHistShowPrev ? dayHistPrevYear      : dayHistCurYear;
    if (monIdx < 1 || monIdx > 12) return 0;

    DateTime now = getTime();
    int daysTotal  = daysInMonth(monIdx, yr > 0 ? yr : now.year());
    int leftCount  = (daysTotal < 15) ? daysTotal : 15;
    int rightCount = (daysTotal > 15) ? daysTotal - 15 : 0;
    return (leftCount > rightCount) ? leftCount : rightCount;
}

// ── Màn hình "Tháng X" — lịch sử kWh từng ngày trong tháng ───
// Bố cục 3 cột, chia đều số ngày trong tháng cho từng cột để hiển thị
// đủ toàn bộ các ngày cùng lúc — không cần nhấn NEXT để xem thêm ngày.
// Dùng chung cho cả "Tổng", "Công tơ 1" và "Công tơ 2" — chỉ khác nhau
// ở mảng dữ liệu ngày (data) truyền vào.
// Ô của ngày hôm nay (chưa "chốt sổ") và các ngày trong tương lai hiển thị "-"
static void drawDayHistData(float *data) {
    DateTime now = getTime();
    lv_obj_t *scr = new_screen();

    int monIdx = dayHistCurMonthIdx;
    int yr     = dayHistCurYear;

    char title[16];
    if (monIdx >= 1 && monIdx <= 12)
        snprintf(title, sizeof(title), "Tháng %d", monIdx);
    else
        snprintf(title, sizeof(title), "Tháng ?");
    draw_title_bar(scr, title, now);

    if (monIdx < 1 || monIdx > 12) {
        make_label(scr, 6, SCR_H / 2 - 4, "Chưa có dữ liệu", LV_C_GRAY);
        make_label_f(scr, 8, SCR_H - 16, "NEXT: Biểu đồ  |  OK: Thoát", LV_C_GRAY, FONT_SMALL);
        return;
    }

    int daysTotal = daysInMonth(monIdx, yr > 0 ? yr : now.year());

    // Số ngày đã "chốt sổ" tính tới hiện tại (ngày hôm nay đang chạy dở,
    // chưa chốt sổ, nên chưa hiển thị số)
    int filledDays = daysTotal;
    if (monIdx == now.month() && yr == now.year())
        filledDays = now.day() - 1;

    // 3 cột, chia đều số ngày trong tháng cho từng cột (cột đầu có thể
    // nhiều hơn 1 ngày nếu số ngày trong tháng không chia hết cho 3)
    const int COLS = 3;
    int rowsPerCol = (daysTotal + COLS - 1) / COLS;
    int colW = SCR_W / COLS;

    int y0 = TITLE_H + 4;
    int lh = 16;   // dòng nhỏ (FONT_SMALL) để vừa đủ 11 hàng x 3 cột

    for (int c = 0; c < COLS; c++) {
        for (int r = 0; r < rowsPerCol; r++) {
            int day = c * rowsPerCol + r + 1;
            if (day > daysTotal) break;
            int x = c * colW + 4;
            int y = y0 + r * lh;

            char lbl[5], val[10];
            snprintf(lbl, sizeof(lbl), "%d:", day);
            make_label_f(scr, x, y, lbl, LV_C_GRAY, FONT_SMALL);
            if (day <= filledDays) snprintf(val, sizeof(val), "%.1f", data[day - 1]);
            else                    snprintf(val, sizeof(val), "-");
            make_label_f(scr, x + 30, y, val, LV_C_GREEN, FONT_SMALL);
        }
    }

    // Gợi ý điều hướng bên trong màn hình cha (Tổng/Công tơ 1/Công tơ 2)
    make_label_f(scr, 8, SCR_H - 16, "NEXT: Biểu đồ  |  OK: Thoát", LV_C_GRAY, FONT_SMALL);
}

void drawDayHist()    { drawDayHistData(dayHistCurMonth);  }  // "Tổng"
static void drawDayHistCT1() { drawDayHistData(dayHistCurMonth1); }
static void drawDayHistCT2() { drawDayHistData(dayHistCurMonth2); }

// ── Màn hình Biểu đồ năm Y — luôn hiển thị biểu đồ năm hiện tại ─────
// Dùng chung cho "Tổng", "Công tơ 1" và "Công tơ 2" — chỉ khác nhau ở
// mảng dữ liệu 12 tháng (data) truyền vào.
static void drawChartData(float *data) {
    DateTime now = getTime();
    lv_obj_t *scr = new_screen();

    int yearLabel = now.year();

    char title[20];
    snprintf(title, sizeof(title), "Biểu đồ %d", yearLabel);
    draw_title_bar(scr, title, now);

    // Dịch trục X lên để nhường chỗ cho chú thích bên dưới
    int cX = 32;
    int cY = TITLE_H + 6;
    int cW = SCR_W - cX - 8;           // 280px
    int cH = SCR_H - cY - 52;          // thu nhỏ lại để có chỗ cho nhãn tháng + chú thích

    // Biểu đồ dùng data (chartDataTotal hoặc chartDataTotalPrev)
    float maxVal = 1.0f;
    for (int i = 0; i < 12; i++)
        if (data[i] > maxVal) maxVal = data[i];

    // Nhãn maxVal (trục Y)
    char buf[8];
    snprintf(buf, sizeof(buf), "%.0f", maxVal);
    make_label_f(scr, 2, cY, buf, LV_C_GRAY, FONT_SMALL);

    // Trục Y (dọc)
    make_rect(scr, cX, cY, 1, cH + 1, LV_C_GRAY);
    // Trục X (ngang)
    make_rect(scr, cX, cY + cH, cW, 1, LV_C_GRAY);

    // Các cột tháng
    int barW = 13;
    int curMon = now.month() - 1;   // Highlight tháng hiện tại
    const char *monLabels[] = {"1","2","3","4","5","6","7","8","9","10","11","12"};

    for (int i = 0; i < 12; i++) {
        int bx = cX + 4 + i * (barW + 7);
        int bh = (int)((data[i] / maxVal) * (float)(cH - 2));
        if (bh < 0) bh = 0;
        lv_color_t col = (i == curMon) ? LV_C_ORANGE : LV_C_BLUE;

        if (bh > 0) make_rect(scr, bx, cY + cH - bh, barW, bh, col);

        // Nhãn tháng dưới cột
        make_label_f(scr, bx + 1, cY + cH + 5, monLabels[i], LV_C_GRAY, FONT_SMALL);
    }

    // Chú thích dưới biểu đồ
    make_label(scr, 70, cY + cH + 24, "Sản lượng tiêu thụ (kWh)", LV_C_ORANGE);
}

void drawChart()    { drawChartData(chartDataTotal); }  // "Tổng"
static void drawChartCT1() { drawChartData(kwhMonth1); }
static void drawChartCT2() { drawChartData(kwhMonth2); }

// ── kWh của "tháng X-1" (tháng liền trước tháng hiện tại) ────────────
// Dùng lại dữ liệu đã "chốt sổ" khi sang tháng mới (kwhMonTotal[]).
// Trường hợp tháng trước là tháng 12 của năm trước (đã bị reset khi sang
// năm mới) thì lấy từ snapshot chartDataTotalPrev[] được lưu lúc đó.
static float prevMonthKwhTotal() {
    if (dayHistPrevMonthIdx == 12 && dayHistPrevYear != dayHistCurYear)
        return chartDataTotalPrev[11];
    if (dayHistPrevMonthIdx >= 1 && dayHistPrevMonthIdx <= 12)
        return kwhMonTotal[dayHistPrevMonthIdx - 1];
    return 0;
}

// Y hệt prevMonthKwhTotal() ở trên nhưng cho riêng từng công tơ, dùng
// kwhMonth1[]/kwhMonth2[] (đã chốt sổ) hoặc kwhMonth1Prev[]/kwhMonth2Prev[]
// (snapshot cuối năm trước) khi tháng trước là tháng 12 năm trước.
static float prevMonthKwh1Total() {
    if (dayHistPrevMonthIdx == 12 && dayHistPrevYear != dayHistCurYear)
        return kwhMonth1Prev[11];
    if (dayHistPrevMonthIdx >= 1 && dayHistPrevMonthIdx <= 12)
        return kwhMonth1[dayHistPrevMonthIdx - 1];
    return 0;
}
static float prevMonthKwh2Total() {
    if (dayHistPrevMonthIdx == 12 && dayHistPrevYear != dayHistCurYear)
        return kwhMonth2Prev[11];
    if (dayHistPrevMonthIdx >= 1 && dayHistPrevMonthIdx <= 12)
        return kwhMonth2[dayHistPrevMonthIdx - 1];
    return 0;
}

// ── Màn hình "Thống kê tháng X-1" — số kWh và tiền điện của tháng trước ──
// Dùng chung cho "Tổng", "Công tơ 1" và "Công tơ 2" — chỉ khác nhau ở
// số kWh của tháng trước (prevKwh) truyền vào.
static void drawPrevMonthStatData(float prevKwh) {
    DateTime now = getTime();
    lv_obj_t *scr = new_screen();

    char title[24];
    if (dayHistPrevMonthIdx >= 1 && dayHistPrevMonthIdx <= 12)
        snprintf(title, sizeof(title), "T.kê tháng %d", dayHistPrevMonthIdx);
    else
        snprintf(title, sizeof(title), "T.kê tháng trước");
    draw_title_bar(scr, title, now);

    if (dayHistPrevMonthIdx < 1 || dayHistPrevMonthIdx > 12) {
        make_label(scr, 10, SCR_H / 2 - 6, "Chưa có dữ liệu", LV_C_GRAY);
        make_label_f(scr, 8, SCR_H - 16, "NEXT: Tháng X  |  OK: Thoát", LV_C_GRAY, FONT_SMALL);
        return;
    }

    float prevCost = calculateElectricityCost(prevKwh);

    int y0 = TITLE_H + 24;
    int lh = 46;
    char buf[24];

    // Dòng 1: Số kWh của tháng X-1
    make_label(scr, 8, y0, "Số kWh:", LV_C_GRAY);
    snprintf(buf, sizeof(buf), "%.2f kWh", prevKwh);
    make_label(scr, 130, y0, buf, LV_C_GREEN);
    make_rect(scr, 0, y0 + lh - 8, SCR_W, 1, lv_color_make(40, 40, 40));

    // Dòng 2: Tiền điện của tháng X-1
    make_label(scr, 8, y0 + lh, "Tiền điện:", LV_C_GRAY);
    snprintf(buf, sizeof(buf), "%.0f đ", prevCost);
    make_label(scr, 130, y0 + lh, buf, LV_C_ORANGE);

    make_label_f(scr, 8, SCR_H - 16, "NEXT: Tháng X  |  OK: Thoát", LV_C_GRAY, FONT_SMALL);
}

void drawPrevMonthStat()    { drawPrevMonthStatData(prevMonthKwhTotal()); }  // "Tổng"
static void drawPrevMonthStatCT1() { drawPrevMonthStatData(prevMonthKwh1Total()); }
static void drawPrevMonthStatCT2() { drawPrevMonthStatData(prevMonthKwh2Total()); }

// ── Điều phối 3 màn hình con bên trong "Tổng" ────────────────────────
// totalDetailIndex: 0 = "Tháng X", 1 = "Biểu đồ năm Y",
//                   2 = "Thống kê tháng X-1" — chuyển bằng NEXT, lặp vòng.
void drawTotalDetail() {
    switch (totalDetailIndex) {
        case 0:  drawDayHist();       break;
        case 1:  drawChart();         break;
        case 2:  drawPrevMonthStat(); break;
        default: drawDayHist();       break;
    }
}

// ── Điều phối 3 màn hình con bên trong "Công tơ 1" / "Công tơ 2" ────
// Y hệt drawTotalDetail() ở trên nhưng dùng dữ liệu riêng của từng công tơ.
void drawCT1Detail() {
    switch (ct1DetailIndex) {
        case 0:  drawDayHistCT1();       break;
        case 1:  drawChartCT1();         break;
        case 2:  drawPrevMonthStatCT1(); break;
        default: drawDayHistCT1();       break;
    }
}
void drawCT2Detail() {
    switch (ct2DetailIndex) {
        case 0:  drawDayHistCT2();       break;
        case 1:  drawChartCT2();         break;
        case 2:  drawPrevMonthStatCT2(); break;
        default: drawDayHistCT2();       break;
    }
}

// ── Màn hình Cấu hình WiFi (Web AP) ──────────────────────────
// Hiển thị khi user chọn "Kết nối WiFi" trong Cài đặt.
// Chức năng: xóa WiFi cũ, bật Access Point riêng để người dùng dùng
// điện thoại/máy tính kết nối vào rồi mở trình duyệt cấu hình WiFi + MQTT.
// Nhấn OK → quay về màn hình Cài đặt (AP vẫn chạy nền).
void drawWifiConfig() {
    lv_obj_t *scr = new_screen();

    // Thanh tiêu đề màu xanh dương
    lv_obj_t *bar = make_title_bar(scr, LV_C_BLUE);
    lv_obj_t *lbl_t = lv_label_create(bar);
    lv_label_set_text(lbl_t, "Cấu hình WiFi");
    lv_obj_set_style_text_color(lbl_t, LV_C_TEXT, 0);
    lv_obj_set_style_text_font(lbl_t, FONT_NORMAL, 0);
    lv_obj_set_style_bg_opa(lbl_t, LV_OPA_TRANSP, 0);
    lv_obj_align(lbl_t, LV_ALIGN_LEFT_MID, 4, 0);

    // Nội dung hướng dẫn
    String apName = deviceId + "_Config";
    const char *apPass = "12345678";

    // ── Vẽ QR code bên phải (quét để kết nối WiFi nhanh) ─────
    // Chuỗi chuẩn WiFi QR: WIFI:S:<ssid>;T:WPA;P:<pass>;;
    char qrStr[128];
    snprintf(qrStr, sizeof(qrStr), "WIFI:S:%s;T:WPA;P:%s;;", apName.c_str(), apPass);

    // QR size vừa với khoảng còn lại bên phải (SCR_W=320, text bên trái ~170px)
    int qrSize = 110;
    int qrX = SCR_W - qrSize - 6;
    int qrY = TITLE_H + 8;

    lv_obj_t *qr = lv_qrcode_create(scr, qrSize, lv_color_black(), lv_color_white());
    lv_qrcode_update(qr, qrStr, strlen(qrStr));
    lv_obj_set_pos(qr, qrX, qrY);

    // Label nhỏ dưới QR
    make_label_f(scr, qrX + 4, qrY + qrSize + 2, "Quét kết nối", LV_C_GRAY, FONT_SMALL);

    // ── Thông tin text bên trái ────────────────────────────────
    int y = TITLE_H + 10;
    int lx = 8;
    make_label_f(scr, lx, y,       "Kết nối WiFi:",    LV_C_VAL,   FONT_SMALL);
    make_label_f(scr, lx, y + 16,  apName.c_str(),     LV_C_GREEN, FONT_SMALL);

    make_label_f(scr, lx, y + 36,  "Mật khẩu:",        LV_C_VAL,   FONT_SMALL);
    make_label_f(scr, lx, y + 52,  apPass,             LV_C_GREEN, FONT_SMALL);

    make_label_f(scr, lx, y + 72,  "Mở trình duyệt:",  LV_C_VAL,   FONT_SMALL);
    make_label_f(scr, lx, y + 88,  "192.168.4.1",      LV_C_GREEN, FONT_SMALL);

    // Trạng thái AP
    make_label_f(scr, lx, y + 112,
                 wifiPortalActive ? "Đang phát sóng AP..." : "AP đang khởi động",
                 wifiPortalActive ? LV_C_GREEN : LV_C_ORANGE,
                 FONT_SMALL);

    // Hướng dẫn thoát
    make_label_f(scr, 8, SCR_H - 22, "OK: quay về Cài đặt", LV_C_GRAY, FONT_SMALL);
}

// ── Màn hình Cài đặt ─────────────────────────────────────────
void drawSettings() {
    DateTime now = getTime();
    lv_obj_t *scr = new_screen();
    draw_title_bar(scr, "Cài Đặt", now);

    int y0 = TITLE_H + 10;
    int lh = 28;

    // Cập nhật tăng số hàng lên 8 và thêm mục Thông tin thiết bị, Khởi động lại
    const char *rows[SETTINGS_ROWS] = {
        "1. Xóa hết dữ liệu",
        "2. Kết nối WiFi",
        "3. Nhật ký lỗi",
        "4. Kiểm tra cập nhật",
        "5. Chọn chế độ",
        "6. Thông tin thiết bị",
        "7. Khởi động lại",
        "8. Quay lại"
    };

    // Cuộn màn hình lên 1 hàng khi đến mục 7 trở đi, vì mục "8. Quay lại"
    // (index 7) nằm ngoài kích thước màn hình (SCR_H = 240px) nếu không cuộn.
    int scrollOffset = (settingsRow >= 6) ? 1 : 0;

    for (int i = 0; i < SETTINGS_ROWS; i++) {
        int ri = i - scrollOffset;
        if (ri < 0) continue; // Hàng đã cuộn lên khỏi màn hình, không vẽ

        bool selected = (i == settingsRow);
        lv_color_t bg = selected ? LV_C_HILIGHT : LV_C_BG;
        lv_color_t fg = selected ? LV_C_VAL     : LV_C_TEXT;

        lv_obj_t *row_bg = make_rect(scr, 0, y0 + ri * lh, SCR_W, lh - 2, bg);

        lv_obj_t *lbl = lv_label_create(row_bg);
        lv_label_set_text(lbl, rows[i]);
        lv_obj_set_style_text_color(lbl, fg, 0);
        lv_obj_set_style_text_font(lbl, FONT_NORMAL, 0);
        lv_obj_set_style_bg_opa(lbl, LV_OPA_TRANSP, 0);
        lv_obj_align(lbl, LV_ALIGN_LEFT_MID, 20, 0);

        if (selected) {
            lv_obj_t *arr = lv_label_create(row_bg);
            lv_label_set_text(arr, ">");
            lv_obj_set_style_text_color(arr, fg, 0);
            lv_obj_set_style_text_font(arr, FONT_NORMAL, 0);
            lv_obj_set_style_bg_opa(arr, LV_OPA_TRANSP, 0);
            lv_obj_align(arr, LV_ALIGN_RIGHT_MID, -10, 0);
        }

        if (i == 2) { // Hiển thị số lượng log bên cạnh dòng Nhật ký lỗi
            char cnt[8];
            snprintf(cnt, sizeof(cnt), "(%d)", logCount);
            lv_obj_t *lbl_cnt = lv_label_create(row_bg);
            lv_label_set_text(lbl_cnt, cnt);
            lv_obj_set_style_text_color(lbl_cnt, selected ? fg : LV_C_GRAY, 0);
            lv_obj_set_style_text_font(lbl_cnt, FONT_NORMAL, 0);
            lv_obj_set_style_bg_opa(lbl_cnt, LV_OPA_TRANSP, 0);
            lv_obj_align(lbl_cnt, LV_ALIGN_LEFT_MID, 140, 0);
        }
    }
}

// ── Màn hình Nhật ký lỗi ─────────────────────────────────────
void drawLogView() {
    lv_obj_t *scr = new_screen();

    // Thanh tiêu đề xanh tím tối, không bo góc
    lv_obj_t *bar = make_title_bar(scr, lv_color_make(48, 48, 96));

    lv_obj_t *lbl_hdr = lv_label_create(bar);
    lv_label_set_text(lbl_hdr, "Nhật ký lỗi");
    lv_obj_set_style_text_color(lbl_hdr, LV_C_TEXT, 0);
    lv_obj_set_style_text_font(lbl_hdr, FONT_NORMAL, 0);
    lv_obj_set_style_bg_opa(lbl_hdr, LV_OPA_TRANSP, 0);
    lv_obj_align(lbl_hdr, LV_ALIGN_LEFT_MID, 8, 0);

    char hdr[16];
    snprintf(hdr, sizeof(hdr), "%d/%d dòng", logCount, LOG_MAX);
    lv_obj_t *lbl_cnt = lv_label_create(bar);
    lv_label_set_text(lbl_cnt, hdr);
    lv_obj_set_style_text_color(lbl_cnt, LV_C_TEXT, 0);
    lv_obj_set_style_text_font(lbl_cnt, FONT_NORMAL, 0);
    lv_obj_set_style_bg_opa(lbl_cnt, LV_OPA_TRANSP, 0);
    lv_obj_align(lbl_cnt, LV_ALIGN_RIGHT_MID, -8, 0);

    if (logCount == 0) {
        make_label(scr, 30, SCR_H / 2 - 6, "Chưa có nhật ký", LV_C_GRAY);
        return;
    }

    if (logScroll > logCount - 1) logScroll = logCount - 1;
    if (logScroll < 0) logScroll = 0;

    // Dành 22px dưới cùng cho dòng hướng dẫn → tính vùng nội dung log
    // FONT_LOG ~14px cao/dòng → mỗi dòng log tối thiểu 16px, nếu wrap thêm 14px/dòng phụ
    int lineH   = 16;  // chiều cao 1 dòng text FONT_LOG
    int tsH     = 14;  // chiều cao timestamp FONT_SMALL
    int padBot  = 4;   // khoảng trống dưới mỗi entry trước đường kẻ
    int bottomReserve = 22;
    int yMax    = SCR_H - bottomReserve;  // vùng có thể vẽ log
    int msgW    = SCR_W - 70 - 6;        // chiều rộng vùng text msg (bắt đầu từ x=70)
    // Số ký tự xấp xỉ vừa 1 dòng với FONT_LOG (~7px/ký tự ASCII, ~8px/ký tự UTF-8)
    // Dùng 7px làm xấp xỉ để tính số dòng wrap
    const int charW = 7;
    int charsPerLine = msgW / charW;
    if (charsPerLine < 1) charsPerLine = 1;

    int y = TITLE_H + 6;

    for (int i = 0; ; i++) {
        int idx = logCount - 1 - logScroll - i;
        if (idx < 0) break;
        if (y >= yMax) break;  // hết vùng hiển thị

        const char *m = logBuf[idx].msg;
        lv_color_t col = LV_C_TEXT;
        if (strncmp(m, "[LỖI]", 7) == 0 || strncmp(m, "[LOI]", 5) == 0) col = LV_C_RED;
        else if (strncmp(m, "[WARN]", 6) == 0) col = LV_C_ORANGE;
        else if (strncmp(m, "[OK]", 4) == 0)   col = LV_C_GREEN;

        // Ước tính số dòng wrap của msg
        int msgLen = (int)strlen(m);
        int wrapLines = (msgLen + charsPerLine - 1) / charsPerLine;
        if (wrapLines < 1) wrapLines = 1;
        int entryH = wrapLines * lineH + padBot;  // tổng chiều cao entry này

        // Nếu entry này vượt ra ngoài vùng hiển thị thì dừng
        if (y + entryH > yMax) break;

        // Timestamp dùng FONT_SMALL (chiều cao ~12px, đặt căn giữa dọc entry)
        make_label_f(scr, 8, y, logBuf[idx].ts, LV_C_GRAY, FONT_SMALL);

        // Nội dung log — WRAP để không đè dòng bên dưới
        lv_obj_t *lbl_msg = make_label_f(scr, 70, y, m, col, FONT_LOG);
        lv_obj_set_width(lbl_msg, msgW);
        lv_label_set_long_mode(lbl_msg, LV_LABEL_LONG_WRAP);

        // Đường kẻ phân cách mờ đặt sau entry (bao gồm phần wrap)
        make_rect(scr, 0, y + entryH - 1, SCR_W, 1, lv_color_make(32, 32, 32));

        y += entryH;
    }

    // Hướng dẫn phím — đặt cách đáy để đảm bảo hiển thị đầy đủ
    make_label_f(scr, 8, SCR_H - 22, "NEXT:cuộn  |  OK:thoát", LV_C_GRAY, FONT_SMALL);
}

// ── Màn hình Chọn chế độ ─────────────────────────────────────
void drawModeSelect() {
    lv_obj_t *scr = new_screen();

    // Thanh tiêu đề màu xanh indigo
    lv_obj_t *bar = make_title_bar(scr, lv_color_make(48, 64, 160));
    lv_obj_t *lbl_t = lv_label_create(bar);
    lv_label_set_text(lbl_t, "Chọn chế độ");
    lv_obj_set_style_text_color(lbl_t, LV_C_TEXT, 0);
    lv_obj_set_style_text_font(lbl_t, FONT_NORMAL, 0);
    lv_obj_set_style_bg_opa(lbl_t, LV_OPA_TRANSP, 0);
    lv_obj_align(lbl_t, LV_ALIGN_LEFT_MID, 8, 0);

    // 4 chế độ
    const OperatingMode modes[MODE_COUNT] = { MODE_SUM, MODE_DIFF, MODE_NLMT, MODE_NGAYDEM };
    int y0 = TITLE_H + 8;
    int lh = 44;

    for (int i = 0; i < (int)MODE_COUNT; i++) {
        bool isCurrent  = (modes[i] == operatingMode);
        bool isSelected = (i == modeSelectRow);

        lv_color_t bg = isSelected  ? LV_C_HILIGHT : LV_C_BG;
        lv_color_t fg = isSelected  ? LV_C_VAL     : LV_C_TEXT;

        lv_obj_t *row_bg = make_rect(scr, 0, y0 + i * lh, SCR_W, lh - 4, bg);

        // Dấu ✓ nếu đang dùng chế độ này
        if (isCurrent) {
            lv_obj_t *lbl_chk = lv_label_create(row_bg);
            lv_label_set_text(lbl_chk, "*");
            lv_obj_set_style_text_color(lbl_chk, LV_C_GREEN, 0);
            lv_obj_set_style_text_font(lbl_chk, FONT_NORMAL, 0);
            lv_obj_set_style_bg_opa(lbl_chk, LV_OPA_TRANSP, 0);
            lv_obj_align(lbl_chk, LV_ALIGN_LEFT_MID, 8, 0);
        }

        lv_obj_t *lbl = lv_label_create(row_bg);
        lv_label_set_text(lbl, modeLabel(modes[i]));
        lv_obj_set_style_text_color(lbl, fg, 0);
        lv_obj_set_style_text_font(lbl, FONT_NORMAL, 0);
        lv_obj_set_style_bg_opa(lbl, LV_OPA_TRANSP, 0);
        lv_obj_align(lbl, LV_ALIGN_LEFT_MID, 28, 0);

        if (isSelected) {
            lv_obj_t *arr = lv_label_create(row_bg);
            lv_label_set_text(arr, ">");
            lv_obj_set_style_text_color(arr, fg, 0);
            lv_obj_set_style_text_font(arr, FONT_NORMAL, 0);
            lv_obj_set_style_bg_opa(arr, LV_OPA_TRANSP, 0);
            lv_obj_align(arr, LV_ALIGN_RIGHT_MID, -10, 0);
        }
    }

    // Hướng dẫn phím
    make_label_f(scr, 8, SCR_H - 22, "NEXT:chọn  |  OK:xác nhận", LV_C_GRAY, FONT_SMALL);
}

// ── Màn hình Thông tin thiết bị ───────────────────────────────
// Hiển thị: mã thiết bị, địa chỉ MAC, địa chỉ IP, tên WiFi đã kết nối,
// phiên bản firmware hiện tại. Chỉ xem, không có mục để chọn.
void drawDeviceInfo() {
    lv_obj_t *scr = new_screen();

    // Thanh tiêu đề màu xanh dương giống các màn hình phụ khác
    lv_obj_t *bar = make_title_bar(scr, LV_C_BLUE);
    lv_obj_t *lbl_t = lv_label_create(bar);
    lv_label_set_text(lbl_t, "Thông tin thiết bị");
    lv_obj_set_style_text_color(lbl_t, LV_C_TEXT, 0);
    lv_obj_set_style_text_font(lbl_t, FONT_NORMAL, 0);
    lv_obj_set_style_bg_opa(lbl_t, LV_OPA_TRANSP, 0);
    lv_obj_align(lbl_t, LV_ALIGN_LEFT_MID, 4, 0);

    int y0 = TITLE_H + 12;
    int lh = 30;

    // Mã thiết bị
    make_label_f(scr, 8, y0, "Mã thiết bị:", LV_C_GRAY, FONT_SMALL);
    make_label_f(scr, 130, y0, deviceId.length() ? deviceId.c_str() : "--", LV_C_TEXT, FONT_SMALL);

    // Địa chỉ MAC
    String macStr = WiFi.macAddress();
    make_label_f(scr, 8, y0 + lh, "Địa chỉ MAC:", LV_C_GRAY, FONT_SMALL);
    make_label_f(scr, 130, y0 + lh, macStr.c_str(), LV_C_TEXT, FONT_SMALL);

    // Địa chỉ IP
    String ipStr = wifiConnected ? WiFi.localIP().toString() : String("--");
    make_label_f(scr, 8, y0 + lh * 2, "Địa chỉ IP:", LV_C_GRAY, FONT_SMALL);
    make_label_f(scr, 130, y0 + lh * 2, ipStr.c_str(), LV_C_TEXT, FONT_SMALL);

    // Tên WiFi đã kết nối
    String ssidStr = wifiConnected ? WiFi.SSID() : String("--");
    make_label_f(scr, 8, y0 + lh * 3, "WiFi đã kết nối:", LV_C_GRAY, FONT_SMALL);
    make_label_f(scr, 130, y0 + lh * 3, ssidStr.c_str(), LV_C_TEXT, FONT_SMALL);

    // Phiên bản hiện tại
    make_label_f(scr, 8, y0 + lh * 4, "Phiên bản:", LV_C_GRAY, FONT_SMALL);
    make_label_f(scr, 130, y0 + lh * 4, CURRENT_FIRMWARE_VERSION, LV_C_TEXT, FONT_SMALL);

    // Hướng dẫn thoát
    make_label_f(scr, 8, SCR_H - 22, "OK: quay về Cài đặt", LV_C_GRAY, FONT_SMALL);
}

// ══════════════════════════════════════════════════════════════
// CHẾ ĐỘ "NGÀY & ĐÊM" — 4 màn hình con
// ══════════════════════════════════════════════════════════════

// Màu chữ của 1 field trong màn hình "Cài đặt thời gian":
// - Chưa lưu cấu hình (ngdStatus == NGD_CHUA_CAUHINH):
//     field đang chọn (chưa edit) → vàng
//     đang edit, chế độ TĂNG       → đỏ
//     đang edit, chế độ GIẢM       → xanh dương (để phân biệt rõ với TĂNG)
//     còn lại                      → trắng
// - Đã lưu cấu hình → luôn trắng (không còn field nào chỉnh được nữa)
static lv_color_t ngdFieldColor(int fieldIdx) {
    if (ngdStatus != NGD_CHUA_CAUHINH) return LV_C_TEXT;
    if (fieldIdx != ngdCursorPos)      return LV_C_TEXT;
    if (!ngdEditing) return LV_C_VAL;
    return ngdEditDecreasing ? LV_C_BLUE : LV_C_RED;
}

static const char* ngdStatusText() {
    return ngdStatusLabel();
}

static lv_color_t ngdStatusColor() {
    switch (ngdStatus) {
        case NGD_CHUA_CAUHINH: return LV_C_GRAY;
        case NGD_CHO_BATDAU:   return LV_C_ORANGE;
        case NGD_DANG_CHAY:    return LV_C_GREEN;
        case NGD_DA_KETTHUC:   return LV_C_BLUE;
        default:                return LV_C_TEXT;
    }
}

// ── Màn hình "Cài đặt thời gian" ──────────────────────────────
void drawNgdSetting() {
    DateTime now = getTime();
    lv_obj_t *scr = new_screen();
    draw_title_bar(scr, titleNgdSetting(), now);

    int y0 = TITLE_H + 14;
    int lh = 38;
    char buf[8];

    // ── Hàng 1: TGBĐ (5 field: Giờ/Phút/Ngày/Tháng/Năm) ────────
    make_label(scr, 8, y0, "TGBĐ:", LV_C_GRAY);

    bool saved = (ngdStatus != NGD_CHUA_CAUHINH);
    DateTime savedStart(ngdStartEpoch);
    int hh = saved ? savedStart.hour()   : ngdCfgHour;
    int mi = saved ? savedStart.minute() : ngdCfgMinute;
    int dd = saved ? savedStart.day()    : ngdCfgDay;
    int mo = saved ? savedStart.month()  : ngdCfgMonth;
    int yy = saved ? savedStart.year()   : ngdCfgYear;

    snprintf(buf, sizeof(buf), "%02d", hh);
    make_label(scr, 100, y0, buf, ngdFieldColor(0));
    make_label(scr, 122, y0, ":", LV_C_GRAY);
    snprintf(buf, sizeof(buf), "%02d", mi);
    make_label(scr, 132, y0, buf, ngdFieldColor(1));

    snprintf(buf, sizeof(buf), "%02d", dd);
    make_label(scr, 172, y0, buf, ngdFieldColor(2));
    make_label(scr, 194, y0, "/", LV_C_GRAY);
    snprintf(buf, sizeof(buf), "%02d", mo);
    make_label(scr, 204, y0, buf, ngdFieldColor(3));
    make_label(scr, 226, y0, "/", LV_C_GRAY);
    snprintf(buf, sizeof(buf), "%04d", yy);
    make_label(scr, 236, y0, buf, ngdFieldColor(4));

    // ── Hàng 2: Số ngày ──────────────────────────────────────
    make_label(scr, 8, y0 + lh, "Số ngày:", LV_C_GRAY);
    int soNgay = saved ? (int)((ngdEndEpoch - ngdStartEpoch) / 86400UL) : ngdSoNgay;
    snprintf(buf, sizeof(buf), "%d", soNgay);
    make_label(scr, 130, y0 + lh, buf, ngdFieldColor(5));

    // ── Hàng 3: TGKT (chỉ hiển thị, không chỉnh được) ─────────
    make_label(scr, 8, y0 + lh * 2, "TGKT:", LV_C_GRAY);
    DateTime end = saved ? DateTime(ngdEndEpoch) : ngdPreviewEnd();
    char endBuf[24];
    snprintf(endBuf, sizeof(endBuf), "%02d:%02d - %02d/%02d/%04d",
             end.hour(), end.minute(), end.day(), end.month(), end.year());
    make_label(scr, 130, y0 + lh * 2, endBuf, LV_C_GREEN);

    // ── Hàng 4: Trạng thái ─────────────────────────────────────
    make_label(scr, 8, y0 + lh * 3, "Trạng thái:", LV_C_GRAY);
    make_label(scr, 130, y0 + lh * 3, ngdStatusText(), ngdStatusColor());

    // Hướng dẫn phím theo trạng thái hiện tại
    if (ngdStatus == NGD_CHUA_CAUHINH) {
        if (ngdEditing) {
            make_label_f(scr, 8, SCR_H - 22,
                ngdEditDecreasing ? "NEXT:giảm giá trị | Giữ 3s:sang Tăng | OK:lưu"
                                  : "NEXT:tăng giá trị | Giữ 3s:sang Giảm | OK:lưu",
                LV_C_GRAY, FONT_SMALL);
        } else {
            make_label_f(scr, 8, SCR_H - 22, "NEXT:chọn field | OK:sửa | Giữ NEXT+OK:Lưu&Chạy",
                LV_C_GRAY, FONT_SMALL);
        }
    } else {
        make_label_f(scr, 8, SCR_H - 22, "NEXT:đổi màn hình | Giữ NEXT+OK:Đặt lại", LV_C_GRAY, FONT_SMALL);
    }
}

// ── Màn hình "Thông số 1" — kWh ban ngày/đêm/tổng/% ────────────
void drawNgdP1() {
    DateTime now = getTime();
    lv_obj_t *scr = new_screen();
    draw_title_bar(scr, titleNgdP1(), now);

    int y0 = TITLE_H + 10;
    int lh = 46;
    char buf[24];

    float total = ngdKwhDay + ngdKwhNight;
    float pctDay = (total > 0) ? (ngdKwhDay / total * 100.0f) : 0.0f;

    make_label(scr, 8, y0, "kWh ban ngày:", LV_C_GRAY);
    snprintf(buf, sizeof(buf), "%.2f kWh", ngdKwhDay);
    make_label(scr, 170, y0, buf, LV_C_ORANGE);
    make_rect(scr, 0, y0 + lh - 8, SCR_W, 1, lv_color_make(40, 40, 40));

    make_label(scr, 8, y0 + lh, "kWh ban đêm:", LV_C_GRAY);
    snprintf(buf, sizeof(buf), "%.2f kWh", ngdKwhNight);
    make_label(scr, 170, y0 + lh, buf, LV_C_BLUE);
    make_rect(scr, 0, y0 + lh * 2 - 8, SCR_W, 1, lv_color_make(40, 40, 40));

    make_label(scr, 8, y0 + lh * 2, "Tổng:", LV_C_GRAY);
    snprintf(buf, sizeof(buf), "%.2f kWh", total);
    make_label(scr, 170, y0 + lh * 2, buf, LV_C_GREEN);
    make_rect(scr, 0, y0 + lh * 3 - 8, SCR_W, 1, lv_color_make(40, 40, 40));

    make_label(scr, 8, y0 + lh * 3, "% Sd ban ngày:", LV_C_GRAY);
    snprintf(buf, sizeof(buf), "%.1f %%", pctDay);
    make_label(scr, 170, y0 + lh * 3, buf, LV_C_VAL);
}

// ── Màn hình "Thông số 2" — CS(W), Điện áp/Hz, Dòng/Hệ số (PZEM1) ──
void drawNgdP2() {
    DateTime now = getTime();
    lv_obj_t *scr = new_screen();
    draw_title_bar(scr, titleNgdP2(), now);

    int y0 = TITLE_H + 14;
    int lh = 42;
    char buf[24];

    make_label(scr, 8, y0, "CS(W):", LV_C_GRAY);
    if (rd1.ok) snprintf(buf, sizeof(buf), "%.0f W", rd1.watt);
    else        strncpy(buf, "--", sizeof(buf));
    make_label(scr, 170, y0, buf, LV_C_VAL);

    make_label(scr, 8, y0 + lh, "Điện áp/Hz:", LV_C_GRAY);
    if (rd1.ok) snprintf(buf, sizeof(buf), "%.1fV  %.1fHz", rd1.volt, rd1.hz);
    else        strncpy(buf, "--", sizeof(buf));
    make_label(scr, 170, y0 + lh, buf, LV_C_ORANGE);

    make_label(scr, 8, y0 + lh * 2, "Dòng/Hệ số:", LV_C_GRAY);
    if (rd1.ok) snprintf(buf, sizeof(buf), "%.2fA  PF%.2f", rd1.amp, rd1.pf);
    else        strncpy(buf, "--", sizeof(buf));
    make_label(scr, 170, y0 + lh * 2, buf, LV_C_ORANGE);

    if (!rd1.ok) make_label(scr, 8, y0 + lh * 3, "--LỖI PZEM1--", LV_C_RED);
}

// ── Màn hình "Thông số 3" — CS Max/TB/Min (PZEM1, lúc đang chạy) ──
void drawNgdP3() {
    DateTime now = getTime();
    lv_obj_t *scr = new_screen();
    draw_title_bar(scr, titleNgdP3(), now);

    int y0 = TITLE_H + 14;
    int lh = 42;
    char buf[24];

    float avg = (ngdPowerSamples > 0) ? (ngdPowerSum / (float)ngdPowerSamples) : 0.0f;

    make_label(scr, 8, y0, "CS Max:", LV_C_GRAY);
    snprintf(buf, sizeof(buf), "%.0f W", ngdPowerMax);
    make_label(scr, 170, y0, buf, LV_C_RED);

    make_label(scr, 8, y0 + lh, "CS TB:", LV_C_GRAY);
    snprintf(buf, sizeof(buf), "%.0f W", avg);
    make_label(scr, 170, y0 + lh, buf, LV_C_VAL);

    make_label(scr, 8, y0 + lh * 2, "CS Min:", LV_C_GRAY);
    snprintf(buf, sizeof(buf), "%.0f W", ngdPowerMin);
    make_label(scr, 170, y0 + lh * 2, buf, LV_C_GREEN);
}

// ── Điều phối 4 màn hình con theo ngdScreenIndex ──────────────
void drawNgayDem() {
    switch (ngdScreenIndex) {
        case NGD_SCR_SETTING: drawNgdSetting(); break;
        case NGD_SCR_P1:       drawNgdP1();      break;
        case NGD_SCR_P2:       drawNgdP2();      break;
        case NGD_SCR_P3:       drawNgdP3();      break;
        default:                drawNgdSetting(); break;
    }
}