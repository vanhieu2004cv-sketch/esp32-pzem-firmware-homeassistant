// esp32wroom
#include <Preferences.h>
#include <Matter.h>
#if !CONFIG_ENABLE_CHIPOBLE
// ESP32 WROOM (Xtensa) KHÔNG hỗ trợ commissioning qua BLE (dùng Bluedroid, không tương thích CHIPOBLE)
// -> luôn phải dùng WiFi thủ công như dưới đây, không có cách nào bật BLE commissioning trên chip này.
#include <WiFi.h>
const char *ssid = "Mang 2.4G";         // Đổi thành SSID WiFi của bạn
const char *password = "dauloxo@"; // Đổi thành mật khẩu WiFi của bạn
#endif

#define RL1_PIN 12 // LÊN
#define RL2_PIN 13 // DỪNG
#define RL3_PIN 14 // XUỐNG
#define SW1_PIN 16 // SW lên
#define SW2_PIN 17 // SW dừng
#define SW3_PIN 5 // SW xuống
#define LED1_PIN -1 // Led lên
#define LED2_PIN -1 // Led dừng
#define LED3_PIN -1 // Led xuống
#define BT_SET_PIN 15 // Nút set hành trình
#define LED_HT_PIN 2 // Led hành trình
#define MATTER_RESET_PIN 0 // Nút reset Matter (GPIO0 - nút BOOT), nhấn 5 lần để reset

int i = 0;
const unsigned long dotre = 500; // Chờ 500ms
bool lastSW1State = HIGH, lastSW2State = HIGH, lastSW3State = HIGH; // Trạng thái ban đầu của nút

// Biến dùng để đếm thời gian ReLay được bật
unsigned long RelayOnTime = 0;
const unsigned long RelayTimeout = 500; // 500ms

// ==================== SET HÀNH TRÌNH ====================
Preferences prefs;

const unsigned long SET_HOLD_TIME = 5000; // giữ 5s để vào chế độ set

enum SetState {
  SET_WAIT_UP,       // chờ nhấn SW1 để mở
  SET_UP_RUNNING,     // đang mở, chờ SW2 để dừng
  SET_UP_STOPPED,     // đã dừng, chờ nhấn SET để lưu HT trên
  SET_WAIT_DOWN,      // chờ nhấn SW3 để đóng
  SET_DOWN_RUNNING,    // đang đóng, chờ SW2 để dừng
  SET_DOWN_STOPPED,   // đã dừng, chờ nhấn SET để lưu HT dưới
  SET_READY_FINAL     // đã lưu cả 2, chờ nhấn SET lần cuối để lưu tổng
};

bool setModeActive = false;
SetState setState = SET_WAIT_UP;

unsigned long startUpTime = 0, stopUpTime = 0;
unsigned long startDownTime = 0, stopDownTime = 0;
unsigned long t_up = 0, t_down = 0;
unsigned long totalTravelTime = 0; // tổng thời gian hành trình 0% -> 100% (ms)
float msPerPercent = 0;

int currentPercent = 0; // vị trí cửa ước lượng hiện tại (0% đóng, 100% mở)

bool btSetLastState = HIGH;
unsigned long btSetPressStart = 0;
bool btSetLongTriggered = false;

// ==================== ĐIỀU KHIỂN THEO % ====================
bool percentMoveActive = false;
int percentMoveStartPercent = 0, percentMoveTargetPercent = 0;
unsigned long percentMoveStartTime = 0, percentMoveDuration = 0;
bool percentMoveNeedStop = true;
unsigned long lastPercentPrint = 0;

// ==================== MATTER (Tuya/Aqara/Home Assistant...) ====================
// Cửa cuốn chỉ có lift (lên/xuống), không có tilt -> dùng kiểu ROLLERSHADE
MatterWindowCovering RollingDoor;

// Quy ước Matter: 0% = mở hoàn toàn, 100% = đóng hoàn toàn
// Quy ước code hiện tại (currentPercent): 0% = đóng hoàn toàn, 100% = mở hoàn toàn -> phải đảo ngược khi đồng bộ
unsigned long lastMatterPrintTime = 0; // in nhắc mã pairing định kỳ khi chưa commissioning

// ==================== RESET MATTER (nhấn GPIO0 x5) ====================
bool matterResetLastState = HIGH;
int matterResetPressCount = 0;
unsigned long matterResetWindowStart = 0;
const unsigned long MATTER_RESET_WINDOW = 3000; // phải nhấn đủ 5 lần trong vòng 3s
const int MATTER_RESET_PRESS_NEEDED = 5;

void setup() {
  Serial.begin(115200);

  pinMode(SW1_PIN, INPUT_PULLUP);
  pinMode(SW2_PIN, INPUT_PULLUP);
  pinMode(SW3_PIN, INPUT_PULLUP);
  pinMode(RL1_PIN, OUTPUT);
  pinMode(RL2_PIN, OUTPUT);
  pinMode(RL3_PIN, OUTPUT);
  pinMode(LED1_PIN, OUTPUT);
  pinMode(LED2_PIN, OUTPUT);
  pinMode(LED3_PIN, OUTPUT);
  pinMode(BT_SET_PIN, INPUT_PULLUP);
  pinMode(LED_HT_PIN, OUTPUT);
  pinMode(MATTER_RESET_PIN, INPUT_PULLUP);

  loadHanhTrinh();

#if !CONFIG_ENABLE_CHIPOBLE
  Serial.print(F("Dang ket noi WiFi: "));
  Serial.println(ssid);
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println();
  Serial.print(F("WiFi da ket noi, IP: "));
  Serial.println(WiFi.localIP());
#endif

  // Vị trí ban đầu gửi cho Matter phải đảo ngược quy ước (Matter: 0=mo, 100=dong)
  uint8_t initialMatterLift = 100 - currentPercent;
  RollingDoor.begin(initialMatterLift, 0, MatterWindowCovering::ROLLERSHADE);

  RollingDoor.onOpen(matterOpen);
  RollingDoor.onClose(matterClose);
  RollingDoor.onStop(matterStop);
  RollingDoor.onGoToLiftPercentage(matterGoToLiftPercentage);

  Matter.begin();

  if (Matter.isDeviceCommissioned()) {
    Serial.println(F("Matter da duoc commissioning, san sang su dung voi Tuya/Aqara/Home Assistant..."));
  } else {
    Serial.println(F("Matter CHUA duoc commissioning."));
    Serial.print(F("Ma pairing thu cong: "));
    Serial.println(Matter.getManualPairingCode());
    Serial.print(F("QR code: "));
    Serial.println(Matter.getOnboardingQRCodeUrl());
  }
}

void loop() {
  // Nhắc lại mã pairing mỗi 10s nếu chưa commissioning (không chặn loop để nút vẫn dùng được)
  if (!Matter.isDeviceCommissioned() && millis() - lastMatterPrintTime >= 10000) {
    lastMatterPrintTime = millis();
    Serial.println(F("Matter chua duoc commissioning. Ma pairing:"));
    Serial.println(Matter.getManualPairingCode());
  }

  handleSetButton(); // luôn theo dõi nút SET (giữ 5s / nhấn 1 lần)
  handleMatterResetButton(); // luôn theo dõi nút GPIO0 (nhấn 5 lần để reset Matter)

  if (setModeActive) {
    chedo_setmode(); // trong chế độ set: SW1/SW2/SW3 phục vụ việc set hành trình
  } else {
    chedo_congtac(); // chế độ vận hành bình thường
    handleSerialInput(); // cho nhập % qua Serial để test khi không set
    updatePercentMove();
  }

  // Nếu RL đang bật và đã qua 0.5s thì tắt
  if ((i == 1 || i == 2 || i == 3) && (millis() - RelayOnTime >= RelayTimeout)) {
    digitalWrite(RL1_PIN, 0);
    digitalWrite(RL3_PIN, 0);
    digitalWrite(RL2_PIN, 0);
    digitalWrite(LED1_PIN, 0);
    digitalWrite(LED2_PIN, 0);
    digitalWrite(LED3_PIN, 0);
  }
}

void van_hanh() {
  // Cửa chạy lên
  if (i == 1) {
    digitalWrite(RL2_PIN, 0);
    digitalWrite(RL3_PIN, 0);
    digitalWrite(RL1_PIN, 1);

    digitalWrite(LED1_PIN, 1);
    digitalWrite(LED2_PIN, 0);
    digitalWrite(LED3_PIN, 0);
    RelayOnTime = millis(); // Ghi lại thời điểm RL được bật
  }

  // Cửa Dừng
  if (i == 2) {
    digitalWrite(RL1_PIN, 0);
    digitalWrite(RL3_PIN, 0);
    digitalWrite(RL2_PIN, 1);

    digitalWrite(LED1_PIN, 0);
    digitalWrite(LED2_PIN, 1);
    digitalWrite(LED3_PIN, 0);
    RelayOnTime = millis(); // Ghi lại thời điểm RL được bật
  }

  // Cửa chạy xuống
  if (i == 3) {
    digitalWrite(RL1_PIN, 0);
    digitalWrite(RL2_PIN, 0);
    digitalWrite(RL3_PIN, 1);

    digitalWrite(LED1_PIN, 0);
    digitalWrite(LED2_PIN, 0);
    digitalWrite(LED3_PIN, 1);
    RelayOnTime = millis(); // Ghi lại thời điểm RL được bật
  }
}

void chedo_congtac() {
  // Lên
  bool SW1 = digitalRead(SW1_PIN);
  if (SW1 == 0 && lastSW1State == HIGH) {
    startManualMove(1); // mở tay -> chạy relay + bắt đầu theo dõi/in % tiến tới 100%
  }
  lastSW1State = SW1;

  // Dừng
  bool SW2 = digitalRead(SW2_PIN);
  if (SW2 == 0 && lastSW2State == HIGH) { // đã sửa lỗi so sánh nhầm lastSW3State
    i = 2;
    van_hanh();
    stopManualMove(); // dừng tay giữa chừng -> chốt lại currentPercent theo thời gian đã chạy
  }
  lastSW2State = SW2;

  // Xuống
  bool SW3 = digitalRead(SW3_PIN);
  if (SW3 == 0 && lastSW3State == HIGH) {
    startManualMove(3); // đóng tay -> chạy relay + bắt đầu theo dõi/in % tiến tới 0%
  }
  lastSW3State = SW3;
}

// Nhấn SW1 (dir=1, đích 100%) hoặc SW3 (dir=3, đích 0%) bằng tay:
// vẫn chạy relay như cũ, đồng thời bật tiến trình đếm % giống hệt lệnh nhập qua Serial
// (không tự gửi lệnh dừng khi tới đích, vì 0%/100% coi như chạy tới giới hạn vật lý).
void startManualMove(int dir) {
  i = dir;
  van_hanh();
  setMatterMoving(dir == 1); // báo cho app biết cửa đang chạy lên/xuống

  if (totalTravelTime == 0) return; // chưa set hành trình thì chỉ chạy relay, không có % để in

  int target = (dir == 1) ? 100 : 0;
  if (target == currentPercent) return;

  percentMoveActive = true;
  percentMoveStartPercent = currentPercent;
  percentMoveTargetPercent = target;
  percentMoveStartTime = millis();
  percentMoveDuration = (unsigned long)(abs(target - currentPercent) * msPerPercent);
  percentMoveNeedStop = false; // dừng bằng tay (SW2), không tự gửi lệnh dừng
  lastPercentPrint = 0;

  reportMatterTarget(target);

  Serial.print(dir == 1 ? F("Dang mo cua (tay)... huong toi ") : F("Dang dong cua (tay)... huong toi "));
  Serial.print(target);
  Serial.println(F("%"));
}

// Nhấn SW2 bằng tay trong lúc đang có tiến trình % (từ SW1/SW3 hoặc Serial):
// chốt lại currentPercent theo tỉ lệ thời gian đã chạy thay vì huỷ bỏ không rõ vị trí.
void stopManualMove() {
  if (!percentMoveActive) {
    setMatterStalled(); // chưa set hành trình nên không có % để tính, nhưng vẫn báo đã dừng
    return;
  }

  unsigned long elapsed = millis() - percentMoveStartTime;
  float progress = (percentMoveDuration > 0) ? min(1.0f, (float)elapsed / (float)percentMoveDuration) : 1.0f;
  currentPercent = percentMoveStartPercent +
                   (int)((percentMoveTargetPercent - percentMoveStartPercent) * progress);

  percentMoveActive = false;
  saveHanhTrinh();

  reportMatterPosition(currentPercent);
  setMatterStalled();

  Serial.print(F("Da dung. Vi tri hien tai: "));
  Serial.print(currentPercent);
  Serial.println(F("%"));
}

// ---- Đồng bộ vị trí/trạng thái sang Matter (để app Tuya/Aqara/HA hiển thị đúng) ----
void reportMatterPosition(int pct) {
  // pct theo quy ước code (0=đóng,100=mở) -> đổi sang quy ước Matter (0=mở,100=đóng)
  uint16_t matterPercent100ths = (uint16_t)((100 - pct) * 100);
  RollingDoor.setCurrentLiftPercent100ths(matterPercent100ths);
}

void reportMatterTarget(int pct) {
  uint16_t matterPercent100ths = (uint16_t)((100 - pct) * 100);
  RollingDoor.setTargetLiftPercent100ths(matterPercent100ths);
}

void setMatterMoving(bool movingUp) {
  RollingDoor.setOperationalState(
    MatterWindowCovering::LIFT,
    movingUp ? MatterWindowCovering::MOVING_UP_OR_OPEN : MatterWindowCovering::MOVING_DOWN_OR_CLOSE
  );
}

void setMatterStalled() {
  RollingDoor.setOperationalState(MatterWindowCovering::LIFT, MatterWindowCovering::STALL);
}

// ---- Callback khi lệnh Matter đến từ app Tuya/Aqara/Home Assistant... ----
bool matterOpen() { // app bấm nút "Mở"
  startManualMove(1);
  return true;
}

bool matterClose() { // app bấm nút "Đóng"
  startManualMove(3);
  return true;
}

bool matterStop() { // app bấm nút "Dừng"
  i = 2;
  van_hanh();
  stopManualMove();
  return true;
}

bool matterGoToLiftPercentage(uint8_t liftPercent) { // app kéo thanh tiến trình
  // liftPercent theo quy ước Matter (0=mo,100=dong) -> đổi sang quy ước code (0=đóng,100=mở)
  int target = 100 - liftPercent;
  moveToPercent(target);
  return true;
}

// ==================== RESET MATTER (nhấn GPIO0 x5 trong 3s) ====================
void handleMatterResetButton() {
  // Nếu đã quá thời gian cho phép mà chưa đủ số lần nhấn -> huỷ đếm, bắt đầu lại từ đầu
  if (matterResetPressCount > 0 && millis() - matterResetWindowStart > MATTER_RESET_WINDOW) {
    matterResetPressCount = 0;
  }

  bool state = digitalRead(MATTER_RESET_PIN);
  if (state == LOW && matterResetLastState == HIGH) { // vừa nhấn xuống (cạnh xuống)
    if (matterResetPressCount == 0) {
      matterResetWindowStart = millis(); // bắt đầu tính giờ từ lần nhấn đầu tiên
    }
    matterResetPressCount++;

    Serial.print(F("GPIO0 nhan lan "));
    Serial.print(matterResetPressCount);
    Serial.print(F("/"));
    Serial.println(MATTER_RESET_PRESS_NEEDED);

    if (matterResetPressCount >= MATTER_RESET_PRESS_NEEDED) {
      Serial.println(F("=== RESET MATTER (decommission) - thiet bi se khoi dong lai ==="));
      blinkLedHT(10, 100); // chớp nhanh 10 lần báo đang reset

      Matter.decommission(); // xoá thông tin fabric/mạng Matter đã lưu, đưa về trạng thái chưa commissioning

      matterResetPressCount = 0;
      delay(500);
      ESP.restart(); // khởi động lại để Matter vào lại trạng thái chờ commissioning sạch
    }
  }
  matterResetLastState = state;
}

// ==================== NÚT SET (giữ 5s / nhấn 1 lần) ====================
void handleSetButton() {
  bool btSetState = digitalRead(BT_SET_PIN);

  // Vừa nhấn xuống
  if (btSetState == LOW && btSetLastState == HIGH) {
    btSetPressStart = millis();
    btSetLongTriggered = false;
  }

  // Đang giữ, kiểm tra đủ 5s để vào chế độ set (chỉ khi chưa ở trong chế độ set)
  if (btSetState == LOW && !setModeActive && !btSetLongTriggered) {
    if (millis() - btSetPressStart >= SET_HOLD_TIME) {
      btSetLongTriggered = true;
      enterSetMode();
    }
  }

  // Vừa thả ra
  if (btSetState == HIGH && btSetLastState == LOW) {
    if (setModeActive && !btSetLongTriggered) {
      // nhấn 1 lần trong lúc đang ở chế độ set -> xử lý bước lưu tương ứng
      handleSetClick();
    }
  }

  btSetLastState = btSetState;
}

void enterSetMode() {
  // Dừng cửa an toàn trước khi vào chế độ set
  i = 2;
  van_hanh();

  setModeActive = true;
  setState = SET_WAIT_UP;
  percentMoveActive = false;

  blinkLedHT(5, 300); // chớp 5 lần báo đã vào chế độ set HT
  Serial.println(F("== Da vao che do SET HANH TRINH =="));
  Serial.println(F("Nhan SW1 de mo cua len den nguong tren, roi nhan SW2 de dung."));
}

void handleSetClick() {
  switch (setState) {
    case SET_UP_STOPPED:
      t_up = stopUpTime - startUpTime;
      blinkLedHT(1, 300); // chớp 1 lần báo đã lưu HT trên
      Serial.print(F("Da luu hanh trinh tren: "));
      Serial.print(t_up);
      Serial.println(F(" ms"));
      Serial.println(F("Nhan SW3 de dong cua xuong nguong duoi, roi nhan SW2 de dung."));
      setState = SET_WAIT_DOWN;
      break;

    case SET_DOWN_STOPPED:
      t_down = stopDownTime - startDownTime;
      blinkLedHT(1, 300); // chớp 1 lần báo đã lưu HT dưới
      Serial.print(F("Da luu hanh trinh duoi: "));
      Serial.print(t_down);
      Serial.println(F(" ms"));
      Serial.println(F("Nhan SET 1 lan nua de luu tong hanh trinh."));
      setState = SET_READY_FINAL;
      break;

    case SET_READY_FINAL:
      totalTravelTime = t_up + t_down; // cộng 2 khoảng thời gian lại
      msPerPercent = totalTravelTime / 100.0;
      saveHanhTrinh();

      blinkLedHT(3, 200); // báo hoàn tất set (khác kiểu chớp để phân biệt bước lưu từng phần)
      Serial.print(F("Hoan tat SET HANH TRINH. Tong thoi gian: "));
      Serial.print(totalTravelTime);
      Serial.println(F(" ms"));

      setModeActive = false;
      currentPercent = 0; // sau khi set xong, cửa đang ở ngưỡng dưới (đóng hoàn toàn)
      reportMatterPosition(currentPercent);
      setMatterStalled();
      break;

    default:
      // Nhấn SET trong lúc đang chờ SW hoặc đang chạy thì bỏ qua
      break;
  }
}

// SW1/SW2/SW3 trong lúc đang ở chế độ set hành trình
void chedo_setmode() {
  bool SW1 = digitalRead(SW1_PIN);
  bool SW2 = digitalRead(SW2_PIN);
  bool SW3 = digitalRead(SW3_PIN);

  if (setState == SET_WAIT_UP) {
    if (SW1 == 0 && lastSW1State == HIGH) {
      i = 1;
      van_hanh();
      startUpTime = millis();
      setState = SET_UP_RUNNING;
      Serial.println(F("Dang mo cua... nhan SW2 khi cua da mo hoan toan."));
    }
  } else if (setState == SET_UP_RUNNING) {
    if (SW2 == 0 && lastSW2State == HIGH) {
      i = 2;
      van_hanh();
      stopUpTime = millis();
      setState = SET_UP_STOPPED;
      Serial.println(F("Da dung. Nhan SET 1 lan de luu hanh trinh tren."));
    }
  } else if (setState == SET_WAIT_DOWN) {
    if (SW3 == 0 && lastSW3State == HIGH) {
      i = 3;
      van_hanh();
      startDownTime = millis();
      setState = SET_DOWN_RUNNING;
      Serial.println(F("Dang dong cua... nhan SW2 khi cua da dong hoan toan."));
    }
  } else if (setState == SET_DOWN_RUNNING) {
    if (SW2 == 0 && lastSW2State == HIGH) {
      i = 2;
      van_hanh();
      stopDownTime = millis();
      setState = SET_DOWN_STOPPED;
      Serial.println(F("Da dung. Nhan SET 1 lan de luu hanh trinh duoi."));
    }
  }
  // SET_UP_STOPPED, SET_DOWN_STOPPED, SET_READY_FINAL: bỏ qua SW, chỉ chờ nút SET

  lastSW1State = SW1;
  lastSW2State = SW2;
  lastSW3State = SW3;
}

void blinkLedHT(int times, int ms) {
  for (int k = 0; k < times; k++) {
    digitalWrite(LED_HT_PIN, HIGH);
    delay(ms);
    digitalWrite(LED_HT_PIN, LOW);
    delay(ms);
  }
}

// ==================== LƯU / ĐỌC NVS ====================
void loadHanhTrinh() {
  prefs.begin("hanhtrinh", false);
  t_up = prefs.getULong("t_up", 0);
  t_down = prefs.getULong("t_down", 0);
  totalTravelTime = prefs.getULong("total", 0);
  currentPercent = prefs.getInt("cur_pct", 0);
  prefs.end();

  if (totalTravelTime > 0) {
    msPerPercent = totalTravelTime / 100.0;
    Serial.print(F("Da nap hanh trinh da luu: "));
    Serial.print(totalTravelTime);
    Serial.println(F(" ms"));
  } else {
    Serial.println(F("Chua co hanh trinh nao duoc luu. Giu nut SET 5s de set hanh trinh."));
  }
}

void saveHanhTrinh() {
  prefs.begin("hanhtrinh", false);
  prefs.putULong("t_up", t_up);
  prefs.putULong("t_down", t_down);
  prefs.putULong("total", totalTravelTime);
  prefs.putInt("cur_pct", currentPercent);
  prefs.end();
}

// ==================== ĐIỀU KHIỂN THEO % (test qua Serial) ====================
void handleSerialInput() {
  if (Serial.available()) {
    String s = Serial.readStringUntil('\n');
    s.trim();
    if (s.length() == 0) return;

    int val = s.toInt();
    moveToPercent(val);
  }
}

void moveToPercent(int target) {
  if (setModeActive) {
    Serial.println(F("Dang o che do SET, khong the chay theo %."));
    return;
  }
  if (totalTravelTime == 0) {
    Serial.println(F("Chua set hanh trinh! Giu nut SET 5s de set truoc."));
    return;
  }

  target = constrain(target, 0, 100);

  if (target == currentPercent) {
    Serial.print(F("Cua da o vi tri "));
    Serial.print(currentPercent);
    Serial.println(F("%."));
    return;
  }

  percentMoveActive = true;
  percentMoveStartPercent = currentPercent;
  percentMoveTargetPercent = target;
  percentMoveStartTime = millis();
  percentMoveDuration = (unsigned long)(abs(target - currentPercent) * msPerPercent);
  // 0% và 100% tương đương nhấn SW3 / SW1 -> không cần lệnh dừng tự động
  percentMoveNeedStop = !(target == 0 || target == 100);

  if (target > currentPercent) {
    i = 1;
    van_hanh(); // mở
    setMatterMoving(true);
    Serial.print(F("Dang mo cua den "));
  } else {
    i = 3;
    van_hanh(); // đóng
    setMatterMoving(false);
    Serial.print(F("Dang dong cua den "));
  }
  reportMatterTarget(target);
  Serial.print(target);
  Serial.println(F("%..."));

  lastPercentPrint = 0;
}

void updatePercentMove() {
  if (!percentMoveActive) return;

  unsigned long elapsed = millis() - percentMoveStartTime;

  if (percentMoveDuration > 0) {
    float progress = min(1.0f, (float)elapsed / (float)percentMoveDuration);
    int curPct = percentMoveStartPercent +
                 (int)((percentMoveTargetPercent - percentMoveStartPercent) * progress);

    if (millis() - lastPercentPrint >= 300) { // in tiến trình mỗi 300ms
      Serial.print(F("Cua dang chay: "));
      Serial.print(curPct);
      Serial.println(F("%"));
      reportMatterPosition(curPct); // cập nhật thanh tiến trình trên app theo thời gian thực
      lastPercentPrint = millis();
    }
  }

  if (elapsed >= percentMoveDuration) {
    if (percentMoveNeedStop) {
      i = 2;
      van_hanh(); // gửi lệnh dừng khi đến ngưỡng % mong muốn
    }
    currentPercent = percentMoveTargetPercent;
    percentMoveActive = false;

    saveHanhTrinh(); // lưu lại vị trí hiện tại

    reportMatterPosition(currentPercent);
    setMatterStalled();

    Serial.print(F("Cua da den vi tri: "));
    Serial.print(currentPercent);
    Serial.println(F("%"));
  }
}
